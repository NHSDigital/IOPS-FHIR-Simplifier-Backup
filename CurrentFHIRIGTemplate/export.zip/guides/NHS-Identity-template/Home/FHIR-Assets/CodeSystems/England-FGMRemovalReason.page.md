---
subject: https://fhir.nhs.uk/England/CodeSystem/England-ConditionCategoryRA
issue: CodeSystem-England-ConditionCategoryRA
---
## {{page-title}}

{{page:Home/Templates/CodeSystem-Template.page.md}}