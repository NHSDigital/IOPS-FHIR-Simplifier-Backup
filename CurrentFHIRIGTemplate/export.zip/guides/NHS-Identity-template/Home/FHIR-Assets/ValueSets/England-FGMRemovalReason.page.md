---
subject: https://fhir.nhs.uk/England/ValueSet/England-FlagCategoryPatient
issue: ValueSet-England-FlagCategoryPatient
---
## {{page-title}}

{{page:Home/Templates/ValueSet-Template.page.md}}

<iframe src="https://simplifier.net/guide/nhs-england-fhir-implementation-guide/home/terminology/valueset/valueset-england-fgmremovalreason.page.md?version=current"  height="800px" width="100%"></iframe>