## {{page-title}}

Usage:
- Context of use: Flag
- Required when removing an [xyz] indicator. Reference PUT /Flag/&lt;id&gt; on {{pagelink:Home/Design/Interactions.page.md}}
- If the Flag.status is inactive or entered-in-error then the extension must be included.
- If the Flag.status is active then this extension must be be omitted.

<br>


<iframe src="https://simplifier.net/guide/nhs-england-fhir-implementation-guide/home/profiles-and-extensions/extension-library/extension-england-flagremovalreason.page.md?version=1.1.0" height="800px" width="100%"></iframe>