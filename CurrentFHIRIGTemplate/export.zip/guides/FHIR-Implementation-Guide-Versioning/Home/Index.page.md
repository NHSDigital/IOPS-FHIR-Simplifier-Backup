# Change Log
## v2 15/12/2022
- Bug fix for dynamic tables not rendering correctly based of ticket number <a href='https://nhsd-jira.digital.nhs.uk/browse/IOPS-774' Target='_blank'>IOPS-774</a>
- Updated the home page with prompt text for the creater of IG's which was approved on the DA based of ticket number  <a href="https://nhsd-jira.digital.nhs.uk/browse/IOPS-834/" Target="_blank">IOPS-834</a>