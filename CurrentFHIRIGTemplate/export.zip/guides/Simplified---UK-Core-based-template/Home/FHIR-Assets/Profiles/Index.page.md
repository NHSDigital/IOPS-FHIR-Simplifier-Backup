---
topic: England-Condition-Flag
subject: https://fhir.nhs.uk/England/StructureDefinition/England-Condition-Flag
usage: https://fhir.hl7.org.uk/StructureDefinition/UKCore-Condition
issue: England-Condition-Flag
---

# StructureDefinition {{variable:issue}}

<nocheck>
{{page:Home/Templates/Profile-Template.page.md}}

<div id="Examples" class="tabcontent">
  <h3>Examples</h3>
<br>{{pagelink: RA-Condition-Example}}
<br>{{pagelink: RA-Condition2-Example}}
<br><br>

</div>
</nocheck>