## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

The page lists the profiles used by [xyz] FHIR R4 API:

- {{pagelink:Home/FHIR-Assets/All-Assets/Profiles/UKCore-Patient.page.md}}

<br>The profiles are provided for implementation guidance:
- it is not neccessary to reference the profile in the Resource.meta. Reference: {{pagelink:Home/Examples}}