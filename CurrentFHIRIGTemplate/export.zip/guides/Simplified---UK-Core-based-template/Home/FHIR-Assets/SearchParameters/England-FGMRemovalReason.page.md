---
topic: England-SearchParameter-FlagCategory
subject: https://fhir.nhs.uk/England/SearchParameter/England-FlagCategory
usage: http://hl7.org/fhir/StructureDefinition/SearchParameter
issue: England-FlagCategory
---

## {{page-title}}

{{page:Home/Templates/SearchParameter-Template.page.md}}