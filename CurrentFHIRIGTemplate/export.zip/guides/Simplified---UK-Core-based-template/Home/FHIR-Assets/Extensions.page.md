## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

The page lists the extensions used by [xyz] FHIR R4 API:

- {{pagelink:Home/FHIR-Assets/All-Assets/Extensions/England-FGMRemovalReason.page.md}}