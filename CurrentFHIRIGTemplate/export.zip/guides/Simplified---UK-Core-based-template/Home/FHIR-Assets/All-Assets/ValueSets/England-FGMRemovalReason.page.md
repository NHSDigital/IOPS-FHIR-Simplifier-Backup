## {{page-title}}

Usage:
- Composed of CodeSystem {{pagelink:CodeSystem-England-FGMRemovalReason}}
- Bound in {{pagelink:Extension-England-FGMRemovalReason}}

<br>

<iframe src="https://simplifier.net/guide/nhs-england-fhir-implementation-guide/home/terminology/valueset/valueset-england-fgmremovalreason.page.md?version=current"  height="800px" width="100%"></iframe>