## What is [xyz]?

This implementation guide provides guidance on implementing the [xyz] FHIR R4 API. For further details refer to {{pagelink:Home/Introduction}}

Refer to NHS conditions for information <a href='' class="external">[xyz]</a>