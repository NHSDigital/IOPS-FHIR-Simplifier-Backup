  # Please provide a brief description of what this implementation guide is about

- What is the Aim of this IG?
- Is this IG part of a bigger project
- Does it replace another system?

# Please provide an example of what is in scope for this implementation guide
- Does it use any third party applications


# Please include some use cases

- GP to Ambulance
- Hospital to hospital patient transfer

# Introduction Space 
#### *Please use the introduction page if you have a lengthy introduction section

- How to use this Guide
- Approach
- Delivery

<div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>



