## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page gives a link to download the FHIR assets as a downloadable package. It may be specific to the specification or be a snapshot of the UK Core FHIR assets.

