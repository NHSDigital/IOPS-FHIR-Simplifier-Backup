# {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page needs an overview of the examples section.

version 1.1.0 has no longer got separate pages for clinical scenarios as this has caused display issues and has not been used by any IG apart from Pathology. Clinical scenarios should be added to the example pages. 




