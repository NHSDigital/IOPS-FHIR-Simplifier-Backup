# {{page-title}}

A brief description of the purpose of this section 

|Conformance|
|--
|API|M|
|DOCUMENT|M|
|MESSAGE|M|

|Audience Definition| |
|--
|C|Clinical|This is anyone who has a clinical background and who would review the specification from that angle |
|B|Business|N|Anyone who is connected with the business side, for example NHSD programmes this will be may be many different roles such as project and programme managers, BAs etc|
|T|Technical Architect|Internal and external technical architects|
|F|FHIR |FHIR SMEs looking at FHIR design and compliance| 
|D|Developer| People working at the coding level and associated roles|

