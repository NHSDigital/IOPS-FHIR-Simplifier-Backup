## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page details the interactions between systems, senders, receivers etc.  

It should contain the interaction information and diagram to illustrate the interactions.

Subpages may be added if required for multiple mappings.



