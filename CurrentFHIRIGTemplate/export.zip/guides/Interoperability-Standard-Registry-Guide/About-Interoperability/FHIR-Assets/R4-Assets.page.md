## Profiles

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Condition-Flag">England-Condition-Flag</a>
  Condition
  0.2.0
  2024-06-18
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-DiagnosticReport-MCED">England-DiagnosticReport-MCED</a>
  DiagnosticReport
  0.0.1
  2024-03-19
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Flag-PatientFlag">England-Flag-PatientFlag</a>
  Flag
  0.3.0
  2024-09-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Flag-PatientFlag-Adjustment">England-Flag-PatientFlag-Adjustment</a>
  Flag
  0.2.0
  2024-09-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-MCED-TestReport">England-MCED-TestReport</a>
  2023-11-09
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Observation-MCED">England-Observation-MCED</a>
  Observation
  0.0.1
  2024-03-22
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Observation-MCED-Result">England-Observation-MCED-Result</a>
  Observation
  0.0.1
  2024-03-19
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Observation-MCED-Screening">England-Observation-MCED-Screening</a>
  Observation
  0.0.1
  2024-03-19
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Observation-MCED-Site">England-Observation-MCED-Site</a>
  Observation
  0.0.2
  2024-03-21
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Organization-MCED">England-Organization-MCED</a>
  Organization
  0.0.1
  2024-03-19
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Organization-ODS">England-Organization-ODS</a>
  Organization
  0.0.1
  2024-01-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-OrganizationAffiliation-ODS">England-OrganizationAffiliation-ODS</a>
  OrganizationAffiliation
  0.0.2
  2024-06-18
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Pathology-Report">England-Pathology-Report</a>
  2024-01-23
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Pathology-Request">England-Pathology-Request</a>
  2024-01-23
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Patient-MCED">England-Patient-MCED</a>
  Patient
  0.0.1
  2024-02-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Patient-PDS">England-Patient-PDS</a>
  Patient
  0.0.1
  2024-03-05
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Provenance-Flag">England-Provenance-Flag</a>
  Provenance
  0.1.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-ServiceRequestLab-MCED">England-ServiceRequestLab-MCED</a>
  ServiceRequest
  0.0.1
  2024-02-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Specimen-MCED">England-Specimen-MCED</a>
  Specimen
  0.0.1
  2024-02-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/GPReg-Questionnaire-RegisterGPSurgery-Example">GPReg-Questionnaire-RegisterGPSurgery-Example</a>
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Extension-OrganisationRole-ActiveRoleCode">England-Extension-OrganisationRole-ActiveRoleCode</a>
  token
  0.0.2
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Extension-OrganisationRole-RoleCode">England-Extension-OrganisationRole-RoleCode</a>
  token
  0.0.2
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Extension-TypedDateTime-LastChangeDate">England-Extension-TypedDateTime-LastChangeDate</a>
  date
  0.0.2
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-FlagCategory">England-FlagCategory</a>
  token
  0.4.0
  2024-02-14
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-FlagCode">England-FlagCode</a>
  token
  0.1.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-FlagDetail">England-FlagDetail</a>
  reference
  0.4.0
  2024-02-14
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-AllergyIntolerance">UKCore-AllergyIntolerance</a>
  AllergyIntolerance
  2.5.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Appointment">UKCore-Appointment</a>
  Appointment
  1.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-AuditEvent">UKCore-AuditEvent</a>
  AuditEvent
  1.2.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-BodyStructure">UKCore-BodyStructure</a>
  BodyStructure
  0.0.1
  2024-08-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Bundle">UKCore-Bundle</a>
  Bundle
  2.2.0
  2023-12-16
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-CarePlan">UKCore-CarePlan</a>
  CarePlan
  2.2.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-CareTeam">UKCore-CareTeam</a>
  CareTeam
  2.1.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Communication">UKCore-Communication</a>
  Communication
  2.1.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Composition">UKCore-Composition</a>
  Composition
  2.4.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Condition">UKCore-Condition</a>
  Condition
  2.6.0
  2024-06-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Consent">UKCore-Consent</a>
  Consent
  2.4.0
  2023-12-16
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Device">UKCore-Device</a>
  Device
  1.2.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Device-BloodPressure">UKCore-Device-BloodPressure</a>
  Device
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-DiagnosticReport">UKCore-DiagnosticReport</a>
  DiagnosticReport
  2.5.0
  2024-06-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-DiagnosticReport-Lab">UKCore-DiagnosticReport-Lab</a>
  DiagnosticReport
  2.0.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-DocumentReference">UKCore-DocumentReference</a>
  DocumentReference
  2.2.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Encounter">UKCore-Encounter</a>
  Encounter
  2.5.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-EpisodeOfCare">UKCore-EpisodeOfCare</a>
  EpisodeOfCare
  2.2.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-FamilyMemberHistory">UKCore-FamilyMemberHistory</a>
  FamilyMemberHistory
  1.2.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Flag">UKCore-Flag</a>
  Flag
  1.2.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-HealthcareService">UKCore-HealthcareService</a>
  HealthcareService
  1.3.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-ImagingStudy">UKCore-ImagingStudy</a>
  ImagingStudy
  1.1.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Immunization">UKCore-Immunization</a>
  Immunization
  2.4.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-List">UKCore-List</a>
  List
  2.4.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Location">UKCore-Location</a>
  Location
  2.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Medication">UKCore-Medication</a>
  Medication
  2.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MedicationAdministration">UKCore-MedicationAdministration</a>
  MedicationAdministration
  2.3.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MedicationDispense">UKCore-MedicationDispense</a>
  MedicationDispense
  2.4.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MedicationRequest">UKCore-MedicationRequest</a>
  MedicationRequest
  2.5.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MedicationStatement">UKCore-MedicationStatement</a>
  MedicationStatement
  2.5.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MessageHeader">UKCore-MessageHeader</a>
  MessageHeader
  2.4.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation">UKCore-Observation</a>
  Observation
  2.5.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-ACVPU">UKCore-Observation-ACVPU</a>
  Observation
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-AlcoholConsumption">UKCore-Observation-AlcoholConsumption</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-AverageBloodPressure">UKCore-Observation-AverageBloodPressure</a>
  Observation
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-BloodGlucose">UKCore-Observation-BloodGlucose</a>
  Observation
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-EarlyWarningTotalScore">UKCore-Observation-EarlyWarningTotalScore</a>
  Observation
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-Group-Lab">UKCore-Observation-Group-Lab</a>
  Observation
  2.0.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-InspiredOxygen">UKCore-Observation-InspiredOxygen</a>
  Observation
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-Lab">UKCore-Observation-Lab</a>
  Observation
  2.0.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-TobaccoConsumption">UKCore-Observation-TobaccoConsumption</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns">UKCore-Observation-VitalSigns</a>
  Observation
  1.1.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-BMI">UKCore-Observation-VitalSigns-BMI</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-BloodPressure">UKCore-Observation-VitalSigns-BloodPressure</a>
  Observation
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-BodyHeight">UKCore-Observation-VitalSigns-BodyHeight</a>
  Observation
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-BodyTemperature">UKCore-Observation-VitalSigns-BodyTemperature</a>
  Observation
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-BodyWeight">UKCore-Observation-VitalSigns-BodyWeight</a>
  Observation
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-HeadCircumference">UKCore-Observation-VitalSigns-HeadCircumference</a>
  Observation
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-HeartRate">UKCore-Observation-VitalSigns-HeartRate</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-OxygenSaturation">UKCore-Observation-VitalSigns-OxygenSaturation</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Observation-VitalSigns-RespirationRate">UKCore-Observation-VitalSigns-RespirationRate</a>
  Observation
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-OperationOutcome">UKCore-OperationOutcome</a>
  OperationOutcome
  1.3.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Organization">UKCore-Organization</a>
  Organization
  2.5.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-OrganizationAffiliation">UKCore-OrganizationAffiliation</a>
  OrganizationAffiliation
  0.0.1
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Patient">UKCore-Patient</a>
  Patient
  2.6.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Practitioner">UKCore-Practitioner</a>
  Practitioner
  2.4.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-PractitionerRole">UKCore-PractitionerRole</a>
  PractitionerRole
  2.4.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Procedure">UKCore-Procedure</a>
  Procedure
  2.5.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Provenance">UKCore-Provenance</a>
  Provenance
  1.2.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Questionnaire">UKCore-Questionnaire</a>
  Questionnaire
  1.3.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Questionnaire-EOLPlan-Example">UKCore-Questionnaire-EOLPlan-Example</a>
  2023-11-13T13:32:13+00:00
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Questionnaire-FitnessForWork-Example">UKCore-Questionnaire-FitnessForWork-Example</a>
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Questionnaire-InpatientSurvey-Example">UKCore-Questionnaire-InpatientSurvey-Example</a>
  2023-11-13T11:50:00+00:00
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-QuestionnaireResponse">UKCore-QuestionnaireResponse</a>
  QuestionnaireResponse
  1.2.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-RelatedPerson">UKCore-RelatedPerson</a>
  RelatedPerson
  2.5.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-RequestGroup">UKCore-RequestGroup</a>
  RequestGroup
  1.0.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Schedule">UKCore-Schedule</a>
  Schedule
  1.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-ServiceRequest">UKCore-ServiceRequest</a>
  ServiceRequest
  2.5.1
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-ServiceRequest-Lab">UKCore-ServiceRequest-Lab</a>
  ServiceRequest
  2.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Slot">UKCore-Slot</a>
  Slot
  1.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Specimen">UKCore-Specimen</a>
  Specimen
  2.4.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-Task">UKCore-Task</a>
  Task
  1.2.0
  2023-12-12
  <span class="status draft">draft</span>
</li>

</ul></div><br><br>

---


## Extensions

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/Extension-England-FlagNotes">Extension-England-FlagNotes</a>
  Extension
  0.1.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/Extension-England-LocationExtension">Extension-England-LocationExtension</a>
  Extension
  1.0.0
  2024-06-19
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/Extension-England-TypedPeriod">Extension-England-TypedPeriod</a>
  Extension
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/Extension-England-TypedDateTime">Extension-England-TypedDateTime</a>
  Extension
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/Extension-England-OrganisationRole">Extension-England-OrganisationRole</a>
  Extension
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/Extension-England-FlagRemovalReason">Extension-England-FlagRemovalReason</a>
  Extension
  1.0.0
  2023-11-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-BookingOrganization">Extension-UKCore-BookingOrganization</a>
  Extension
  1.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-OtherContactSystem">Extension-UKCore-OtherContactSystem</a>
  Extension
  3.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ProblemSignificance">Extension-UKCore-ProblemSignificance</a>
  Extension
  1.1.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ActualProblem">Extension-UKCore-ActualProblem</a>
  Extension
  1.3.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ResidentialStatus">Extension-UKCore-ResidentialStatus</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-PharmacistVerifiedIndicator">Extension-UKCore-PharmacistVerifiedIndicator</a>
  Extension
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-CareSettingType">Extension-UKCore-CareSettingType</a>
  Extension
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-Evidence">Extension-UKCore-Evidence</a>
  Extension
  2.2.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-BodySiteReference">Extension-UKCore-BodySiteReference</a>
  Extension
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DiagnosticReportSupportingInfo">Extension-UKCore-DiagnosticReportSupportingInfo</a>
  Extension
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-BirthSex">Extension-UKCore-BirthSex</a>
  Extension
  2.1.0
  2024-06-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-CuffSize">Extension-UKCore-CuffSize</a>
  Extension
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AllergyIntoleranceEnd">Extension-UKCore-AllergyIntoleranceEnd</a>
  Extension
  2.3.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AdditionalContact">Extension-UKCore-AdditionalContact</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-LegalStatus">Extension-UKCore-LegalStatus</a>
  Extension
  1.2.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ListWarningCode">Extension-UKCore-ListWarningCode</a>
  Extension
  3.1.0
  2024-06-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ParentPresent">Extension-UKCore-ParentPresent</a>
  Extension
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-SourceOfServiceRequest">Extension-UKCore-SourceOfServiceRequest</a>
  Extension
  1.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-Recorder">Extension-UKCore-Recorder</a>
  Extension
  1.1.0
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationChangeSummary">Extension-UKCore-MedicationChangeSummary</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ConditionBodyStructure">Extension-UKCore-ConditionBodyStructure</a>
  Extension
  0.0.1
  2024-06-07
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-EthnicCategory">Extension-UKCore-EthnicCategory</a>
  Extension
  2.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DiagnosticReportNote">Extension-UKCore-DiagnosticReportNote</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationPrescribingOrganization">Extension-UKCore-MedicationPrescribingOrganization</a>
  Extension
  1.0.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DiagnosticReportComposition">Extension-UKCore-DiagnosticReportComposition</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ContactRank">Extension-UKCore-ContactRank</a>
  Extension
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-PreferredDispenserOrganization">Extension-UKCore-PreferredDispenserOrganization</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-EmergencyCareDischargeStatus">Extension-UKCore-EmergencyCareDischargeStatus</a>
  Extension
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AddressKey">Extension-UKCore-AddressKey</a>
  Extension
  3.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationDosageLastChanged">Extension-UKCore-MedicationDosageLastChanged</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-TreatmentCategory">Extension-UKCore-TreatmentCategory</a>
  Extension
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationPrescribingOrganizationType">Extension-UKCore-MedicationPrescribingOrganizationType</a>
  Extension
  1.1.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-OutcomeOfAttendance">Extension-UKCore-OutcomeOfAttendance</a>
  Extension
  2.2.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-CodingSCTDescDisplay">Extension-UKCore-CodingSCTDescDisplay</a>
  Extension
  1.2.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicalApplianceSupplier">Extension-UKCore-MedicalApplianceSupplier</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DischargeMethod">Extension-UKCore-DischargeMethod</a>
  Extension
  2.2.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-Coverage">Extension-UKCore-Coverage</a>
  Extension
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DeviceReference">Extension-UKCore-DeviceReference</a>
  Extension
  1.1.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-TypedPeriod">Extension-UKCore-TypedPeriod</a>
  Extension
  1.0.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-NominatedPharmacy">Extension-UKCore-NominatedPharmacy</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ConditionEpisode">Extension-UKCore-ConditionEpisode</a>
  Extension
  3.1.0
  2024-06-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DiagnosticReportMediaLink">Extension-UKCore-DiagnosticReportMediaLink</a>
  Extension
  0.0.1
  2024-06-07
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-SampleCategory">Extension-UKCore-SampleCategory</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationQuantityText">Extension-UKCore-MedicationQuantityText</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-VaccinationProcedure">Extension-UKCore-VaccinationProcedure</a>
  Extension
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-SpecimenCollectionCollector">Extension-UKCore-SpecimenCollectionCollector</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AdmissionMethod">Extension-UKCore-AdmissionMethod</a>
  Extension
  2.3.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ContactPreference">Extension-UKCore-ContactPreference</a>
  Extension
  2.3.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ObservationBodyStructure">Extension-UKCore-ObservationBodyStructure</a>
  Extension
  1.0.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ServiceRequestMethod">Extension-UKCore-ServiceRequestMethod</a>
  Extension
  1.0.0
  2022-05-20
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AssociatedEncounter">Extension-UKCore-AssociatedEncounter</a>
  Extension
  1.1.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-NHSNumberVerificationStatus">Extension-UKCore-NHSNumberVerificationStatus</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ClinicalSetting">Extension-UKCore-ClinicalSetting</a>
  Extension
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ReligiousAffiliation">Extension-UKCore-ReligiousAffiliation</a>
  Extension
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-CopyCorrespondenceIndicator">Extension-UKCore-CopyCorrespondenceIndicator</a>
  Extension
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-TypedDateTime">Extension-UKCore-TypedDateTime</a>
  Extension
  2.2.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-PriorityReason">Extension-UKCore-PriorityReason</a>
  Extension
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-SpecimenContainerDevice">Extension-UKCore-SpecimenContainerDevice</a>
  Extension
  0.0.1
  2023-12-05
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationPrescribingAgency">Extension-UKCore-MedicationPrescribingAgency</a>
  Extension
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-PatientFetalStatus">Extension-UKCore-PatientFetalStatus</a>
  Extension
  0.0.1
  2024-07-23
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-EffectivePeriod">Extension-UKCore-EffectivePeriod</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-NHSNumberUnavailableReason">Extension-UKCore-NHSNumberUnavailableReason</a>
  Extension
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-RelatedProblemHeader">Extension-UKCore-RelatedProblemHeader</a>
  Extension
  1.3.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-OverseasVisitorChargingCategory">Extension-UKCore-OverseasVisitorChargingCategory</a>
  Extension
  1.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-RecordingSetting">Extension-UKCore-RecordingSetting</a>
  Extension
  1.1.0
  2024-06-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-ObservationTriggeredBy">Extension-UKCore-ObservationTriggeredBy</a>
  Extension
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MessageHeaderInstruction">Extension-UKCore-MessageHeaderInstruction</a>
  Extension
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-EncounterTransport">Extension-UKCore-EncounterTransport</a>
  Extension
  2.1.0
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-NHSCommunication">Extension-UKCore-NHSCommunication</a>
  Extension
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DeathNotificationStatus">Extension-UKCore-DeathNotificationStatus</a>
  Extension
  2.2.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-RelatedClinicalContent">Extension-UKCore-RelatedClinicalContent</a>
  Extension
  1.3.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationStatementLastIssueDate">Extension-UKCore-MedicationStatementLastIssueDate</a>
  Extension
  2.1.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MainLocation">Extension-UKCore-MainLocation</a>
  Extension
  2.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-PrescriptionType">Extension-UKCore-PrescriptionType</a>
  Extension
  2.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-CodingSCTDescId">Extension-UKCore-CodingSCTDescId</a>
  Extension
  2.2.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-AnaestheticIssues">Extension-UKCore-AnaestheticIssues</a>
  Extension
  2.3.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-FamilyMemberHistoryParticipant">Extension-UKCore-FamilyMemberHistoryParticipant</a>
  Extension
  1.1.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-DeliveryChannel">Extension-UKCore-DeliveryChannel</a>
  Extension
  2.1.0
  2024-06-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationTradeFamily">Extension-UKCore-MedicationTradeFamily</a>
  Extension
  1.1.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-SpecimenContainerLocation">Extension-UKCore-SpecimenContainerLocation</a>
  Extension
  0.0.1
  2023-12-05
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/Extension-UKCore-MedicationRepeatInformation">Extension-UKCore-MedicationRepeatInformation</a>
  Extension
  2.3.0
  2023-12-07
  <span class="status active">active</span>
</li>

</ul></div><br><br>

---


## ValueSets

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-BodyStructure">England-BodyStructure</a>
  0.0.2
  2024-06-18
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-England-ChildProtectionPlan">England-ChildProtectionPlan</a>
  1.0.0
  2023-11-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagCategoryPatient">England-FlagCategoryPatient</a>
  0.1.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagCategoryProgramme">England-FlagCategoryProgramme</a>
  0.3.7
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagCodeProgramme">England-FlagCodeProgramme</a>
  0.3.7
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagCodeRA">England-FlagCodeRA</a>
  0.1.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagConditionCategory">England-FlagConditionCategory</a>
  0.3.7
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagConditionCode">England-FlagConditionCode</a>
  0.3.7
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-FlagProvenanceRole">England-FlagProvenanceRole</a>
  0.3.8
  2024-06-25
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-England-FlagRemovalReason">England-FlagRemovalReason</a>
  1.0.0
  2023-11-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/ValueSet-England-MCEDSignalResult">England-MCEDSignalResult</a>
  0.0.1
  2024-02-27
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-England-OrganisationRole">England-OrganisationRole</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-England-PeriodType">England-PeriodType</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-England-TypedDateTime">England-TypedDateTime</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ACVPU">UKCore-ACVPU</a>
  2.1.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AddressKeyType">UKCore-AddressKeyType</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AdmissionMethod">UKCore-AdmissionMethod</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AlcoholConsumption">UKCore-AlcoholConsumption</a>
  0.0.1
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AllergyCode">UKCore-AllergyCode</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AllergyExposureRoute">UKCore-AllergyExposureRoute</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AllergyManifestation">UKCore-AllergyManifestation</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AllergySubstance">UKCore-AllergySubstance</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-AppointmentReasonCode">UKCore-AppointmentReasonCode</a>
  1.0.0
  2022-05-20
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BMI">UKCore-BMI</a>
  1.0.1
  2024-02-27
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BiopsyState">UKCore-BiopsyState</a>
  2.1.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BirthSex">UKCore-BirthSex</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodGlucose">UKCore-BloodGlucose</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure">UKCore-BloodPressure</a>
  1.0.1
  2024-02-27
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-Average">UKCore-BloodPressure-Average</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-AverageDiastolic">UKCore-BloodPressure-AverageDiastolic</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-AverageSystolic">UKCore-BloodPressure-AverageSystolic</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-CuffSize">UKCore-BloodPressure-CuffSize</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-DeviceType">UKCore-BloodPressure-DeviceType</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-Diastolic">UKCore-BloodPressure-Diastolic</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-MeasurementMethod">UKCore-BloodPressure-MeasurementMethod</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BloodPressure-Systolic">UKCore-BloodPressure-Systolic</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BodyHeightMeasurements">UKCore-BodyHeightMeasurements</a>
  1.0.1
  2024-02-27
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BodyPosition">UKCore-BodyPosition</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BodySite">UKCore-BodySite</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BodyTemperature">UKCore-BodyTemperature</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-BodyWeightMeasurements">UKCore-BodyWeightMeasurements</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-CareSettingType">UKCore-CareSettingType</a>
  3.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-CompositionCategory">UKCore-CompositionCategory</a>
  1.0.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-CompositionSectionCode">UKCore-CompositionSectionCode</a>
  2.2.0
  2023-08-03
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConditionCategory">UKCore-ConditionCategory</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConditionCode">UKCore-ConditionCode</a>
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConditionEpisode">UKCore-ConditionEpisode</a>
  2.1.0
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConditionEpisodicity">UKCore-ConditionEpisodicity</a>
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConditionRelationship">UKCore-ConditionRelationship</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ConsentException">UKCore-ConsentException</a>
  0.0.1
  2024-07-11
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DateTimeType">UKCore-DateTimeType</a>
  2.1.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DeathNotificationStatus">UKCore-DeathNotificationStatus</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DeliveryChannel">UKCore-DeliveryChannel</a>
  1.1.0
  2022-05-20
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DeviceType">UKCore-DeviceType</a>
  1.1.0
  2022-01-22
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DischargeDestination">UKCore-DischargeDestination</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DischargeMethod">UKCore-DischargeMethod</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-DocumentType">UKCore-DocumentType</a>
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EarlyWarningSubScore">UKCore-EarlyWarningSubScore</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EarlyWarningTotalScore">UKCore-EarlyWarningTotalScore</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EmergencyCareDischargeStatus">UKCore-EmergencyCareDischargeStatus</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EncounterLocationType">UKCore-EncounterLocationType</a>
  1.0.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EncounterType">UKCore-EncounterType</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-EthnicCategory">UKCore-EthnicCategory</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-FindingCode">UKCore-FindingCode</a>
  2.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-FundingCategory">UKCore-FundingCategory</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-GenomeSequencingCategory">UKCore-GenomeSequencingCategory</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-HeadCircumferenceMeasurements">UKCore-HeadCircumferenceMeasurements</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-HeartRate">UKCore-HeartRate</a>
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-HumanLanguage">UKCore-HumanLanguage</a>
  2.2.0
  2023-12-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ImmunizationAdministrationBodySite">UKCore-ImmunizationAdministrationBodySite</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ImmunizationExplanationReason">UKCore-ImmunizationExplanationReason</a>
  2.3.0
  2023-02-14
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-InspiredOxygen">UKCore-InspiredOxygen</a>
  2.1.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-LanguageAbilityMode">UKCore-LanguageAbilityMode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-LanguageAbilityProficiency">UKCore-LanguageAbilityProficiency</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-LegalStatusClassification">UKCore-LegalStatusClassification</a>
  1.0.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-LegalStatusContext">UKCore-LegalStatusContext</a>
  1.0.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ListCode">UKCore-ListCode</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ListEmptyReasonCode">UKCore-ListEmptyReasonCode</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ListWarningCode">UKCore-ListWarningCode</a>
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationAdministrationCategory">UKCore-MedicationAdministrationCategory</a>
  1.0.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationChangeStatus">UKCore-MedicationChangeStatus</a>
  1.1.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationCode">UKCore-MedicationCode</a>
  2.3.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationDosageMethod">UKCore-MedicationDosageMethod</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationDosageRoute">UKCore-MedicationDosageRoute</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationForm">UKCore-MedicationForm</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationPrecondition">UKCore-MedicationPrecondition</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationPrescribingAgency">UKCore-MedicationPrescribingAgency</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationPrescribingOrganization">UKCore-MedicationPrescribingOrganization</a>
  1.1.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationPrescribingOrganizationType">UKCore-MedicationPrescribingOrganizationType</a>
  1.0.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationRequestCategory">UKCore-MedicationRequestCategory</a>
  1.1.2
  2024-07-23
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationRequestCourseOfTherapy">UKCore-MedicationRequestCourseOfTherapy</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationStatementCategory">UKCore-MedicationStatementCategory</a>
  1.1.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationSupplyType">UKCore-MedicationSupplyType</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MedicationTradeFamily">UKCore-MedicationTradeFamily</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MessageEvent">UKCore-MessageEvent</a>
  2.2.0
  2024-02-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-MessageHeaderInstruction">UKCore-MessageHeaderInstruction</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-NHSNumberUnavailableReason">UKCore-NHSNumberUnavailableReason</a>
  1.1.0
  2024-06-14
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-NHSNumberVerificationStatus">UKCore-NHSNumberVerificationStatus</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ObservationMethod">UKCore-ObservationMethod</a>
  2.0.0
  2023-11-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ObservationType">UKCore-ObservationType</a>
  2.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ObservationVitalSignsType">UKCore-ObservationVitalSignsType</a>
  1.1.0
  2024-02-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ObservationVitalSignsValue">UKCore-ObservationVitalSignsValue</a>
  1.0.0
  2023-11-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OperationOutcomeIssueDetails">UKCore-OperationOutcomeIssueDetails</a>
  1.1.0
  2024-02-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OrganizationType">UKCore-OrganizationType</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OtherContactSystem">UKCore-OtherContactSystem</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OutcomeOfAttendance">UKCore-OutcomeOfAttendance</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OverseasVisitorChargingCategory">UKCore-OverseasVisitorChargingCategory</a>
  1.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-OxygenSaturation">UKCore-OxygenSaturation</a>
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PathologyAndLaboratoryMedicineObservables">UKCore-PathologyAndLaboratoryMedicineObservables</a>
  1.0.0
  2023-11-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PathologyAndLaboratoryMedicineProcedures">UKCore-PathologyAndLaboratoryMedicineProcedures</a>
  1.0.0
  2023-11-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PeriodType">UKCore-PeriodType</a>
  1.0.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PersonMaritalStatusCode">UKCore-PersonMaritalStatusCode</a>
  2.3.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PersonRelationshipType">UKCore-PersonRelationshipType</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PersonStatedGenderCode">UKCore-PersonStatedGenderCode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PracticeSettingCode">UKCore-PracticeSettingCode</a>
  1.0.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PractitionerRoleCode">UKCore-PractitionerRoleCode</a>
  1.0.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PreferredContactMethod">UKCore-PreferredContactMethod</a>
  2.2.0
  2023-10-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PreferredWrittenCommunicationFormat">UKCore-PreferredWrittenCommunicationFormat</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-PrescriptionType">UKCore-PrescriptionType</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ProblemSignificance">UKCore-ProblemSignificance</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ProcedureCode">UKCore-ProcedureCode</a>
  2.2.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-QuestionnaireQuestionCodes">UKCore-QuestionnaireQuestionCodes</a>
  1.0.0
  2024-02-12
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ReasonImmunizationNotAdministered">UKCore-ReasonImmunizationNotAdministered</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-RecordingSetting">UKCore-RecordingSetting</a>
  1.0.0
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ReligiousAffiliation">UKCore-ReligiousAffiliation</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ReportCode">UKCore-ReportCode</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ReportCodeSnCT">UKCore-ReportCodeSnCT</a>
  2.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ResidentialStatus">UKCore-ResidentialStatus</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-RespirationRate">UKCore-RespirationRate</a>
  1.1.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SDSJobRoleName">UKCore-SDSJobRoleName</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SampleCategory">UKCore-SampleCategory</a>
  2.1.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ServiceRequestMethod">UKCore-ServiceRequestMethod</a>
  1.0.0
  2022-05-20
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-ServiceRequestReasonCode">UKCore-ServiceRequestReasonCode</a>
  1.1.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SourceOfAdmission">UKCore-SourceOfAdmission</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SourceOfServiceRequest">UKCore-SourceOfServiceRequest</a>
  1.2.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SpecimenBodySite">UKCore-SpecimenBodySite</a>
  2.1.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SpecimenType">UKCore-SpecimenType</a>
  2.2.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-SubstanceOrProductAdministrationRoute">UKCore-SubstanceOrProductAdministrationRoute</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-TobaccoConsumption">UKCore-TobaccoConsumption</a>
  0.0.1
  2023-09-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-TreatmentCategory">UKCore-TreatmentCategory</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-UnifiedTestList">UKCore-UnifiedTestList</a>
  1.0.0
  2023-11-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-VaccinationProcedure">UKCore-VaccinationProcedure</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-VaccinationProcedureSupplementary">UKCore-VaccinationProcedureSupplementary</a>
  2.1.1
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-VaccineCode">UKCore-VaccineCode</a>
  2.2.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-VitalSignsObservationType">UKCore-VitalSignsObservationType</a>
  2.0.1
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/ValueSet-UKCore-VitalSignsObservationValue">UKCore-VitalSignsObservationValue</a>
  2.0.0
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/ValueSet-nhsdigital-message-events">nhsdigital-message-events</a>
  1.0.12
  <span class="status draft">draft</span>
</li>

</ul></div><br><br>

---


## CodeSystems

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/CodeSystem-England-ConditionCategoryRA">England-ConditionCategoryRA</a>
  0.4.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/CodeSystem-England-ConditionCodeRA">England-ConditionCodeRA</a>
  0.4.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-FGMRemovalReason">England-FGMRemovalReason</a>
  1.0.0
  2023-11-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/CodeSystem-England-FlagCategoryPatient">England-FlagCategoryPatient</a>
  0.4.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/CodeSystem-England-FlagCategoryRA">England-FlagCategoryRA</a>
  0.4.0
  2024-02-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-HTTPErrorCodes">England-HTTPErrorCodes</a>
  1.0.0
  2024-06-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-MessageEventsBARS">England-MessageEventsBARS</a>
  1.0.0
  2024-06-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-MessageReasonBARS">England-MessageReasonBARS</a>
  1.0.0
  2024-06-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-ODSDateTime">England-ODSDateTime</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-ODSOrganisationRole">England-ODSOrganisationRole</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-ODSRecordClass">England-ODSRecordClass</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-ODSRecordUseType">England-ODSRecordUseType</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-ODSRelationship">England-ODSRelationship</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-PFSPrescriptionOrderingParameter">England-PFSPrescriptionOrderingParameter</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-England-PeriodType">England-PeriodType</a>
  1.0.0
  2023-12-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/CodeSystem-England-SDSJobRoleName">England-SDSJobRoleName</a>
  0.0.1
  2024-09-17
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-AdmissionMethod">NHSDataModelAndDictionary-AdmissionMethod</a>
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-DischargeDestination">NHSDataModelAndDictionary-DischargeDestination</a>
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-DischargeMethod">NHSDataModelAndDictionary-DischargeMethod</a>
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-OutcomeOfAttendance">NHSDataModelAndDictionary-OutcomeOfAttendance</a>
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-PersonMaritalStatusCode">NHSDataModelAndDictionary-PersonMaritalStatusCode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-PersonStatedGenderCode">NHSDataModelAndDictionary-PersonStatedGenderCode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-NHSDataModelAndDictionary-SourceOfAdmission">NHSDataModelAndDictionary-SourceOfAdmission</a>
  2.0.0
  2022-01-07
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-AdditionalPersonRelationshipRole">UKCore-AdditionalPersonRelationshipRole</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-AddressKeyType">UKCore-AddressKeyType</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-AdmissionMethodEngland">UKCore-AdmissionMethodEngland</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-AdmissionMethodWales">UKCore-AdmissionMethodWales</a>
  1.1.0
  2024-01-04
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-AppointmentReasonCode">UKCore-AppointmentReasonCode</a>
  1.0.0
  2022-05-20
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-BiopsyState">UKCore-BiopsyState</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ConditionCategory">UKCore-ConditionCategory</a>
  1.1.0
  2023-12-12
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ConditionEpisodicity">UKCore-ConditionEpisodicity</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ConditionRelationship">UKCore-ConditionRelationship</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ConsentUpdateMode">UKCore-ConsentUpdateMode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DateTimeType">UKCore-DateTimeType</a>
  2.1.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DeathNotificationStatus">UKCore-DeathNotificationStatus</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DeliveryChannel">UKCore-DeliveryChannel</a>
  1.1.0
  2022-05-20
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DischargeDestinationEngland">UKCore-DischargeDestinationEngland</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DischargeDestinationWales">UKCore-DischargeDestinationWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DischargeMethodEngland">UKCore-DischargeMethodEngland</a>
  1.1.0
  2024-01-04
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-DischargeMethodWales">UKCore-DischargeMethodWales</a>
  1.1.0
  2024-01-04
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EPSIssueCode">UKCore-EPSIssueCode</a>
  1.1.0
  2023-02-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EmergencyCareOutcomeOfAttendanceWales">UKCore-EmergencyCareOutcomeOfAttendanceWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EncounterLocationTypeEngland">UKCore-EncounterLocationTypeEngland</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EncounterLocationTypeWales">UKCore-EncounterLocationTypeWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EthnicCategory">UKCore-EthnicCategory</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EthnicCategoryEngland">UKCore-EthnicCategoryEngland</a>
  1.1.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EthnicCategoryScotland">UKCore-EthnicCategoryScotland</a>
  1.1.1
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-EthnicCategoryWales">UKCore-EthnicCategoryWales</a>
  1.1.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-FundingCategory">UKCore-FundingCategory</a>
  2.0.0
  2024-06-14
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-GenomeSequencingCategory">UKCore-GenomeSequencingCategory</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-HumanLanguage">UKCore-HumanLanguage</a>
  2.1.0
  2023-12-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ITKResponseCode">UKCore-ITKResponseCode</a>
  1.0.0
  2023-02-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-LanguageAbilityMode">UKCore-LanguageAbilityMode</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-LanguageAbilityProficiency">UKCore-LanguageAbilityProficiency</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-LegalStatusClassificationEngland">UKCore-LegalStatusClassificationEngland</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-LegalStatusClassificationWales">UKCore-LegalStatusClassificationWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-LegalStatusContext">UKCore-LegalStatusContext</a>
  1.0.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ListEmptyReasonCode">UKCore-ListEmptyReasonCode</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ListWarningCode">UKCore-ListWarningCode</a>
  2.1.0
  2022-01-07
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationAdministrationCategory">UKCore-MedicationAdministrationCategory</a>
  1.0.0
  2022-12-16
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationChangeStatus">UKCore-MedicationChangeStatus</a>
  1.0.1
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationPrescribingAgency">UKCore-MedicationPrescribingAgency</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationPrescribingOrganization">UKCore-MedicationPrescribingOrganization</a>
  1.0.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationPrescribingOrganizationType">UKCore-MedicationPrescribingOrganizationType</a>
  1.0.0
  2022-08-26
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationRequestCategory">UKCore-MedicationRequestCategory</a>
  1.1.1
  2023-10-06
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationRequestCourseOfTherapy">UKCore-MedicationRequestCourseOfTherapy</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationStatementCategory">UKCore-MedicationStatementCategory</a>
  1.0.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MedicationSupplyType">UKCore-MedicationSupplyType</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MessageEvent">UKCore-MessageEvent</a>
  2.1.0
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-MessageHeaderInstruction">UKCore-MessageHeaderInstruction</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-NHSNumberUnavailableReason">UKCore-NHSNumberUnavailableReason</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-NHSNumberVerificationStatus">UKCore-NHSNumberVerificationStatus</a>
  2.1.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-NHSNumberVerificationStatusEngland">UKCore-NHSNumberVerificationStatusEngland</a>
  1.1.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-NHSNumberVerificationStatusWales">UKCore-NHSNumberVerificationStatusWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-OrganizationTypeGenomics">UKCore-OrganizationTypeGenomics</a>
  1.0.0
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-OtherContactSystem">UKCore-OtherContactSystem</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-OutcomeOfAttendanceEngland">UKCore-OutcomeOfAttendanceEngland</a>
  1.1.0
  2024-01-04
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-OutcomeOfAttendanceWales">UKCore-OutcomeOfAttendanceWales</a>
  1.1.0
  2024-01-04
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-OverseasVisitorChargingCategory">UKCore-OverseasVisitorChargingCategory</a>
  1.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PeriodType">UKCore-PeriodType</a>
  1.0.0
  2023-10-13
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PersonMaritalStatus">UKCore-PersonMaritalStatus</a>
  1.0.0
  2022-08-26
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PersonMaritalStatusEngland">UKCore-PersonMaritalStatusEngland</a>
  1.1.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PersonMaritalStatusScotland">UKCore-PersonMaritalStatusScotland</a>
  1.0.1
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PersonMaritalStatusWales">UKCore-PersonMaritalStatusWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PracticeSettingCode">UKCore-PracticeSettingCode</a>
  1.0.1
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PracticeSettingCodeEngland">UKCore-PracticeSettingCodeEngland</a>
  1.0.1
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PracticeSettingCodeScotland">UKCore-PracticeSettingCodeScotland</a>
  1.0.1
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PracticeSettingCodeWales">UKCore-PracticeSettingCodeWales</a>
  1.0.1
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PreferredContactMethod">UKCore-PreferredContactMethod</a>
  2.2.0
  2023-10-09
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PreferredWrittenCommunicationFormat">UKCore-PreferredWrittenCommunicationFormat</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-PrescriptionType">UKCore-PrescriptionType</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ProblemSignificance">UKCore-ProblemSignificance</a>
  1.0.0
  2023-04-28
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-RecordStandardHeadings">UKCore-RecordStandardHeadings</a>
  2.2.0
  2022-08-03
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-RecordingSetting">UKCore-RecordingSetting</a>
  1.0.0
  2024-07-11
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ResidentialStatus">UKCore-ResidentialStatus</a>
  2.1.0
  2021-09-10
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-SDSJobRoleName">UKCore-SDSJobRoleName</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-SampleCategory">UKCore-SampleCategory</a>
  2.0.0
  2024-08-05
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-ServiceRequestMethod">UKCore-ServiceRequestMethod</a>
  1.0.0
  2022-05-20
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-SourceOfAdmissionEngland">UKCore-SourceOfAdmissionEngland</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-SourceOfAdmissionWales">UKCore-SourceOfAdmissionWales</a>
  1.0.1
  2023-04-28
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-SpineErrorOrWarningCode">UKCore-SpineErrorOrWarningCode</a>
  1.0.0
  2023-02-12
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-TreatmentCategory">UKCore-TreatmentCategory</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/CodeSystem-UKCore-WithheldIdentityReason">UKCore-WithheldIdentityReason</a>
  0.0.1
  2024-06-14
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-implementation-guide/CodeSystem-message-events">message-events</a>
  1.0.19
  2022-03-25
  <span class="status draft">draft</span>
</li>

</ul></div><br><br>

---


## ConceptMaps

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-AdministrativeGender">UKCore-AdministrativeGender</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-ConditionEpisodicity">UKCore-ConditionEpisodicity</a>
  2.0.0
  2022-12-16
  <span class="status retired">retired</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/UKCore-MaritalStatus">UKCore-MaritalStatus</a>
  2.0.0
  2021-09-10
  <span class="status retired">retired</span>
</li>

</ul></div><br><br>

---


## CapabilityStatements

<div class="status-container">
<ul>
<li><a href="https://simplifier.net/nhs-england-implementation-guide/apim-conformance">apim-conformance</a>
  1.0.0
  2022-12-16T00:00:00+00:00
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-FHIRExamples-Conformance">England-FHIRExamples-Conformance</a>
  3.2.0
  2022-12-16T00:00:00+00:00
  <span class="status active">active</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-MCED-Requirements">England-MCED-Requirements</a>
  0.0.1
  2024-01-23
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-ODS-Requirements">England-ODS-Requirements</a>
  0.0.5
  2024-09-17
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-Pathology-Requirements">England-Pathology-Requirements</a>
  0.0.2
  2024-03-20
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/nhs-england-programme-implementation-guides/England-PatientFlag-Server-Requirements">England-PatientFlag-Server-Requirements</a>
  0.1.0
  2024-09-20
  <span class="status draft">draft</span>
</li>

<li><a href="https://simplifier.net/hl7fhirukcorer4/apim-conformance">apim-conformance</a>
  3.2.0
  2022-12-16T00:00:00+00:00
  <span class="status active">active</span>
</li>

</ul></div><br><br>

---


