## OperationDefinitions


<div class="project-container">


<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/OperationDefinition-genomics-generate" class="child-title">
<div class="title">OperationDefinition-genomics-generate</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-09-04 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/OperationDefinition-genomics-validate" class="child-title">
<div class="title">OperationDefinition-genomics-validate</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-09-20 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
</div>

---


