## ConceptMaps


<div class="project-container">


<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-AdministrativeGender" class="child-title">
<div class="title">UKCore-AdministrativeGender</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2021-09-10 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-ConditionEpisodicity" class="child-title">
<div class="title">UKCore-ConditionEpisodicity</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2022-12-16 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-MaritalStatus" class="child-title">
<div class="title">UKCore-MaritalStatus</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2021-09-10 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
</div>

---


