## ConceptMaps


<div class="project-container">


<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-laterality-of-hearingloss" class="child-title">
<div class="title">genomics-laterality-of-hearingloss</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-22T16:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-condition-liquidtumourtype" class="child-title">
<div class="title">genomics-condition-liquidtumourtype</div>
<div class="description">
  0.2.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-11T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-condition-pancreatictumourtype" class="child-title">
<div class="title">genomics-condition-pancreatictumourtype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-11T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-condition-pituitarytumourtype" class="child-title">
<div class="title">genomics-condition-pituitarytumourtype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-11T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-condition-solidtumourtype" class="child-title">
<div class="title">genomics-condition-solidtumourtype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-11T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-disease-status" class="child-title">
<div class="title">genomics-disease-status</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-08T14:15:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-fetal-maternal-screening-genotype" class="child-title">
<div class="title">genomics-fetal-maternal-screening-genotype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-08T18:15:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-patient-bornstatus" class="child-title">
<div class="title">genomics-patient-bornstatus</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-19T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-foetusobservedsex" class="child-title">
<div class="title">genomics-foetusobservedsex</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-19T16:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-patientbirthsex" class="child-title">
<div class="title">genomics-patientbirthsex</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-28T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-patientpregnancytype" class="child-title">
<div class="title">genomics-patientpregnancytype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-07-04T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-primary-sample-state" class="child-title">
<div class="title">genomics-primary-sample-state</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-10-04T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-probandrelationshiptype" class="child-title">
<div class="title">genomics-probandrelationshiptype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-28T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-procedure-transfusiontype" class="child-title">
<div class="title">genomics-procedure-transfusiontype</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-07-12T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-reportdeliverymethod" class="child-title">
<div class="title">genomics-reportdeliverymethod</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-06-27T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-risk-reason-for-specimen-specialhandling" class="child-title">
<div class="title">genomics-risk-reason-for-specimen-specialhandling</div>
<div class="description">
  0.2.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-09T18:45:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-finalsample" class="child-title">
<div class="title">genomics-finalsample</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-10-01T18:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-primarysample" class="child-title">
<div class="title">genomics-primarysample</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-15T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-samplepreparation" class="child-title">
<div class="title">genomics-samplepreparation</div>
<div class="description">
  0.0.2 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-10-01T15:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-specimen-tumourcellularity" class="child-title">
<div class="title">genomics-specimen-tumourcellularity</div>
<div class="description">
  0.1.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-05T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-testrequestpriority" class="child-title">
<div class="title">genomics-testrequestpriority</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-01T00:00:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/NHS-Digital-FHIR-Genomics-Implementation-Guide/genomics-typeof-transplantprocedure" class="child-title">
<div class="title">genomics-typeof-transplantprocedure</div>
<div class="description">
  0.0.1 &nbsp;&nbsp;&nbsp;&nbsp;
  2024-08-12T17:40:00.000Z &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status draft">draft</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-AdministrativeGender" class="child-title">
<div class="title">UKCore-AdministrativeGender</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2021-09-10 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-ConditionEpisodicity" class="child-title">
<div class="title">UKCore-ConditionEpisodicity</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2022-12-16 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
<a href="https://simplifier.net/HL7FHIRUKCoreR4/UKCore-MaritalStatus" class="child-title">
<div class="title">UKCore-MaritalStatus</div>
<div class="description">
  2.0.0 &nbsp;&nbsp;&nbsp;&nbsp;
  2021-09-10 &nbsp;&nbsp;&nbsp;&nbsp;
<span class="status retired">retired</span> &nbsp;&nbsp;&nbsp;&nbsp;
</div>
</a>
</div>

---


