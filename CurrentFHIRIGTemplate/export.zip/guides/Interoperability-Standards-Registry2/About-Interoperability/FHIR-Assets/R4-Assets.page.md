<div class="container-nhs-pale-grey">

## R4 Assets

</div>
</br>

<div class="col-grid">
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/ProfilesandExtensions/ExtensionLibrary?version=current#Extension-UKCore-AdditionalContact">Extensions</a></b></h4>
<p class="col-grid-text">List of all the Extensions Used.</p>
</div>
</div>
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/Terminology/AllValueSets?version=current">ValueSets</a></b></h4>
<p class="col-grid-text">List of all the Valuesets Used.
</p>
</div>
</div>
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/Terminology/AllCodeSystems?version=current" >CodeSystems </a></b></h4>
 <p class="col-grid-text">List of all the Codesystems used.</p>
</div>
</div>
</div>
</div>
</br>

<div class="col-grid">
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/Examples/Profile-Examples?version=current">Examples(Profile)</a></b></h4>
<p class="col-grid-text">List of Example used for profiles.</p>
</div>
</div>
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/Examples/Extension-Examples?version=current">Examples(Extension)</a></b></h4>
<p class="col-grid-text">List of examples used for extensions.
</p>
</div>
</div>
</div>
</div>
</div>
</br>
