<div class="container-nhs-pale-grey">

## STU3 Assets

</div>
</br>

<div class="col-grid">
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://fhir.nhs.uk/">STU3 Assets(Derived)</a></b></h4>
<p class="col-grid-text">List of all the DSTU2/STU3 Assets.</p>
</div>
</div>
<div class="col-grid">
<div class="col-grid-content">
<div class="col-grid-body">
<h4 class="col-grid-title"><b><a href="https://fhir.hl7.org.uk/">HL7 UK INTEROPen CareConnect FHIR Profiles</a></b></h4>
<p class="col-grid-text">List of all the DSTU2/STU3 Assets.</p>
</div>
</div>
</div>
</div>
</br>


