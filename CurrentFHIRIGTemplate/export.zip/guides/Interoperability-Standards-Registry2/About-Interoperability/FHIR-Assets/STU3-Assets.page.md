<div class="container-nhs-pale-grey">

## STU3 Assets

</div>
</br>

<div class="col">
<div class="col-md-7 card text-center ">
<div class="card-body">
<h4 class="card-title"><b><a href="https://fhir.nhs.uk/">STU3 Assets</a></b></h4>
<p class="card-text">List of all the DSTU2/STU3 Assets.</p>
</div>
</div>
</div>
</div>
</div>
</br>
