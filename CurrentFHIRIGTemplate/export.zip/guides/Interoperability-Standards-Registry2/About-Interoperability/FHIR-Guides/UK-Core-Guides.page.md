<div class="container-nhs-pale-grey">

## UK Core Implementation Guides

</div>
</br>

<div class="col">
<div class="col-md-7 card text-center ">
<div class="card-body">
<h4 class="card-title"><b><a href="https://simplifier.net/guide/uk-core-implementation-guide?version=current">UK Core Implementation Guide 1.0.0 - STU1</a></b></h4>
<p class="card-text">The UK Core Implementation Guide as a project aims to provide UK wide FHIR implementation guidance that has applicability across jurisdictions and care settings.</p>
</div>
</div>
<div class="col-md-7 card text-center">
<div class="card-body">
 <h4 class="card-title"><b><a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2?version=current">UK Core Implementation Guide 2.0.1 - STU2 Sequence</a></b></h4>
<p class="card-text">The FHIR UK Core Implementation Guide as a project aims to provide UK wide FHIR implementation guidance that has applicability across jurisdictions and care settings.
</div>
</div>
<div class="col-md-7 card text-center">
<div class="card-body">
<h4 class="card-title"><b><a href="https://simplifier.net/guide/uk-core-implementation-guide-stu3-sequence?version=current" >UK Core Implementation Guide STU3 Sequence </a></b></h4>
 <p class="card-text">The FHIR UK Core Implementation Guide as a project aims to provide UK wide FHIR implementation guidance that has applicability across jurisdictions and care settings.</p>
</div>
</div>
</div>
</div>
</div>
</br>