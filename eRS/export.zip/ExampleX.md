## Example [X]

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page shows examples supported by the specification. Examples should be as comprehensive as possible to aid developers.

Subpages may be added for navigation for example for Clinical scenarios. 



