## Use of attachments

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This is really only applicable to FHIR documents but may be used for other paradigms. It should explain the use of attachments etc.   
