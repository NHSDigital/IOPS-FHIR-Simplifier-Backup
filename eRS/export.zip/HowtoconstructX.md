## How to construct [X]

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page is used to describe how to create a clinical structure such as allergy lists.

It may just point to core guidance where it exists. This page should describe in detail how to construct the structure in an instance.

