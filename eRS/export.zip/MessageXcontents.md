## Message [X] contents

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page is used to describe the contents of message i.e. list the profiles and extensions in a message. These should link to the profile and extension pages in this specification.

