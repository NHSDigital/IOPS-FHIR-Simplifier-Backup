## Acknowledgments and responses

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page details responses in the form of acknowledgements etc.
It is more applicable to messaging and document exchanges.

