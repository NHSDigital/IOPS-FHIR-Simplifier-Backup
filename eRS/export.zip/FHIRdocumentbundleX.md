## FHIR Document Bundle

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This is only applicable to FHIR documents and details the document bundle structure.  Multiple pages may be added at this level if required.
