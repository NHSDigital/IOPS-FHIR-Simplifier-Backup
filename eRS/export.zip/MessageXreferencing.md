## Message [X] referencing

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page is used to describe referencing between the profiles in a message and should include diagrams to illustrate this.
As bundle type will be 'message', all profiles should reference each other i.e. none should be orphaned.



