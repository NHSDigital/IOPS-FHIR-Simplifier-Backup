## How to construct clinical coded structures

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page is used to describe how to create clinical structures such as allergy lists.

This page should describe what the clinical structure is and list the structures used by this specification.

This page may link to core guidance where it exists, or document the specific guidance.

