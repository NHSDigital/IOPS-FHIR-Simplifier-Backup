## Transport

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This page is used where there is a need to describe the transport used, such as MESH.

It may be a link to other specifications, such as the MESH pages, or specific included guidance.

