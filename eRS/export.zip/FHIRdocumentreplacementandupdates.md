## FHIR document replacement and updates

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS Digital</div>

This is only applicable to FHIR documents and should explain the update semantics.


