### Example of UKCore-Patient-PreferredDispenserOrganization in a Patient resource

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:UKCore-Patient-Extension-PreferredDispenserOrganization-Exam}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:UKCore-Patient-Extension-PreferredDispenserOrganization-Exam}}
</div>