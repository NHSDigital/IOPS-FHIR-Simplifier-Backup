## Design overview


The PDS FHIR API provides an R4 FHIR Application Programming Interface to allow connecting systems to search and update Patient demographic information.

It provides a RESTful FHIR interface.

PDS FHIR API is intended to supersede the PDS HL7v3 and PDS SMSP interfaces for common use cases.
