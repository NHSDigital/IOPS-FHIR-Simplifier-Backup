## Release notes

* <a href="#1.2.0">1.2.0-Live</a> 
* <a href="#1.1.0">1.1.0-Live</a> 
* <a href="#1.0.0">1.0.0-Private Beta</a> 
* <a href="#0.1.0">0.1.0-Alpha</a>


## <a id="1.2.0"></a>v1.0.0
    Rework to Removal reason support after Information Governance clarifications
## <a id="1.1.0"></a>v1.0.0
    * PDS FHIR API Implementation guide updated to reflect API Live status
    * Additions drafted to support Removal reason
## <a id="1.0.0"></a>v1.0.0
    PDS FHIR API Implementation guide content aligned with IOPS proposed Implementation guide template
## <a id="0.1.0"></a>v0.1.0
    Initial draft of PDS FHIR API content
