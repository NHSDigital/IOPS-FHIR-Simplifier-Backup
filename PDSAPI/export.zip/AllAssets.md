### All Assets
