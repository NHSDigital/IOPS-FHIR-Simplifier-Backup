## Example of Extension-UKCore-OtherContactSystem for Patient Richard Smith

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:UKCore-Patient-Extension-OtherContactSystem-Example}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:UKCore-Patient-Extension-OtherContactSystem-Example}}
</div>