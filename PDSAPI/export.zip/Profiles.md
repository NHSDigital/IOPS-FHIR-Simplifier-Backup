## Profiles

The following UK Core Profiles are used by this implementation Guide.

* {{pagelink:profile-ukcore-patient}} <br/>
* {{pagelink:profile-ukcore-relatedperson}} <br/>
