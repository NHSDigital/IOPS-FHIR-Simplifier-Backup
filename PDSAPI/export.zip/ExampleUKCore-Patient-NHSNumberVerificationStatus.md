### Example of extension UKCore-Patient-NHSNumberVerificationStatus

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:UKCore-Patient-Extension-NHSNumberVerificationStatus-Example}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:UKCore-Patient-Extension-NHSNumberVerificationStatus-Example}}
</div>