## FHIR Document Bundle

The first entry will contain a Composition resource with the document data in sections.

Further entires will contain a Patient, Practitoner and PractitionRole resource.

<div class="summary-structure-img">
{{render:summary-care-record-resource-structure}}
</div>