##### ValueSet-SCR-AlertType

{{render:https://fhir.nhs.uk/ValueSet/SCR-AlertType}}