##### CodeSystem-SCR-ACSPermission

{{render:https://fhir.nhs.uk/CodeSystem/SCR-ACSPermission}}