## Overview


This implementation guide details the creation of a Summary Care Record upload document in a FHIR format, that may be supplemented with coded entries that relate to COVID-19


