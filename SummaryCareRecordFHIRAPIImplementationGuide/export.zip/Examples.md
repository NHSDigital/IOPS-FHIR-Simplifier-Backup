## Examples


This page needs an overview of the examples section.


|Conformance|
|--
|API|M|
|DOCUMENT|M|
|MESSAGE|M|

|Audience| |
|--
|C|Clinical|N|
|B|Business|N|
|T|Technical Architect|N|
|F|FHIR |N|
|D|Developer|N|


