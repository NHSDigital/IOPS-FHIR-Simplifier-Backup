## Profiles

This project is using the profiles shown below.

|Profiles|
|--
|{{pagelink:Bundle}}|M|
|{{pagelink:Composition}}|M|
|{{pagelink:DocumentReference}}|M|
|{{pagelink:Patient}}|M|
|{{pagelink:Practitioner}}|M|
|{{pagelink:PractitionerRole}}|M|
|{{pagelink:Organization}}|O|
|{{pagelink:Observation}}|O|
|{{pagelink:Encounter}}|O|
|{{pagelink:Procedure}}|O|
|{{pagelink:Immunization}}|O|
|{{pagelink:Communication}}|O|
|{{pagelink:ImmunizationRecommendation}}|O|
|{{pagelink:SCR-Alert-AuditEvent}}|M|