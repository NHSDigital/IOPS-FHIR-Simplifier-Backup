## Build

This section demonstrates how to construct a Composition & coded entries, as well as mappings from HL7v3 to FHIR construucts