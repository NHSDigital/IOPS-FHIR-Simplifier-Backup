## Downloads

This page gives a link to download the FHIR assets as a downloadable package. It may be specific to the specification or be a snap shot of the UK Core FHIR assets.

https://simplifier.net/packages/uk.core.r4/1.1.0