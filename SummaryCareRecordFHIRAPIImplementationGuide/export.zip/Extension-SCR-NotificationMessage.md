##### Extension-SCR-NotificationMessage

| Conformance url |
|--
| https://fhir.nhs.uk/StructureDefinition/Extension-SCR-NotificationMessage | 

<br>

<div class="tab">
<button class="tablinks active" onclick="openTab(event, 'Structure')">Structure</button>
<button class="tablinks" onclick="openTab(event, 'Examples')">Examples</button>
</div>
<div id="Structure" class="tabcontent" style="display:block">
  <h3>Structure</h3>
  from {{link:https://fhir.nhs.uk/StructureDefinition/SCR-Alert-AuditEvent}} <br><br>
  {{tree: extensionscrnotificationmessage, diff}}
</div>
<div id="Examples" class="tabcontent">
  <h3>Examples</h3>
  {{pagelink:extension-scr-notificationmessageexample}}
</div>