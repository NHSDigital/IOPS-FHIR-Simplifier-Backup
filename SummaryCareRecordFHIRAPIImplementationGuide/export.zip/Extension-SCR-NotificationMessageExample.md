### Extension-SCR-NotificationMessage Example

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
</div>
<div id="JSON" class="tabcontent" style="display:block">
  {{json:auditevent-example-duplicate-2}}
</div>
