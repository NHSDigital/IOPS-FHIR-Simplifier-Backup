## Glossary

A glossary of common terms and abbreviations used in this Implementation Guide can be found on the [Health Developer Network](https://digital.nhs.uk/developer/guides-and-documentation/glossary-of-developer-terms).