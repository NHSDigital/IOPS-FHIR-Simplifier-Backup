##### CodeSystem-SCR-AlertType

{{render:https://fhir.nhs.uk/CodeSystem/SCR-AlertType}}