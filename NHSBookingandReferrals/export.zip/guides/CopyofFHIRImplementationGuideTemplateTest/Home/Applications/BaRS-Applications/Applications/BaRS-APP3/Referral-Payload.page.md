---
topic: APP3-ReferralPayload
---

## {{page-title}}

### Payload for a Validation Request, using Service Request

This payload is used to transmit all the necessary information that is required for a CAS to accept a patient referred into their service.