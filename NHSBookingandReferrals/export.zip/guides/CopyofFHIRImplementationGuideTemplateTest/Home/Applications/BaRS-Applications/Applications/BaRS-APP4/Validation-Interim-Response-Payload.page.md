---
topic: APP4-ValidationInterimResponsePayload
---

## {{page-title}}

### Payload for a Validation Interim Response, using Service Request