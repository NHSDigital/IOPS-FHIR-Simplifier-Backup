---
topic: APP4-ValidationPayload
---

## {{page-title}}

### Payload for a Validation Request, using Service Request

This payload is used to transmit all the necessary information that is required for CAS to accept a patient referred into their service for validation.