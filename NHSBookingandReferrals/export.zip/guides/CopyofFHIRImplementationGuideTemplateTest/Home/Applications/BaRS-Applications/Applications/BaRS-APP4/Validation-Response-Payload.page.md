---
topic: APP4-ValidationResponsePayload
---

## {{page-title}}

### Payload for a Validation Response, using Service Request

This payload is used to transmit all the necessary information that is required for a CAS to accept a patient referred into their service.

