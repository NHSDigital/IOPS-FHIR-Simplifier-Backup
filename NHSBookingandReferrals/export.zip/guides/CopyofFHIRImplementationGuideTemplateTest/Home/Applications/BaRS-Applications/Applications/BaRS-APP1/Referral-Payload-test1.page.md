## {{page-title}}

<div class="tab">  
  <button class="tablinks" onclick="openTab(event, 'Message Bundle')">Message Bundle</button>
  <button class="tablinks" onclick="openTab(event, 'Service Request')">Service Request</button>
  <button class="tablinks" onclick="openTab(event, 'Healthcare Service')">Healthcare Service</button>
  <button class="tablinks" onclick="openTab(event, 'Encounter')">Encounter</button>
  <button class="tablinks" onclick="openTab(event, 'Care Plan')">Care Plan</button>
  <button class="tablinks" onclick="openTab(event, 'Patient')">Patient</button>
  <button class="tablinks" onclick="openTab(event, 'Practitioner Role')">Practitioner Role</button>
  <button class="tablinks" onclick="openTab(event, 'Practitioner')">Practitioner</button>
  <button class="tablinks" onclick="openTab(event, 'Organization')">Organization</button>
  <button class="tablinks" onclick="openTab(event, 'Medication Statement')">Medication Statement</button>
  <button class="tablinks" onclick="openTab(event, 'Allergy Intolerance')">Allergy Intolerance</button>
  <button class="tablinks" onclick="openTab(event, 'Flag')">Flag</button>
  <button class="tablinks" onclick="openTab(event, 'Questionnaire Response')">Questionnaire Response</button>
  <button class="tablinks" onclick="openTab(event, 'Observation')">Observation</button>
  <button class="tablinks" onclick="openTab(event, 'Consent')">Consent</button>
</div>

<div id="Message Bundle" class="tabcontent">
  <h3>Message Bundle</h3>

</div>

<div id="Service Request" class="tabcontent">
  <h3>Service Request</h3>

</div>

<div id="Healthcare Service" class="tabcontent"  style="display:block">
  <h3>Healthcare Service</h3>

</div>

<div id="Encounter" class="tabcontent">
  <h3>Encounter</h3>
     
</div>

<div id="Care Plan" class="tabcontent">
  <h3>Care Plan</h3>
     
</div>

<div id="Patient" class="tabcontent">
  <h3>Patient</h3>
     
</div>

<div id="Practitioner Role" class="tabcontent">
  <h3>Practitioner Role</h3>
     
</div>

<div id="Practitioner" class="tabcontent">
  <h3>Practitioner</h3>
     
</div>

<div id="Organization" class="tabcontent">
  <h3>Organization</h3>
     
</div>

<div id="Medication Statement" class="tabcontent">
  <h3>Medication Statement</h3>
     
</div>

<div id="Allergy Intolerance" class="tabcontent">
  <h3>Allergy Intolerance</h3>
     
</div>

<div id="Flag" class="tabcontent">
  <h3>Flag</h3>
     
</div>

<div id="Questionnaire Response" class="tabcontent">
  <h3>Questionnaire Response</h3>
     
</div>

<div id="Observation" class="tabcontent">
  <h3>Observation</h3>
     
</div>

<div id="Consent" class="tabcontent">
  <h3>Consent</h3>
     
</div>


