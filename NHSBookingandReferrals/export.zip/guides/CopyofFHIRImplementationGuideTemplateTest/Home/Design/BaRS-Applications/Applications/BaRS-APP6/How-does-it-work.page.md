---
topic: APP6-HowDoesItWork
---

## {{page-title}}