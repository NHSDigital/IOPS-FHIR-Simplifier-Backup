### Booking Receiver 

- Provide Slots for a specific service 
- Create Booking 
- Cancel Booking 
- Accept Rebook request (two open Bookings during this routine)

<br>
