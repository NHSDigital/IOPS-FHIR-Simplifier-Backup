### Booking Sender 

- Request Slots for a specific service
- Make Booking request
- Cancel Booking request 
- Make Rebook request (two open Bookings during this routine)

<br>