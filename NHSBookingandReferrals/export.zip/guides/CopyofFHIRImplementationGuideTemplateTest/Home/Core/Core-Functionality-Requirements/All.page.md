### All

- Provide Capability Statement 
- Read and interpret Capability State 
- Provide Message Definition(s) for a specific service
- Read and interpret Message Definition(s) for a specific service 

<br>