## Initial Request

The X-Correlation-ID is a conversation ID for this Encounter or Case. In our initial request both IDs are supplied by the original sender. 

![BaRS FHIR API end-to-end process](https://raw.githubusercontent.com/NHSDigital/booking-and-referral-media/master/src/images/TransactionIntegrity/Initial-Request-1.0.0.svg)

<br>
<hr>