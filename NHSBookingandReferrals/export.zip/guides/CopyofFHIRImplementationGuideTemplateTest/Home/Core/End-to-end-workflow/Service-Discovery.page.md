## Service discovery 

For a sender making a booking or referral, the first step is to establish a service (including the identifier) to send to. This can be achieved by using national or local service directories or preconfigured services, where a sender only ever sends to a handful of endpoints. The service identifier is all the sender requires to engage with a service which supports BaRS. {{pagelink:Home/Helpandsupport, text:Contact us}}  if you need further information about service discovery.

<hr>
<br>