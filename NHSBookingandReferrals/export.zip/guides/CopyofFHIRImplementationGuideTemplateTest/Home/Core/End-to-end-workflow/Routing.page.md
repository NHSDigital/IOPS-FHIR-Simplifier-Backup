## {{page-title}}

| Header                 | Requirement            | Description                                                  | Value                      |
|------------------------|------------------------|--------------------------------------------------------------|----------------------------|
| NHSD-Target-Identifier | Required by the sender | Allows BaRS to route the message to the appropriate endpoint | Base64 encoded JSON object |

<hr>
<br>