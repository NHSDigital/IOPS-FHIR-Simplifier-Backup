---
topic: core-NFR
---

## {{page-title}}

The following non functional requirements apply to all APIs designed to receive requests from BaRS. This includes sender systems receiving asynchronous responses and feedback, as well as receiving systems. All items listed below will be adhered to.

<br>
<hr>