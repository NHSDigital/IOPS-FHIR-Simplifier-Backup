## Frameworks

A mix of data exchange frameworks are employed by BaRS to support different workflows.

<br>
<hr>