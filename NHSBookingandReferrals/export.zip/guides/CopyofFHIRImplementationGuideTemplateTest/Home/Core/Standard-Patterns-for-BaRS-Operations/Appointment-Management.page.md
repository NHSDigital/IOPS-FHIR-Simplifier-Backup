## {{page-title}}

### Baseline operations:

* Get Slot/s
* Get Appointment/s
* Create appointment
* Update Appointment

### Appointment Management Workflows or standard patterns

Appointment management workflows combine the baseline operations to support an operational outcome

Workflows:

* Book Appointment  
* Ammend appointment
  including cancel appointment and re-book appointment
* View appointment

