---
topic: CORE-ReferralCancelPayload
---

## {{page-title}}
 

