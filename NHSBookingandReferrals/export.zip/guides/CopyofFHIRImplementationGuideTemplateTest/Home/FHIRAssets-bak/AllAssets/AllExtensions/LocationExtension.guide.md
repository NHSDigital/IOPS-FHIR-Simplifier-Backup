## {{page-title}}

{{tree:https://fhir.nhs.uk/StructureDefinition/LocationExtension, snapshot}}