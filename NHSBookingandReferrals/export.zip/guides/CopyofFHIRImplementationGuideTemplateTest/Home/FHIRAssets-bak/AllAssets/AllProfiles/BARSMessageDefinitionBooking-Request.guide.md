## {{page-title}}

{{xml:https://fhir.nhs.uk/MessageDefinition/bars-message-booking-request}}