## {{page-title}}

{{render:https://fhir.nhs.uk/CodeSystem/consent-categories-bars}}