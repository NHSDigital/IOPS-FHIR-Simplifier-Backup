## {{page-title}}

{{render:https://fhir.nhs.uk/CodeSystem/pathways-sg-codes, snapshot}}