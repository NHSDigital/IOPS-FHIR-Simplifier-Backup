## CapabilityStatements

A Capability Statement documents a set of capabilities (behaviors) of a FHIR Server or Client for a particular version of FHIR that may be used as a statement of actual server functionality or a statement of required or desired server implementation.

{{xml:45bcbe62-718b-4874-a68c-b0fe39a76cf5}}