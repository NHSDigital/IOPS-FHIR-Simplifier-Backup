
## FHIR Assets
</br>

This is a reference section providing information on a number of FHIR assests used by the booking and referral standard. The complete directory of FHIR assets can be found on the simplifier project page <a href="https://simplifier.net/NHSBookingandReferrals/~introduction" target="_blank">here</a>

{{index:current}}

</br>

