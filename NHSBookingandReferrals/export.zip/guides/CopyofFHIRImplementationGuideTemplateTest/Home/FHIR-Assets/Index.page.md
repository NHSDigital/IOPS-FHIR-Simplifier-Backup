---
topic: fhir_assets
---

## {{page-title}}

</br>

The complete directory of FHIR assets can be found on <a href="https://simplifier.net/NHSBookingandReferrals/~introduction" target="_blank">the simplifier project page</a>
