## {{page-title}}

These payload definitions can be used to develop your payload bundle.

Booking - Request

{{pagelink:Home/Build/PayloadDefinitions/All-Payloads/BARS-Message-Definition-ServiceRequest---Request-Referral.page.md,text:ServiceRequest - Request Referral}}

ServiceRequest - Request Validation

ServiceRequest - Response Referral

ServiceRequest - Response Validation Full

ServiceRequest - Response Validation Interim

<hr>

Diagram showing the links between the payload definitions:

{{render:CapabilityStatementflows.drawio}}