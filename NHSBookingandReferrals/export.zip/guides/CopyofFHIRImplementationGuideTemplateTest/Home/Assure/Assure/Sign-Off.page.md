## {{page-title}}

All sections of the SCAL must have the status of '**Approved**' to complete assurance.
Solution Assurance will provide a Technical Conformance Certificate (TCC), via email, to the named individual in the SCAL, at which point the solution is deemed fit to progress to a Live environment. Those involved in the deployment of the solution can use the TCC to request access to onboard the Production environment as part of their official **Connection Agreement**.
