---
topic: help
---

## Help and support

For any queries or feedback about any aspect of BaRS including support requests contact the BaRS team [here](https://digital.nhs.uk/services/booking-and-referral-standard/enquiry-form).

For further information and resouces regarding the FHIR standard see the [FHIR website](http://hl7.org/fhir/overview-dev.html).