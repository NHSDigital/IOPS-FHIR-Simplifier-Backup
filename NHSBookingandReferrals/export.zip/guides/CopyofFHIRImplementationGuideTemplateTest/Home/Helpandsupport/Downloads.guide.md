## Downloads

This page gives a link to download the FHIR assets as a downloadable package. It may be specific to the specification or be a snapshot of the UK Core FHIR assets.

BARS Package: https://simplifier.net/packages/uk.nhsdigital.bars.r4/

BARS Project Resources: https://simplifier.net/nhsbookingandreferrals