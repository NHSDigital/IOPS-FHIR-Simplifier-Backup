## {{page-title}}

Once in Production and running as business-as-usual (BAU), should an issue with the solution arise, service providers will be expected to follow their existing support processes with their supplier. After investigation, if the issue is thought to lie with the BaRS API or a third party supplier an incident can be raised with the National Service Desk - <ssd.nationalservicedesk@nhs.net> - who will involve the BaRS Programme, if required.
