## {{page-title}}

<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;}
.tg td{border-style:solid;border-width:0px;font-family:Arial, sans-serif;font-size:14px;overflow:hidden;
  padding:10px 5px;word-break:normal;}
.tg th{border-style:solid;border-width:0px;font-family:Arial, sans-serif;font-size:14px;font-weight:normal;
  overflow:hidden;padding:10px 5px;word-break:normal;}
.tg .tg-6xd7{background-color:#B4C6E7;border-color:inherit;font-weight:bold;text-align:center;vertical-align:bottom}
.tg .tg-l53b{background-color:#D9E1F2;border-color:inherit;font-weight:bold;text-align:left;vertical-align:bottom}
.tg .tg-mt5p{background-color:#B4C6E7;border-color:inherit;font-weight:bold;text-align:left;vertical-align:bottom}
.tg .tg-rj2t{background-color:#B4C6E7;border-color:inherit;font-weight:bold;text-align:center;vertical-align:middle}
.tg .tg-81ua{background-color:#B4C6E7;border-color:inherit;text-align:left;vertical-align:bottom}
.tg .tg-9pwo{background-color:#D9E1F2;border-color:inherit;text-align:left;vertical-align:bottom}
.tg .tg-yttn{background-color:#92D050;border-color:inherit;text-align:left;vertical-align:bottom}
.tg .tg-za14{border-color:inherit;text-align:left;vertical-align:bottom}
</style>
<table class="tg">
<thead>
  <tr>
    <th class="tg-mt5p">Product</th>
    <th class="tg-mt5p"> </th>
    <th class="tg-6xd7" colspan="3">BaRS Core</th>
    <th class="tg-6xd7" colspan="3">BaRS Implementation Guide</th>
  </tr>
</thead>
<tbody>
  <tr>
    <td class="tg-81ua"> </td>
    <td class="tg-l53b">Release</td>
    <td class="tg-9pwo">1.0.0-alpha</td>
    <td class="tg-9pwo">1.0.0-beta</td>
    <td class="tg-9pwo">1.0.0</td>
    <td class="tg-9pwo">1.0.0-alpha</td>
    <td class="tg-9pwo">1.0.0-beta</td>
    <td class="tg-9pwo">1.0.0</td>
  </tr>
  <tr>
    <td class="tg-rj2t" rowspan="3">CAS to ED</td>
    <td class="tg-9pwo">1.0.0-alpha</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0-beta</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0</td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
  </tr>
  <tr>
    <td class="tg-rj2t" rowspan="3">111 to UTC</td>
    <td class="tg-9pwo">1.0.0-alpha</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0-beta</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0</td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
  </tr>
  <tr>
    <td class="tg-rj2t" rowspan="3">111 Online</td>
    <td class="tg-9pwo">1.0.0-alpha</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0-beta</td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
  </tr>
  <tr>
    <td class="tg-9pwo">1.0.0</td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-za14"> </td>
    <td class="tg-yttn"> </td>
  </tr>
</tbody>
</table>

<hr>
<br>