## Releases

This section contains the release notes for the various elements of the booking and referral standard. In the table below you will find information about each element and links the the detailed change logs.

