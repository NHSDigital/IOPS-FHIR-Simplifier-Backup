---

topic: trn-api

---

<a href="#" onclick="history.back()">back</a>

## BaRS API Spec Change Log
<br>
This page will list all updates to the BaRS API Specification. 
<br>
<br>
<div class="imgHandshake">{{render:handshake}}</div> &nbsp; - Indicates a change inspired by provider or supplier feedback.
<p>

Each section will reference only changes for its specific version.
<hr>

