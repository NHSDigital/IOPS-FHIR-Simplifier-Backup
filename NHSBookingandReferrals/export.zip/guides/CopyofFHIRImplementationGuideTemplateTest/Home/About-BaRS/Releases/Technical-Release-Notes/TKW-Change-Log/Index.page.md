---
topic: trn-tkw
---

<a href="#" onclick="history.back()">back</a>

## {{page-title}}

<br>
This page will list all general improvements for BaRS. 
<br>
<br>
<div class="imgHandshake">{{render:handshake}}</div> &nbsp; - Indicates a change inspired by provider or supplier feedback.
<p>
<hr>