---
topic: trn-app6
---
<a href="#" onclick="history.back()">back</a>

## Referrals from an AST Computer Aided Dispatch system (CAD) to an AST CAD (Application 6) Change Log

<br>
This page will list all updates to BaRS Application 6
<br>

<div class="imgHandshake">{{render:handshake}}</div> &nbsp; - Indicates a change inspired by provider or supplier feedback.
<p>


|Key                                                            | Description                            | 
|---------------------------------------------------------------|----------------------------------------|
|<mark style="background-color: LightGreen">non-breaking</mark> |Non-breaking changed introduced to the standard since the last release  |
|<mark style="background-color: #ff8080">breaking</mark>        |Breaking changed introduced to the standard since the last release |
|<mark style="background-color: Yellow">correction</mark>       |Correction to the standard since the last release |