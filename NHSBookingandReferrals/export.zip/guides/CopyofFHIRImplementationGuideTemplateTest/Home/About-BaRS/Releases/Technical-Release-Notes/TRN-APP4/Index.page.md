---
topic: trn-app4
---

<a href="#" onclick="history.back()">back</a>

## Validation into CAS (application 4) Change Log

<br>
This page will list all updates to the BaRS Application 4. 
<br>
<br>
<div class="imgHandshake">{{render:handshake}}</div> &nbsp; - Indicates a change inspired by provider or supplier feedback.
<p>


|Key                                                            | Description                            | 
|---------------------------------------------------------------|----------------------------------------|
|<mark style="background-color: LightGreen">non-breaking</mark> |Non-breaking changed introduced to the standard since the last release  |
|<mark style="background-color: #ff8080">breaking</mark>        |Breaking changed introduced to the standard since the last release |
|<mark style="background-color: Yellow">correction</mark>       |Correction to the standard since the last release |