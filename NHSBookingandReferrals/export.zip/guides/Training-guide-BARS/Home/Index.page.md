# {{page-title}} 
{{index:root}}

The first step is to create your folders and pages by using the icons on the far left.

The Simplifier guide editor documentation can be found here: https://docs.fire.ly/projects/Simplifier/simplifierIGeditor.html

This guide is for testing purposes, you can add/delete and configure as you like to learn the features. It's visibility has been set to "private" within the NHS Digital domain.

|Heading 1|Heading 2| Heading 3|
|-
|content|content|content|
|content|content|content|

<details>
  <summary><b>> Epcot Center</b></summary>
  <p>Epcot is a theme park at Walt Disney World Resort featuring exciting attractions, international pavilions, award-winning fireworks and seasonal special events.</p>
</details>

<details>
  <summary><b>> Epcot Center 2</b></summary>
  <p>Epcot is a theme park at Walt Disney World Resort featuring exciting attractions, international pavilions, award-winning fireworks and seasonal special events.</p>
</details>