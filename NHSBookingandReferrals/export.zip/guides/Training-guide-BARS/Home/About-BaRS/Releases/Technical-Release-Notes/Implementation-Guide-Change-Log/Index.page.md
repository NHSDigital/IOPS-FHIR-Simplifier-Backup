---
topic: trn-General
---

<a href="#" onclick="history.back()">back</a>

## General Improvements Change Log
<br>
This page will list all general improvements for BaRS. 
<br>
<br>
<div class="imgHandshake">{{render:handshake}}</div> &nbsp; - Indicates a change inspired by provider or supplier feedback.
<p>
<hr>