## {{page-title}}

First page

<tabs>
      <tab title="Overview">
            {{tree:http://hl7.org/fhir/StructureDefinition/Patient}}
      </tab>
      <tab title="Xml" active="true">
            {{xml:http://hl7.org/fhir/StructureDefinition/Patient}}
      </tab>
</tabs>