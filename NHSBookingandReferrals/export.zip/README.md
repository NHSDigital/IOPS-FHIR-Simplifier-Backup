# NHSDigital-FHIR-BookingAndReferrals
FHIR Assets for BaRS project

## Main Branch Status

FHIR Validation with Terminology Checks 

 [![NHSDigital IOPS Validation)](https://github.com/NHSDigital/NHSDigital-FHIR-BookingAndReferrals/actions/workflows/terminology.yml/badge.svg)](https://github.com/NHSDigital/NHSDigital-FHIR-BookingAndReferrals/actions/workflows/terminology.yml)
