## Downloads

<br />
<table class="regular assets">
<thead>
<tr>
<th>Current Release Package</th>
<th></th>
</tr>
</thead>
<tbody>
<tr>
<td>Package</td>
<td>TBC</td>
</tr>
<tr>
<td>Version</td>
<td>1.0.0</td>
</tr>
<tr>
<td>IG Package Url</td>
<td><a href="TBC">TBC</a></td>
</tr>
</tbody>
</table>