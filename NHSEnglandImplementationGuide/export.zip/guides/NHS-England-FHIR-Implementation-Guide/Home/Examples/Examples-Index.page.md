## {{page-title}}

<br />
<table class="regular assets">
<tr>
<th>Programmes</th>
<th>Description</th>
</tr>

<tr>
<td cosplan="3"><a href="https://simplifier.net/guide/Female-Genital-Mutilation-Implementation-Guide2/Home/Build/Examples?version=current">Examples-Female-Genital-Mutilation (FGM)</a></td>

<td>Various Examples to illustrate the outcome of an attempted system operation on flag status, error or warning codes in response to a request.</td>
</tr>

<tr>
<td cosplan="3"><a href="https://simplifier.net/guide/Child-Protection---Information-Sharing--CP-IS--API-Producer-Impl/Home/Examples?version=current">Examples-Child-Protection -Information-Sharing (CP-IS)</a></td>

<td>Examples to illustrate the outcome of an attempted system operation on child protection information status, error or warning codes in response to a request.</td>
</tr>

</table>