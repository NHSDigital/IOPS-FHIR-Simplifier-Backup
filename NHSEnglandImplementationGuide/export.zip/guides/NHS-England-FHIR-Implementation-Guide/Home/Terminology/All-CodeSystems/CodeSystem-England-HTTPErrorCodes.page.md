---
subject: https://fhir.nhs.uk/CodeSystem/http-error-codes
issue: CodeSystem-England-HTTPErrorCodes
---
## England HTTP Error Codes

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
