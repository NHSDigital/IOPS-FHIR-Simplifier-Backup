---
subject: https://digital.nhs.uk/services/organisation-data-service/CodeSystem/ODSRelationship
issue: CodeSystem-England-ODSRelationship
---
## England ODS Relationship


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
