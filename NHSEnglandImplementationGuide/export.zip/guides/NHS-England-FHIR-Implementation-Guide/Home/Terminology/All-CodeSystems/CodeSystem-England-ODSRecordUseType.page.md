---
subject: https://fhir.nhs.uk/England/CodeSystem/England-ODSRecordUseType
issue: CodeSystem-England-ODSRecordUseType
---
## England ODS Record Use Type


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
