---
subject: https://fhir.nhs.uk/CodeSystem/message-events-bars
issue: CodeSystem-England-MessageEventsBARS
---
## England Message Events BARS

{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
