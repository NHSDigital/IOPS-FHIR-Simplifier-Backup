---
subject: https://fhir.nhs.uk/England/CodeSystem/England-ODSDateTime
issue: CodeSystem-England-ODSDateTime
---
## England ODS Date Time


{{render:Home-Terminology-All-CodeSystems-CodeSystemTemplate}}
