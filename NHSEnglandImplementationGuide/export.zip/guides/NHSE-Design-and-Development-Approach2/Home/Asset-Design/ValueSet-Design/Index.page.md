# {{page-title}}

This section provides background information on metadata specific to the NHS England ValueSet resources.

Further information about the <a href="https://hl7.org/fhir/R4/valueset.html" Target="_blank">ValueSet resource</a> is available.

---
