# {{page-title}}

This section describes the approach taken for metadata relating to the resources used within the NHS England IG.

---
