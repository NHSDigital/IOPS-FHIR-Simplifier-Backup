## Awareness and Learning

This section gives access to material that has been previously shared with the FHIR Community for the purpose of engagement.

<table class="assets">
  <thead>
      <tr>
        <th width="15%">Presentations</th>
        <th width="10%">Published Date</th>
      </tr>
  </thead>
  <tbody>
    <tr>
        <td><a href="https://www.youtube.com/watch?v=QnRgQ_dvkqc" target="_blank">"Why you want to be on FHIR"</a> : A YouTube video presented by David Hay - Interop Summit</td>
        <td>24 Apr 2017</td>
    </tr>
    <tr>
        <td><a href="https://www.youtube.com/watch?v=BT17_5ROp3Q" target="_blank">"Clinicians on FHIR"</a> : A video presented by David Hay - Interop Summit</td>
        <td>14 Mar 2018</td>
    </tr>
   </tbody>
</table>
