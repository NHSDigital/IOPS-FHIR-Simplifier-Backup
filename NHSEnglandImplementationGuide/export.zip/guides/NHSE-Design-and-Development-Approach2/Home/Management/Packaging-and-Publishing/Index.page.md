## {{page-title}}

This guides follows through the creation and checking of the NHS England Simplifier packages

#### Prerequisites

Ensure that you have the following permissions:

- Simplifier Project – Admin
- GitHub Repository – Either Admin or as part of the GitHub IOPs Development Team
- A non standard NHS machine (Virtual or Developers)