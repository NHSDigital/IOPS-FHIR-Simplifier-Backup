## {{page-title}}

All proposed assets for C&TA Sprint 2 are found here:  <a>Clinical and Technical Assurance Sprint 2 Documentation Pack</a>