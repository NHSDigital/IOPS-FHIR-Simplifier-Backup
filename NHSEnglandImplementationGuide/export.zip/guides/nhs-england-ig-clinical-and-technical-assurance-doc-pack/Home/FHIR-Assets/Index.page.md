## {{page-title}}

All proposed assets for C&TA Sprint 2 are found here:  <a href='https://simplifier.net/guide/nhs-england-implementation-guide-stu1?version=current' target="_blank">NHS England Implementation Guide 1.1.0 - STU1-sprint-2-review</a>