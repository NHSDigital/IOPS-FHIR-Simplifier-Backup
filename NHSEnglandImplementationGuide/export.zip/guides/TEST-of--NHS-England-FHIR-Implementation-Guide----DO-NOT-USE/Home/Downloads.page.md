## Downloads


| Current Release Package |  |
|--
| Package | uk.nhsdigital.r4  | 
| Version | 2.8.0 |
| IG Package Url | [https://packages.simplifier.net/uk.nhsdigital.r4/-/uk.nhsdigital.r4-2.8.0.tgz](https://packages.simplifier.net/uk.nhsdigital.r4/-/uk.nhsdigital.r4-2.8.0.tgz) |

