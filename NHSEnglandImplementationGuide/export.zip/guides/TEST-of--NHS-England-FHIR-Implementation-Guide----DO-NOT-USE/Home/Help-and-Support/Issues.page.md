### Issues

A list of issues can be found on [NHS Digital IG Issues](https://simplifier.net/NHSDigital/~issues)

You will need a simplifier account to log or comment on issues.