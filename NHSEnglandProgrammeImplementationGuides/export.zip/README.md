# NHS-England-FHIR-Examples
This repository is maintained by [Interoperability Team](https://nhsd-confluence.digital.nhs.uk/pages/viewpage.action?spaceKey=IOPS&title=Interoperability+Standards). Any queries contact us via [email](interoperabilityteam@nhs.net).

This repository will be used to contain FHIR asset examples for NHS England Programme Implementation Guides [Simplifier project](https://simplifier.net/NHS-England-Programme-Implementation-Guides/~guides).
