## {{page-title}}

Usage:
- Composed of {{pagelink:CodeSystem-England-PeriodType}}
- Bound in {{pagelink:Extension-England-TypedPeriod}}

<br>

<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-ValueSets/ValueSet-England-PeriodType?version=1.1.0"  height="800px" width="100%"></iframe>