## {{page-title}}

Usage:
- Composed of {{pagelink:CodeSystem-England-ORDDateTime}}
- Bound in {{pagelink:Extension-England-DateTime}}

<br>

<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-ValueSets/ValueSet-England-TypedDateTime.page.md?version=current"  height="800px" width="100%"></iframe>