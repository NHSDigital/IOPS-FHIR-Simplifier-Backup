# {{page-title}}

The profile is provided for implementation guidance:
- it is not necessary to reference the profile in the Resource.meta. <!--Reference: {{pagelink:Home/Examples/Example---An-active.md}}-->



 ## Conformance Rules

Reference - {{pagelink:Home/Design/Data-mapping.page.md}}

<!--A searchset Bundle will be returned on the GET /Flag interaction ({{pagelink:Home/Design/Interactions.page.md}}). The Bundle will contain 0 or 1 Flag resource.-->




<iframe src="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/ProfilesandExtensions/Profile-UKCore-Organization?version=current" height="800px" width="100%"></iframe>



