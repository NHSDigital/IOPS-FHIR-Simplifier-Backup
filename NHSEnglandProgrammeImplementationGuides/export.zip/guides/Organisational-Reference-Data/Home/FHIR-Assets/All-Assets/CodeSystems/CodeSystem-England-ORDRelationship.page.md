## {{page-title}}

Usage:
- Context of use:  OrganisationAffiliation.code 
- NOTE: No codes are currently provided, and implementers will need to find these via an external site maintained by ODS.


<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-CodeSystems/CodeSystem-England-ORDRelationship.page.md?version=current" height="800px" width="100%"></iframe>