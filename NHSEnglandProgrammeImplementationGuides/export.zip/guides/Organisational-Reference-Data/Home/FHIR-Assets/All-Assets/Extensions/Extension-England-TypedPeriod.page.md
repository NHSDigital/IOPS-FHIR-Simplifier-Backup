## {{page-title}}

Usage:
- Context of use: Organization, OrganizationAffiliation, ExtensionEnglandOrganisationRole
- This extension has been created from an ORD use-case in which there is a requirement to hold data for Legal and Operational dates, although it is expected to be broader than ORD and can be used for other scenarios.
<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Profiles-and-Extensions/All-Extensions/Extension-England-TypedPeriod?version=1.1.0" height="800px" width="100%"></iframe>