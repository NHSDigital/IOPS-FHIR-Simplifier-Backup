## {{page-title}}

Usage:
- Context of use: Organization and OrganizationAffiliation
- This extension extends the Organization and the OrganizationAffiliation resources to support the exchange of information describing the specific business related date and/or time.
<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Profiles-and-Extensions/All-Extensions/Extension-England-DateTime.page.md?version=current" height="800px" width="100%"></iframe>