## {{page-title}}

Usage:
- Context of use: Organization
- This extension extends the Organization resource to support the NHS England requirement for additional information about organisational roles.
<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Profiles-and-Extensions/All-Extensions/Extension-England-OrganisationRole.page.md?version=current" height="800px" width="100%"></iframe>