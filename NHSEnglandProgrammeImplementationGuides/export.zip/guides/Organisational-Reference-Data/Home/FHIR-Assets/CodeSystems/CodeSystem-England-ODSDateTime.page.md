## {{page-title}}

Usage:
- Provides codes for {{pagelink:ValueSet-England-TypedDateTime}}
<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-CodeSystems/CodeSystem-England-ODSDateTime?version=1.1.0" height="800px" width="100%"></iframe>

---