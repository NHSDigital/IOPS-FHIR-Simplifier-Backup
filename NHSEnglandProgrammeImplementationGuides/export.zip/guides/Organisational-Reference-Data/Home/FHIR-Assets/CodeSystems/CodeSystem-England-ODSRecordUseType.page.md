## {{page-title}}

Usage:
- Context of use:  Organisation.type
<br>

<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-CodeSystems/CodeSystem-England-ODSRecordUseType?version=1.1.0" height="800px" width="100%"></iframe>

---