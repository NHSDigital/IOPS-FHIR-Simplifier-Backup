## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

The page lists the codesystems used by the ODS FHIR R4 API:

- {{pagelink:CodeSystem-England-ODSDateTime}}
- {{pagelink:CodeSystem-England-ODSOrganisationRole}}
- {{pagelink:CodeSystem-England-PeriodType}}
- {{pagelink:CodeSystem-England-ODSRecordClass}}
- {{pagelink:CodeSystem-England-ODSRecordUseType}}
- {{pagelink:CodeSystem-England-ODSRelationship}}