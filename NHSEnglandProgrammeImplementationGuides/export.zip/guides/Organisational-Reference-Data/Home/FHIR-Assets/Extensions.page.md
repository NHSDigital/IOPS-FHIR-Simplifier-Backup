## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

The page lists the extensions used by ORD FHIR R4 API:

- {{pagelink:Extension-England-TypedDateTime}}
- {{pagelink:Extension-England-OrganisationRole}}
- {{pagelink:Extensions/Extension-England-TypedPeriod}}