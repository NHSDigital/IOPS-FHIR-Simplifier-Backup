## {{page-title}}

The page lists the ValueSet used by CP-IS FHIR R4 API:

- {{pagelink:Home/FHIRAssets/AllAssets/Valuesets/ValueSet-England-FGMRemovalReason.page.md}}