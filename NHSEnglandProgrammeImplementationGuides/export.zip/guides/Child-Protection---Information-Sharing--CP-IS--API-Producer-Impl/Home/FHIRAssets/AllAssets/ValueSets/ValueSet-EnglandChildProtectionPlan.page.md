## {{page-title}}

Usage:
- Composed defined of SNOMED CT codes
- Used in {{pagelink:Home/FHIRAssets/AllAssets/Profiles/CareTeam.page.md}.category

<br>

<iframe src="https://simplifier.net/guide/nhs-england-fhir-implementation-guide/home/terminology/valueset/valueset-england-childprotectionplan.page.md?version=current"  height="800px" width="100%"></iframe>