## {{page-title}}

Usage:
- Composed of defined SNOMED CT codes
- Used in {{pagelink:Home/FHIRAssets/AllAssets/Profiles/CareTeam.page.md}}.category

<br>

<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/Home/Terminology/All-ValueSets?version=current#ValueSet-England-ChildProtectionPlan"  height="800px" width="100%"></iframe>