## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:22daadee-26e1-4d6a-9e6a-7f4af9b58877}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:22daadee-26e1-4d6a-9e6a-7f4af9b58877}}
</div>