## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:341572b4-24a8-11ee-be56-0242ac120002}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:341572b4-24a8-11ee-be56-0242ac120002}}
</div>