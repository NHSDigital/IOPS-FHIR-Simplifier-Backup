## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:c6a6a92a-8247-4250-b1c7-10cda16f0310}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:c6a6a92a-8247-4250-b1c7-10cda16f0310}}
</div>



