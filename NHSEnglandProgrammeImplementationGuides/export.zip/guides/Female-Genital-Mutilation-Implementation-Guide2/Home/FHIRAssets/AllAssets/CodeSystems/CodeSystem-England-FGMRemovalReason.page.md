## {{page-title}}

Usage:
- Provides codes for {{pagelink:ValueSet-England-FlagRemovalReason}}

<br>


<iframe src="https://simplifier.net/guide/nhs-england-implementation-guide-stu1/home/terminology/all-codesystems/codesystem-england-fgmremovalreason.page.md?version=current" height="800px" width="100%"></iframe>