# {{page-title}}

The profile is provided for implementation guidance:
- a returned OperationOutcome will not reference the profile in the Resource.meta. Reference: {{pagelink:Home/Build/Examples/Example---Invalid-NHS-Number.page.md}}

<br>


<iframe src="https://simplifier.net/guide/uk-core-implementation-guide-stu3-sequence/home/profilesandextensions/profile-ukcore-operationoutcome?version=current" frameBorder="0" height="800px" width="100%"></iframe>
