# {{page-title}}

The profile is provided for implementation guidance:
- it is not necessary to reference the profile in the Resource.meta. Reference: {{pagelink:Home/Build/Examples/Example---An-active-FGM-flag.page.md}}

 ## Conformance Rules

Reference - {{pagelink:Home/Design/Data-mapping.page.md}}


<iframe src="https://simplifier.net/guide/uk-core-implementation-guide-stu3-sequence/home/profilesandextensions/profile-ukcore-flag?version=current" height="800px" width="100%"></iframe>

