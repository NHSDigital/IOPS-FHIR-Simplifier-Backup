## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fas fa-exclamation-triangle"></i><b> Important:</b> This page is under development by NHS England</div>

The page lists the extensions used by FGM-IS FHIR R4 API:

- {{pagelink:Home/FHIRAssets/AllAssets/Extension/Extension-England-FlagRemovalReason.page.md}}