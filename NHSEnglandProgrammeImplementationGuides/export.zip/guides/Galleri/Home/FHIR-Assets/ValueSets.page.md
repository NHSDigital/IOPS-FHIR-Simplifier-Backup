## {{page-title}}

This specification makes use of SNOMED CT for coding data. Therefore no additional ValueSets are listed here.
