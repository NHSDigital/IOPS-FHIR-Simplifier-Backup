## {{page-title}}

## Usage:
- Context of use: DiagnosticReport
- Used to hold laboratory notes

<br>

<iframe src="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU3-Sequence/Home/ProfilesandExtensions/ExtensionLibrary?version=current#Extension-UKCore-Note" height="800px" width="100%"></iframe>

