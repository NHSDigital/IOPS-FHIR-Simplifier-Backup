# {{page-title}}

The profile is provided for implementation guidance:
- it is not necessary to reference the profile in the Resource.meta. 


 ## Conformance Rules

Reference - {{pagelink:Home/Design/Data-mapping.page.md}}

<iframe src="https://simplifier.net/guide/UKCoreImplementationGuideAssetsinDevelopment/Home/ProfilesandExtensions/ProfileUKCore-Bundle?version=current" height="800px" width="100%"></iframe>


