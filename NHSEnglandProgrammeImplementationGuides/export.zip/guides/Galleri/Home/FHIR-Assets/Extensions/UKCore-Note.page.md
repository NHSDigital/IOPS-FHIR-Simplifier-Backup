## {{page-title}}

## Usage:
- Context of use: DiagnosticReport
- Used to hold laboratory notes

<br>

<iframe src="https://simplifier.net/guide/uk-core-implementation-guide-stu3-sequence/Home/ProfilesandExtensions/ExtensionLibrary/Extension-UKCore-Note?version=1.7.0" height="800px" width="100%"></iframe>

