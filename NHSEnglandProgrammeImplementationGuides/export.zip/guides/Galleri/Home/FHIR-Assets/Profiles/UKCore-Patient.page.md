# {{page-title}}

The profile is provided for implementation guidance:
- it is not necessary to reference the profile in the Resource.meta. 

## Usage
The Patient resource is used to hold details of the patient who's same is being tested.

## Conformance Rules

Reference - {{pagelink:Home/Design/Data-mapping.page.md}}

<iframe src="https://simplifier.net/guide/uk-core-implementation-guide-stu3-sequence/home/profilesandextensions/profile-ukcore-patient?version=1.7.0" height="800px" width="100%"></iframe>



<hr class="thickline">