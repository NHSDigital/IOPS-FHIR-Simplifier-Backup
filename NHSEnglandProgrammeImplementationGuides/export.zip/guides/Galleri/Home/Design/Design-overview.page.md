## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>

The Galleri test results message allows GPs, and other interested parties, to receive the Galleri screening results in a FHIR format that conforms to the proposed pathology R4 guidance.
 
The Galleri screening results message uses a variety of FHIR resources that can be found on the {{pagelink:Home/FHIR-Assets/All-Assets}} page.

