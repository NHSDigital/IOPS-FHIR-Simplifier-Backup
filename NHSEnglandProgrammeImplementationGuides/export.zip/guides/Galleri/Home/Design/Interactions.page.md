## {{page-title}}

  <div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-warning"></i><b> Important:</b> This page is under development by NHS England</div>


### Message a Multi-cancer Early Detection Test Report

<br>
<br>

<br>
<br>

| Outcome         | Response                       |
| ----------- | ------------------------  |
| Record found       | SearchSet Bundle - {{pagelink:Home/Examples/Example---FGM-flag-found.page.md}}|
| No record found       | SearchSet Bundle - {{pagelink:Home/Examples/Example---FGM-flag-not-found.page.md}}|
| Error or validation failure      | OperationOutcome - {{pagelink:Home/Build/Errorhandling.page.md}}|

<br>


