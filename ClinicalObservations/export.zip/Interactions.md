## Interactions

The diagram below highlights one possible user story.

{{render:newsinteraction}}


Other user stories may include (but not limited to):

- A vital signs app to an Electronic Patient Record in a hospital.

- Ambulance to Emergency Department.

- Hospital to hospital patient transfers.

- Hospital look up of observations in GP systems. They are able to import the Vital signs observations from GP Systems to build a single record of observations around a patient, so there is a baseline and trends available to all. 

- Ambulance recording on remote devices and communicating to central ambulance record.

- GP to ambulance.