## ValueSets


This page lists the valuesets used for the Clinical Observations implementation. 

- {{pagelink:BodySite}}
- {{pagelink:ObservationMethod}}
- {{pagelink:ObservationType}}
- {{pagelink:VitalSignsObservationType}}
- {{pagelink:VitalSignObservationValue}}

