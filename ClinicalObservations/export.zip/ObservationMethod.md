##### ObservationMethod

{{render:https://fhir.hl7.org.uk/ValueSet/UKCore-ObservationMethod}}