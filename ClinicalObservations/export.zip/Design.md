## Design

* {{pagelink:Designoverview}} - the proposed FHIR design and FHIR resource model view
* {{pagelink:DataMapping}} - the FHIR elements used to encode the Clinical Observations Data Set data items


