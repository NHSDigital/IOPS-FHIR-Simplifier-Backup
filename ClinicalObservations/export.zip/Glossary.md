## Glossary

[Glossary of developer terms](https://digital.nhs.uk/developer/guides-and-documentation/glossary-of-developer-terms)