# FHIR-R4-CLINICAL-OBSERVATIONS

## Main Branch Status

FHIR Validation with Terminology Checks 

 [![NHSDigital IOPS Validation)](https://github.com/NHSDigital/FHIR-R4-CLINICAL-OBSERVATIONS/actions/workflows/validationcall.yml/badge.svg)](https://github.com/NHSDigital/FHIR-R4-CLINICAL-OBSERVATIONS/actions/workflows/validationcall.yml)
