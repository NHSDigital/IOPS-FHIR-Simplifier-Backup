## Score Chart Used Example

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:ScoreChartUsedObservation}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:ScoreChartUsedObservation}}
</div>