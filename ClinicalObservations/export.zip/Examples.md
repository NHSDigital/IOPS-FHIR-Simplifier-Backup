## Examples
This section gives examples, these are technical examples and have had no clinical review 
{{index:current}}