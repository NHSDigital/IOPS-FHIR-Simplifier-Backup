## PEWS Total Score With Observations Bundle Example

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:1b36355c-ee52-4d1a-ae06-45c6f08380td}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:1b36355c-ee52-4d1a-ae06-45c6f08380td}}
</div>