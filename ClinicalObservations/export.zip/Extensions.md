## Extensions

This implementation currently has no specific extensions and implementers may use any extension allowed for the utilised profiles from the [UK Core Extension Library](https://simplifier.net/guide/UKCoreDevelopment/ExtensionLibrary)