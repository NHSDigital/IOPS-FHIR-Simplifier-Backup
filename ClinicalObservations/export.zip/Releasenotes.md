## Release notes

### 2.0.0 Alpha ###
Updated the status to Alpha following discussion and agreement with first of types. This is now the initial release of the Clinical Observations FHIR R4 specification for NEWS2, NPEWS1 and Clinical Observations. 

---

### 2.0.0 Discovery ###
The initial release of the Clinical Observations FHIR R4 specification for NEWS2, which replaces the deprecated STU3 specifications.

---

### 1.0.n ###
The STU3 versions of NEWS2 now deprecated