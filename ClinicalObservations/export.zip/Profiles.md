## Profiles

This page lists the profiles used for the Clinical Observation implementation.


- {{pagelink:Bundle}} 
- {{pagelink:Organization}} 
- {{pagelink:Patient}} 
- {{pagelink:Practitioner}} 
- {{pagelink:PractitionerRole}}
- {{pagelink:Procedure}} 
- {{pagelink:Observation}}
- {{pagelink:VitalSignsObservation}} 