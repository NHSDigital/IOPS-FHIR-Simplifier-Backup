## {{page-title}}

Refer to the NHS Digital API catalogue entry for [GP Connect (Patient Facing) Prescriptions - FHIR API](https://digital.nhs.uk/developer/api-catalogue/gp-connect-patient-facing-prescriptions-fhir) details on example responses from the API.