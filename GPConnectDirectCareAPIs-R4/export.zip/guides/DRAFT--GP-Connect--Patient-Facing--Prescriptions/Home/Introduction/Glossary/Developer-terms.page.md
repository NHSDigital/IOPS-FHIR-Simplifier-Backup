## {{page-title}}

This guide uses a number of developer terms, details of which can be found in the NHS Digital [Glossary of developer terms](https://digital.nhs.uk/developer/guides-and-documentation/glossary-of-developer-terms).

---