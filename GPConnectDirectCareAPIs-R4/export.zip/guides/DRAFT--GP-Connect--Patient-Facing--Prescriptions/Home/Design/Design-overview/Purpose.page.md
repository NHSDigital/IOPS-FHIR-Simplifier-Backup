## {{page-title}}

To meet strategic objectives to improve access to GP Care, the (Patient Facing) Prescriptions Management FHIR API enables patients (via a consumer application) to view medications, order a repeat prescription, cancel their prescription requests and track the status of their prescription requests.
