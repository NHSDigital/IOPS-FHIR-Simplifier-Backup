## {{page-title}}

Allows the patient to view the status of a prescription order, currently in scope for this is pending, approved or rejected (with rejection reason). Once the prescription order has left the practitioner system (sent on to EPS) the API will no longer receive updates to status. Scope in the future will cover any additional statuses and interactions with EPS/ Pharmacy systems.

{{render:order_tracking_pm.png}}