## {{page-title}}

Allows the patient to send their prescription order to a location other than their nominated pharmacy as a one off. The use case for this would be if the patient is a distance away from their home or where the patient is aware that this prescription would be picked up outside of the normal opening hours of their nominated pharmacy.
