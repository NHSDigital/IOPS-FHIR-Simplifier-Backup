## {{page-title}}

Allows the patient to view their medication(s) (acute and repeat prescriptions) including current and historic. See also {{pagelink:Home/Build/How-to-request-a-new-prescription/Starting-with-Medication.page.md}}.

{{render:view_medication_pm.png}}
