## {{page-title}}

Retrieves a full list of all medications related to the patient, including current and historic medication for both repeat and acute prescriptions.
