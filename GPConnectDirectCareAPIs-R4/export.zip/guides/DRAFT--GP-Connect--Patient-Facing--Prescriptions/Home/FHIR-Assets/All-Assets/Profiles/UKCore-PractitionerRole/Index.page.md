## {{page-title}}

<!--// start of code snippet -->
<div>
    <ul class="nav nav-tabs" role="tablist">
      <li role="presentation" class="active">
        <a href="#profile-1" role="tab" data-toggle="tab">Profile</a>
      </li>
      <li role="presentation">
        <a href="#dictionary-1" role="tab" data-toggle="tab">Dictionary</a>
      </li>
    <li role="presentation">
        <a href="#example-1" role="tab" data-toggle="tab">Example</a>
      </li>
  </ul>
  </div>

  <!-- Tab panes -->
  <div class="tab-content snippet nhsd-!t-margin-bottom-6">
    <div role="tabpanel" class="tab-pane active" id="profile-1">
        {{tree:https://fhir.hl7.org.uk/StructureDefinition/UKCore-PractitionerRole}}
    </div>
    <div role="tabpanel" class="tab-pane" id="dictionary-1">
        {{dict:https://fhir.hl7.org.uk/StructureDefinition/UKCore-PractitionerRole}} 
    </div>
        <div role="tabpanel" class="tab-pane" id="example-1">
        {{json:e35f0382-ac2e-47f9-9164-afd7d6adf952}} 
    </div>
  </div>
</div>

---
