## {{page-title}}


### Optionality and Cardinality

Please refer to [Labels used within this guidance](https://simplifier.net/guide/gp-connect--patient-facing-services--prescriptions/home/introduction/how-to-use-this-implementation-guide/labels-used-within-this-guidance.page.md?version=current) and {{pagelink:Home/Introduction/How-to-use-this-implementation-guide}} for further details.