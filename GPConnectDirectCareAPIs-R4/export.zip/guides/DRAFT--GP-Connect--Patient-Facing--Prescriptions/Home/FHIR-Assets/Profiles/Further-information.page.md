## {{page-title}}


### Optionality and Cardinality

**Optionality** and **Cardinality**, please refer to the [Labels used within this guidance](https://simplifier.net/guide/gp-connect--patient-facing-services--prescriptions/home/introduction/how-to-use-this-implementation-guide/labels-used-within-this-guidance.page.md?version=current) as well as the information referred to in the {{pagelink:Home/Introduction/How-to-use-this-implementation-guide}} for further details