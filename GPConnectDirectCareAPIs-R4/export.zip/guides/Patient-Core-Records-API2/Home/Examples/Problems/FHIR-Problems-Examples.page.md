## {{page-title}}

### Access Record Structured FHIR examples for Problems.

### Request
Example of a call to return the following items from a patient's structured record:

* Problems

#### Request payload
```json
{
  "resourceType": "Parameters",
  "parameter": [
    {
      "name": "patientNHSNumber",
      "valueIdentifier": {
        "system": "https://fhir.nhs.uk/Id/nhs-number",
        "value": "9465701262"
      }
    },
    {
        "name": "includeProblems"
    },
  ]
}

```

### Response payload
```json
{
    "resourceType": "Bundle",
    "id": "219b7cb8-da9e-447a-b279-82be7a3299da",
    "meta": {
        "profile": [
            "https://fhir.nhs.uk/STU3/StructureDefinition/GPConnect-StructuredRecord-Bundle-1"
        ]
    },
    "type": "collection",
    "entry": [
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ListWarningCode-1",
                        "valueCode": "confidential-items"
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ListWarningCode-1",
                        "valueCode": "data-in-transit"
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "717711000000103",
                            "display": "Problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.056+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "note": [
                    {
                        "text": "Items excluded due to confidentiality and/or patient preferences. Patient record transfer from previous GP practice not yet complete; information recorded before 15-Oct-2020 may be missing."
                    }
                ],
                "entry": [
                    {
                        "item": {
                            "reference": "Condition/9569AEF5-9527-4F6A-8EFB-417D0AB3E6B6-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/3BC1331C-7C74-40D8-8576-0C990119514C-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/0DAFB800-AA02-446C-9A9B-5860E9ADA3E0-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/2BE35191-475E-4D5A-8CC8-EB769562B566-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/F6FCF37E-F5D9-46FB-B39A-F94C32A69B11-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/9A8BF064-43AC-462E-BB0A-AABD1FEF0B68-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/FACC8DEB-9D81-476D-AA42-B90F56FF1846-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/D92BE3A5-A8F5-472B-831F-455786BB4A9F-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/828198DE-51DC-412D-B407-8E3253D14A18-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/5EA6E5BC-96BF-403D-B4B2-3771F3791B7B-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/FBDBFCEA-B088-4EE0-AC53-B36647E878A1-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/D50E2934-E2C2-4C5C-8E79-294C7F79BD4A-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/160827C3-6CC2-4816-8DEE-4A234746FA7B-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/7499F1D6-5C58-43A0-8D0D-823CA7BD15B7-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2-PROB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Condition/82ACCC6C-D367-40B5-A4D3-ABA26E7363BD-PROB"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Patient",
                "id": "144A1A2E-B3B3-4A66-B33B-148A5B75959D",
                "meta": {
                    "versionId": "1624651194859004536",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Patient-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-RegistrationDetails-1",
                        "extension": [
                            {
                                "url": "preferredBranchSurgery",
                                "valueReference": {
                                    "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "extension": [
                            {
                                "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-NHSNumberVerificationStatus-1",
                                "valueCodeableConcept": {
                                    "coding": [
                                        {
                                            "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-NHSNumberVerificationStatus-1",
                                            "code": "01",
                                            "display": "Number present and verified"
                                        }
                                    ],
                                    "text": "Number present and verified"
                                }
                            }
                        ],
                        "system": "https://fhir.nhs.uk/Id/nhs-number",
                        "value": "9465701262"
                    }
                ],
                "name": [
                    {
                        "use": "official",
                        "family": "Meyers",
                        "given": [
                            "Yannis",
                            "Rafal"
                        ],
                        "prefix": [
                            "Mr"
                        ]
                    }
                ],
                "gender": "male",
                "birthDate": "1946-04-10",
                "address": [
                    {
                        "use": "home",
                        "type": "physical",
                        "line": [
                            "Roxton",
                            "West Marsh Lane",
                            "Barrow Haven"
                        ],
                        "city": "Barrow-Upon-Humber",
                        "district": "S Humberside",
                        "postalCode": "DN19 7HA"
                    }
                ],
                "generalPractitioner": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "managingOrganization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "9569AEF5-9527-4F6A-8EFB-417D0AB3E6B6-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Immunization/9569AEF5-9527-4F6A-8EFB-417D0AB3E6B6"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9569AEF595274F6A8EFB417D0AB3E6B6PROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2533976011"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "First diphtheria tetanus and five component acellular pertussis, haemophilus influenzae type b, inactivated polio vaccination"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414259000",
                            "display": "Administration of first dose of diphtheria and Haemophilus influenza B and five component acellular pertussis and inactivated poliomyelitis and tetanus vaccine",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "assertedDate": "2020-11-18T13:56:52.87+00:00",
                "asserter": {
                    "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                },
                "note": [
                    {
                        "text": "historical date\nhistorical date"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "3BC1331C-7C74-40D8-8576-0C990119514C-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/3BC1331C-7C74-40D8-8576-0C990119514C"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/47BE9D54-A8A0-46DA-A0A8-A51C794777FE"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "E4AA89361BF14A4BAD332A119C2BD6F83BC1331C7C7440D885760C990119514CPROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "system": "http://read.info/readv2",
                            "code": "E205.11",
                            "display": "Nervous exhaustion",
                            "userSelected": true
                        },
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "677031000006115"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Nervous exhaustion"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "78667006",
                            "display": "Dysthymia"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2006-04-25",
                "assertedDate": "2021-01-12T13:18:55.157+00:00",
                "asserter": {
                    "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "0DAFB800-AA02-446C-9A9B-5860E9ADA3E0-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "AllergyIntolerance/0DAFB800-AA02-446C-9A9B-5860E9ADA3E0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D0DAFB800AA02446C9A9B5860E9ADA3E0PROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "442112014"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Latex allergy"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "300916003",
                            "display": "Allergy to latex",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2019",
                "assertedDate": "2021-03-26T11:15:05.483+00:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "2BE35191-475E-4D5A-8CC8-EB769562B566-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/2BE35191-475E-4D5A-8CC8-EB769562B566"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/F6FCF37E-F5D9-46FB-B39A-F94C32A69B11-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D2BE35191475E4D5A8CC8EB769562B566PROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "961911000006112"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Syncopal episodes (fainting)/dizziness"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "961911000006108",
                            "display": "Syncopal episodes (fainting)/dizziness",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-04-08",
                "abatementDateTime": "2021-07-15",
                "assertedDate": "2021-04-08T17:26:10.21+01:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "patient reports these have been ongoing for 3 to 4 weeks\n(Grouped with Breathless - moderate exertion)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "F6FCF37E-F5D9-46FB-B39A-F94C32A69B11-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/F6FCF37E-F5D9-46FB-B39A-F94C32A69B11"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/534E8774-16A4-48CB-A187-2A7683839A24"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/79649222-3B68-4905-A4DC-7410D29A4565-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Immunization/E151BC23-8CC1-479F-A8EC-5CB9998BA1E5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/C94B1851-0AF6-4DE9-A405-63B4C8BA2205"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/20063759-2032-4474-AA6D-07472A213261"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/FACC8DEB-9D81-476D-AA42-B90F56FF1846-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/2BE35191-475E-4D5A-8CC8-EB769562B566-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DF6FCF37EF5D946FBB39AF94C32A69B11PROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "252385016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "161939006",
                            "display": "Breathless - moderate exertion",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-09-15",
                "assertedDate": "2021-03-26T16:34:39.213+00:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "The descriptive text includes special characters!'Â£$%^7*()-={}][|\":/.#@, -~ (Grouped with Chest pain)\nThe descriptive text includes special characters!'Â£$%^7*()-={}][|\":/.,\n(Grouped with Chest pain)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "9A8BF064-43AC-462E-BB0A-AABD1FEF0B68-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/9A8BF064-43AC-462E-BB0A-AABD1FEF0B68"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/16CD05AC-02C7-4152-8445-CB54A59E3689"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/87114350-4E1E-48CA-A4B9-101F81E8FFF1"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/EB632755-18FA-42AD-A686-3BF03A2C01C6"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/8A2F05CC-4CFE-4E53-896A-18856AA44CC5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DFC4F8B8-FEA3-43A5-9794-2947C3046678"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/C31A4281-1659-4836-AC3E-F7BE648BB52C"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DAA52C30-A026-41CC-82B2-4990DA7AF022"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/9E12D923-66B4-44EB-9A84-6070AB7B1207"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/3F9B0582-3BCC-4E03-A36D-0A33A41C73F6"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "ReferralRequest/10BD3DCD-16BD-4FBC-BECF-0E70472E2B56"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/218164F4-6101-48E4-9AFE-1CD797644C29"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/9C621603-70B0-44A8-B0B1-7DEF38756D2D-PG1"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/2494D07E-DB8B-471E-9171-6F79BC2E9F43"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9A8BF06443AC462EBB0AAABD1FEF0B68PROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1215744012"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Hypertensive disorder"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "38341003",
                            "display": "Hypertension",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-01",
                "assertedDate": "2020-11-18T14:19:48.68+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                },
                "note": [
                    {
                        "text": "First entry with a lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repe\nFirst entry"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "FACC8DEB-9D81-476D-AA42-B90F56FF1846-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/FACC8DEB-9D81-476D-AA42-B90F56FF1846"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/828198DE-51DC-412D-B407-8E3253D14A18-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/F6FCF37E-F5D9-46FB-B39A-F94C32A69B11-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DFACC8DEB9D81476DAA42B90F56FF1846PROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "49966017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "29857009",
                            "display": "Chest pain",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-04",
                "abatementDateTime": "2020-12-02",
                "assertedDate": "2020-11-18T14:17:57.04+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                },
                "note": [
                    {
                        "text": "(Grouped with Ischaemic heart disease)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "D92BE3A5-A8F5-472B-831F-455786BB4A9F-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/D92BE3A5-A8F5-472B-831F-455786BB4A9F"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/679893BB-9C1C-4125-B765-3F511FCBF5CC-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "ProcedureRequest/CBD7D61A-19A2-4368-BF9A-387CCA0DA905"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/BA98DB56-0F48-4118-80C2-2D05BEAE2219"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/16CD05AC-02C7-4152-8445-CB54A59E3689"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/87114350-4E1E-48CA-A4B9-101F81E8FFF1"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/B7DCF025-033D-42BB-9014-482451302802"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/EB632755-18FA-42AD-A686-3BF03A2C01C6"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/8A2F05CC-4CFE-4E53-896A-18856AA44CC5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/D49CDF41-517A-4E66-8118-DD26B178907C"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DFC4F8B8-FEA3-43A5-9794-2947C3046678"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/C31A4281-1659-4836-AC3E-F7BE648BB52C"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/43BB1A68-C1C7-41C8-8B4A-8DDEF272A467"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/DAA52C30-A026-41CC-82B2-4990DA7AF022"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/9E12D923-66B4-44EB-9A84-6070AB7B1207"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/15DFE675-9D45-45CF-A714-070250805F7E"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/E0AA40DB-D6EB-4E1F-B9BB-0E3F7F305731"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "ReferralRequest/10BD3DCD-16BD-4FBC-BECF-0E70472E2B56"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/68628B67-E043-4631-BA6B-C5727324DC69"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/D760544D-A24A-48E4-BCC8-76D2363BCB9B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/D760544D-A24A-48E4-BCC8-76D2363BCB9B-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "AllergyIntolerance/F53DA9B6-72A7-4E82-AC71-F6BC20017A38"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/C83F4EBA-9E94-49B0-8C7C-15C6E8361319"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/5CDC45A0-26C6-495A-80C7-6D9C994F55C1"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/9ADA5156-88A4-4B43-AE6D-1F7903C386F0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/9ADA5156-88A4-4B43-AE6D-1F7903C386F0-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/0D095295-4B3E-46DB-9986-ACDEB12974A7"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/160827C3-6CC2-4816-8DEE-4A234746FA7B-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD92BE3A5A8F5472B831F455786BB4A9FPROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "onsetDateTime": "2020-11-09T13:25:00+00:00",
                "assertedDate": "2020-11-17T13:28:07.517+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "828198DE-51DC-412D-B407-8E3253D14A18-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/828198DE-51DC-412D-B407-8E3253D14A18"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/FACC8DEB-9D81-476D-AA42-B90F56FF1846-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D828198DE51DC412DB4078E3253D14A18PROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "37443015"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Heart attack"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "22298006",
                            "display": "Myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-09",
                "abatementDateTime": "2021-02-01",
                "assertedDate": "2020-11-18T14:17:31.06+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                },
                "note": [
                    {
                        "text": "(Grouped with Ischaemic heart disease)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "5EA6E5BC-96BF-403D-B4B2-3771F3791B7B-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/5EA6E5BC-96BF-403D-B4B2-3771F3791B7B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/FBDBFCEA-B088-4EE0-AC53-B36647E878A1-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/D50E2934-E2C2-4C5C-8E79-294C7F79BD4A-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D5EA6E5BC96BF403DB4B23771F3791B7BPROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "83992015"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "50417007",
                            "display": "Lower respiratory tract infection",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-09",
                "assertedDate": "2020-11-17T15:48:25.117+00:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "To be evolved\n(Evolved into Pneumonia 16-Nov-2020)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "FBDBFCEA-B088-4EE0-AC53-B36647E878A1-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/FBDBFCEA-B088-4EE0-AC53-B36647E878A1"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/52B5207E-072C-4FE2-91D6-8DCF758A31A5"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "MedicationRequest/5182A223-73B1-417E-80BA-9EA73652B79B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/5EA6E5BC-96BF-403D-B4B2-3771F3791B7B-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/D50E2934-E2C2-4C5C-8E79-294C7F79BD4A-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DFBDBFCEAB0884EE0AC53B36647E878A1PROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "350049016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "233604007",
                            "display": "Pneumonia",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-16",
                "abatementDateTime": "2021-02",
                "assertedDate": "2020-11-17T15:48:47.447+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                },
                "note": [
                    {
                        "text": "To be evolved\nTo be evolved"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/828198DE-51DC-412D-B407-8E3253D14A18-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "child"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/FACC8DEB-9D81-476D-AA42-B90F56FF1846-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DBA875AB4958F4E9CA5ACB5BB6C4A077CPROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11-17",
                "assertedDate": "2020-11-17T13:25:09.903+00:00",
                "asserter": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "D50E2934-E2C2-4C5C-8E79-294C7F79BD4A-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/D50E2934-E2C2-4C5C-8E79-294C7F79BD4A"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/FBDBFCEA-B088-4EE0-AC53-B36647E878A1-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/5EA6E5BC-96BF-403D-B4B2-3771F3791B7B-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD50E2934E2C24C5C8E79294C7F79BD4APROB"
                    }
                ],
                "clinicalStatus": "inactive",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "82824016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "49727002",
                            "display": "Cough",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-11",
                "abatementDateTime": "2020-11-17",
                "assertedDate": "2020-11-17T15:47:52.867+00:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "Some entered text To be evolved\n(Evolved into Pneumonia 16-Nov-2020)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "160827C3-6CC2-4816-8DEE-4A234746FA7B-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/160827C3-6CC2-4816-8DEE-4A234746FA7B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/48B935AF-730D-4F99-881C-7FF2C3EF9979"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/09905826-DF3D-4BDD-8377-C54A7A8D4914"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/09905826-DF3D-4BDD-8377-C54A7A8D4914-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/C820B675-650C-4B09-9499-E438E69A128B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/D92BE3A5-A8F5-472B-831F-455786BB4A9F-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D160827C36CC248168DEE4A234746FA7BPROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2020-12-14",
                "assertedDate": "2021-04-19T14:31:44.493+01:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "(Grouped with Ischaemic heart disease)"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "7499F1D6-5C58-43A0-8D0D-823CA7BD15B7-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/7499F1D6-5C58-43A0-8D0D-823CA7BD15B7"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D7499F1D65C5843A08D0D823CA7BD15B7PROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "284159018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "183936003",
                            "display": "Contraindication to live immunisation",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2021-03-17",
                "assertedDate": "2021-03-17T14:40:14.35+00:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/EAF64B5B-2ED0-4190-952B-22D148FDFCBE"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/A07B493D-A5A4-4897-888E-59C7C833BE4F"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/84F97FAB-903E-4E8A-BCB1-A46FE4279038"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/9C621603-70B0-44A8-B0B1-7DEF38756D2D-PG3"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/4AA333FA-A1B1-4A19-BDDA-8496108767FB"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "major"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "parent"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/D92BE3A5-A8F5-472B-831F-455786BB4A9F-PROB"
                                }
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedProblemHeader-1",
                        "extension": [
                            {
                                "url": "type",
                                "valueCode": "sibling"
                            },
                            {
                                "url": "target",
                                "valueReference": {
                                    "reference": "Condition/160827C3-6CC2-4816-8DEE-4A234746FA7B-PROB"
                                }
                            }
                        ]
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D6DEC4C769A0C4E03A1D151A7F87A2DA2PROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                },
                "onsetDateTime": "2021-03-24T11:39:00+00:00",
                "assertedDate": "2021-06-16T11:41:56.31+01:00",
                "asserter": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Condition",
                "id": "82ACCC6C-D367-40B5-A4D3-ABA26E7363BD-PROB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProblemHeader-Condition-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ActualProblem-1",
                        "valueReference": {
                            "reference": "Observation/82ACCC6C-D367-40B5-A4D3-ABA26E7363BD"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/86EC1A71-6739-4A43-8484-896F863E851B"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/86EC1A71-6739-4A43-8484-896F863E851B-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/3A43A34E-CC8A-49AD-B619-E4D7F259926E"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "List/9C621603-70B0-44A8-B0B1-7DEF38756D2D-PG0"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-RelatedClinicalContent-1",
                        "valueReference": {
                            "reference": "Observation/55253F84-1DA1-439D-BF16-B682117780BA"
                        }
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-ProblemSignificance-1",
                        "valueCode": "minor"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D82ACCC6CD36740B5A4D3ABA26E7363BDPROB"
                    }
                ],
                "clinicalStatus": "active",
                "category": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/CareConnect-ConditionCategory-1",
                                "code": "problem-list-item",
                                "display": "Problem List Item"
                            }
                        ]
                    }
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1779359015"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "400097005",
                            "display": "Ingrowing nail",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/86EC1A71-6739-4A43-8484-896F863E851B"
                },
                "onsetDateTime": "2021-03-26",
                "assertedDate": "2021-03-26T11:45:25.077+00:00",
                "asserter": {
                    "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                },
                "note": [
                    {
                        "text": "This problem was created whilst Adding a Document"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Organization",
                "id": "5E496953-065B-41F2-9577-BE8F2FBD0757",
                "meta": {
                    "versionId": "1112974926854455048",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Organization-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MainLocation-1",
                        "valueReference": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://fhir.nhs.uk/Id/ods-organization-code",
                        "value": "A82038"
                    }
                ],
                "type": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-OrganisationType-1",
                                "code": "gp-practice"
                            }
                        ],
                        "text": "GP Practice"
                    }
                ],
                "name": "TEMPLE SOWERBY MEDICAL PRACTICE",
                "telecom": [
                    {
                        "system": "phone",
                        "value": "01133800000",
                        "use": "work",
                        "rank": 1
                    }
                ],
                "address": [
                    {
                        "use": "work",
                        "type": "physical",
                        "line": [
                            "Fulford Grange",
                            "Micklefield Lane",
                            "Rawdon",
                            "Rawdon"
                        ],
                        "city": "Leeds",
                        "district": "Yorkshire",
                        "postalCode": "LS19 6BA"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "2DB481A3-306A-4133-9491-1558161D6A2B",
                "meta": {
                    "versionId": "4333436790463129417",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://fhir.nhs.uk/Id/sds-user-id",
                        "value": "555079033108"
                    },
                    {
                        "system": "https://fhir.nhs.uk/Id/sds-role-profile-id",
                        "value": "555079046103"
                    }
                ],
                "name": [
                    {
                        "use": "official",
                        "family": "TEMPLE SOWERBY",
                        "given": [
                            "GPONE"
                        ],
                        "prefix": [
                            "Mr"
                        ]
                    }
                ],
                "gender": "male"
            }
        },
        {
            "resource": {
                "resourceType": "Location",
                "id": "EB3994A6-5A87-4B53-A414-913137072F57",
                "meta": {
                    "versionId": "6653785719080073703",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Location-1"
                    ]
                },
                "status": "active",
                "name": "Test Practice Location",
                "type": {
                    "text": "Main Surgery"
                },
                "telecom": [
                    {
                        "system": "phone",
                        "value": "01133800000",
                        "use": "work",
                        "rank": 1
                    }
                ],
                "address": {
                    "use": "work",
                    "type": "physical",
                    "line": [
                        "Fulford Grange",
                        "Micklefield Lane",
                        "Rawdon",
                        "Rawdon"
                    ],
                    "city": "Leeds",
                    "district": "Yorkshire",
                    "postalCode": "LS19 6BA"
                },
                "managingOrganization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757",
                    "display": "TEMPLE SOWERBY MEDICAL PRACTICE"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Immunization",
                "id": "9569AEF5-9527-4F6A-8EFB-417D0AB3E6B6",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Immunization-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-DateRecorded-1",
                        "valueDateTime": "2020-11-18T13:56:52.87+00:00"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-VaccinationProcedure-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "extension": [
                                        {
                                            "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                            "extension": [
                                                {
                                                    "url": "descriptionId",
                                                    "valueId": "2533976011"
                                                },
                                                {
                                                    "url": "descriptionDisplay",
                                                    "valueString": "First diphtheria tetanus and five component acellular pertussis, haemophilus influenzae type b, inactivated polio vaccination"
                                                }
                                            ]
                                        }
                                    ],
                                    "system": "http://snomed.info/sct",
                                    "code": "414259000",
                                    "display": "Administration of first dose of diphtheria and Haemophilus influenza B and five component acellular pertussis and inactivated poliomyelitis and tetanus vaccine",
                                    "userSelected": true
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9569AEF595274F6A8EFB417D0AB3E6B6"
                    }
                ],
                "status": "completed",
                "notGiven": false,
                "vaccineCode": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/v3/NullFlavor",
                            "code": "UNK",
                            "display": "unknown"
                        }
                    ]
                },
                "patient": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "primarySource": true,
                "manufacturer": {
                    "reference": "Organization/0D4D8C3BBF6C2736CA91BC7DD50659B4D61D71B6-XMO"
                },
                "lotNumber": "batch001",
                "expirationDate": "2025-12-01",
                "site": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1697871000006117"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Right buttock"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "1697871000006101",
                            "display": "Right buttock"
                        }
                    ]
                },
                "practitioner": [
                    {
                        "role": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v2/0443",
                                    "code": "AP",
                                    "display": "Administering Provider"
                                }
                            ]
                        },
                        "actor": {
                            "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                        }
                    },
                    {
                        "role": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v2/0443",
                                    "code": "EP",
                                    "display": "Entering Provider (probably not the same as transcriptionist?)"
                                }
                            ]
                        },
                        "actor": {
                            "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                        }
                    }
                ],
                "note": [
                    {
                        "text": "GMS : GMS, Scheduled/Unscheduled : Unscheduled\nSignificance : Minor\nEpisodicity : First\nhistorical date\nhistorical date"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "3BC1331C-7C74-40D8-8576-0C990119514C",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "E4AA89361BF14A4BAD332A119C2BD6F83BC1331C7C7440D885760C990119514C"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://read.info/readv2",
                            "code": "E205.11",
                            "display": "Nervous exhaustion",
                            "userSelected": true
                        },
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "677031000006115"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Nervous exhaustion"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "78667006",
                            "display": "Dysthymia"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2006-04-25",
                "issued": "2021-01-12T13:18:55.157+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : First"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "47BE9D54-A8A0-46DA-A0A8-A51C794777FE",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "E4AA89361BF14A4BAD332A119C2BD6F847BE9D54A8A046DAA0A8A51C794777FE"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://read.info/readv2",
                            "code": "E205.11",
                            "display": "Nervous exhaustion",
                            "userSelected": true
                        },
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "677031000006115"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Nervous exhaustion"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "78667006",
                            "display": "Dysthymia"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/BD772D1B-D984-49D4-A2F1-2CA7A654F287"
                },
                "effectiveDateTime": "2006-03-21",
                "issued": "2021-01-12T13:18:55.157+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                    }
                ],
                "comment": "Episode: First ever."
            }
        },
        {
            "resource": {
                "resourceType": "AllergyIntolerance",
                "id": "0DAFB800-AA02-446C-9A9B-5860E9ADA3E0",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-AllergyIntolerance-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D0DAFB800AA02446C9A9B5860E9ADA3E0"
                    }
                ],
                "clinicalStatus": "active",
                "verificationStatus": "unconfirmed",
                "category": [
                    "environment"
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "442112014"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Latex allergy"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "300916003",
                            "display": "Allergy to latex",
                            "userSelected": true
                        }
                    ]
                },
                "patient": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2019",
                "assertedDate": "2021-03-26T11:15:05.483+00:00",
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "Significance : Major\nEpisodicity : First"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "2BE35191-475E-4D5A-8CC8-EB769562B566",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D2BE35191475E4D5A8CC8EB769562B566"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "961911000006112"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Syncopal episodes (fainting)/dizziness"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "961911000006108",
                            "display": "Syncopal episodes (fainting)/dizziness",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-04-08",
                "issued": "2021-04-08T17:26:10.21+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : First\npatient reports these have been ongoing for 3 to 4 weeks\n(Grouped with Breathless - moderate exertion)"
            }
        },
        {
            "resource": {
                "resourceType": "DocumentReference",
                "id": "7189F0C8-639C-45BB-806F-7E156DABA151",
                "meta": {
                    "versionId": "1782816043182506730",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-DocumentReference-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D7189F0C8639C45BB806F7E156DABA151"
                    }
                ],
                "status": "current",
                "type": {
                    "text": "Referral for further care"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "created": "2021-03-26T11:43:00+00:00",
                "indexed": "2021-03-26T11:45:24.763+00:00",
                "custodian": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "description": "This document is linked to a Problem",
                "content": [
                    {
                        "attachment": {
                            "contentType": "text/plain",
                            "url": "https://gpcassurance-b86047.test.thirdparty.nhs.uk/A82038/STU3/1/GPConnect/Documents/Binary/144A1A2EB3B34A66B33B148A5B75959D7189F0C8639C45BB806F7E156DABA151",
                            "size": 33
                        }
                    }
                ],
                "context": {
                    "encounter": {
                        "reference": "Encounter/86EC1A71-6739-4A43-8484-896F863E851B"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "F6FCF37E-F5D9-46FB-B39A-F94C32A69B11",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DF6FCF37EF5D946FBB39AF94C32A69B11"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "252385016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "161939006",
                            "display": "Breathless - moderate exertion",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-09-15",
                "issued": "2021-03-26T16:34:39.213+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : First\nThe descriptive text includes special characters!'Â£$%^7*()-={}][|\":/.#@, -~ (Grouped with Chest pain)\nThe descriptive text includes special characters!'Â£$%^7*()-={}][|\":/.,\n(Grouped with Chest pain)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "534E8774-16A4-48CB-A187-2A7683839A24",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D534E877416A448CBA1872A7683839A24"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "252385016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "161939006",
                            "display": "Breathless - moderate exertion",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                },
                "effectiveDateTime": "2020-11-18T13:56:00+00:00",
                "issued": "2021-03-29T14:38:13.75+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : Flare Up"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "79649222-3B68-4905-A4DC-7410D29A4565",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D796492223B684905A4DC7410D29A4565"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "GP Surgery"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                        }
                    }
                ],
                "period": {
                    "start": "2020-11-18T13:56:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Immunization",
                "id": "E151BC23-8CC1-479F-A8EC-5CB9998BA1E5",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Immunization-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-DateRecorded-1",
                        "valueDateTime": "2020-11-18T13:59:05.83+00:00"
                    },
                    {
                        "url": "https://fhir.hl7.org.uk/STU3/StructureDefinition/Extension-CareConnect-VaccinationProcedure-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "extension": [
                                        {
                                            "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                            "extension": [
                                                {
                                                    "url": "descriptionId",
                                                    "valueId": "458773016"
                                                },
                                                {
                                                    "url": "descriptionDisplay",
                                                    "valueString": "First meningitis C vaccination"
                                                }
                                            ]
                                        }
                                    ],
                                    "system": "http://snomed.info/sct",
                                    "code": "314414007",
                                    "display": "Administration of first dose of meningitis C vaccine",
                                    "userSelected": true
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DE151BC238CC1479FA8EC5CB9998BA1E5"
                    }
                ],
                "status": "completed",
                "notGiven": false,
                "vaccineCode": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/v3/NullFlavor",
                            "code": "UNK",
                            "display": "unknown"
                        }
                    ]
                },
                "patient": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "encounter": {
                    "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                },
                "date": "2020-11-18T13:56:00+00:00",
                "primarySource": true,
                "location": {
                    "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                },
                "manufacturer": {
                    "reference": "Organization/D7CFC8DB301548C1A3DB153C7FDDEDBC21624C4C-XMO"
                },
                "lotNumber": "batch002",
                "expirationDate": "2023",
                "practitioner": [
                    {
                        "role": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v2/0443",
                                    "code": "AP",
                                    "display": "Administering Provider"
                                }
                            ]
                        },
                        "actor": {
                            "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                        }
                    },
                    {
                        "role": {
                            "coding": [
                                {
                                    "system": "http://hl7.org/fhir/v2/0443",
                                    "code": "EP",
                                    "display": "Entering Provider (probably not the same as transcriptionist?)"
                                }
                            ]
                        },
                        "actor": {
                            "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "C94B1851-0AF6-4DE9-A405-63B4C8BA2205",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DC94B18510AF64DE9A40563B4C8BA2205"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "37331000000100",
                            "display": "Comment note"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                },
                "effectiveDateTime": "2020-11-18T13:56:00+00:00",
                "issued": "2020-11-18T14:04:45.87+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                    }
                ],
                "comment": "Biochemistry - Venous blood specimen (Test request : Serum electrolytes, Test request : Liver Function Tests, Test request : Blood Glucose)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "20063759-2032-4474-AA6D-07472A213261",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D2006375920324474AA6D07472A213261"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "37331000000100",
                            "display": "Comment note"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                },
                "effectiveDateTime": "2020-11-18T13:56:00+00:00",
                "issued": "2020-11-18T14:04:46.79+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                    }
                ],
                "comment": "Biochemistry - Urine specimen (Test request : Urinary Microalbumin)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "9A8BF064-43AC-462E-BB0A-AABD1FEF0B68",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9A8BF06443AC462EBB0AAABD1FEF0B68"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1215744012"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Hypertensive disorder"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "38341003",
                            "display": "Hypertension",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-01",
                "issued": "2020-11-18T14:19:48.68+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : First\nFirst entry with a lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repeating sentences. A lot of text and a number of repe\nFirst entry"
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "7F987A44-FF18-4109-935B-C0A0A3976FD5",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationRepeatInformation-1",
                        "extension": [
                            {
                                "url": "numberOfRepeatPrescriptionsAllowed",
                                "valueUnsignedInt": 6
                            },
                            {
                                "url": "numberOfRepeatPrescriptionsIssued",
                                "valueUnsignedInt": 4
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D7F987A44FF184109935BC0A0A3976FD5"
                    }
                ],
                "status": "active",
                "intent": "plan",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:06:09.56+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "DAACC2C8-D0CA-4445-AB79-BA8476B61F49",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationRepeatInformation-1",
                        "extension": [
                            {
                                "url": "numberOfRepeatPrescriptionsAllowed",
                                "valueUnsignedInt": 6
                            },
                            {
                                "url": "numberOfRepeatPrescriptionsIssued",
                                "valueUnsignedInt": 4
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DDAACC2C8D0CA4445AB79BA8476B61F49"
                    }
                ],
                "status": "active",
                "intent": "plan",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:06:09.56+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "16CD05AC-02C7-4152-8445-CB54A59E3689",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D16CD05AC02C741528445CB54A59E3689"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "authoredOn": "2020-11-09T13:25:00+00:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09",
                        "end": "2020-12-07"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "87114350-4E1E-48CA-A4B9-101F81E8FFF1",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D871143504E1E48CAA4B9101F81E8FFF1"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "authoredOn": "2020-11-09T13:25:00+00:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09",
                        "end": "2020-12-07"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "EB632755-18FA-42AD-A686-3BF03A2C01C6",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DEB63275518FA42ADA6863BF03A2C01C6"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:12:16.157+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-02",
                        "end": "2020-12-30"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "8A2F05CC-4CFE-4E53-896A-18856AA44CC5",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D8A2F05CC4CFE4E53896A18856AA44CC5"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:12:16.157+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-02",
                        "end": "2020-12-30"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "DFC4F8B8-FEA3-43A5-9794-2947C3046678",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DDFC4F8B8FEA343A597942947C3046678"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:15:35.393+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-31",
                        "end": "2021-01-28"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "C31A4281-1659-4836-AC3E-F7BE648BB52C",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DC31A428116594836AC3EF7BE648BB52C"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:15:35.393+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-31",
                        "end": "2021-01-28"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "DAA52C30-A026-41CC-82B2-4990DA7AF022",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DDAA52C30A02641CC82B24990DA7AF022"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:19:45.023+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2021-01-29",
                        "end": "2021-02-26"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "9E12D923-66B4-44EB-9A84-6070AB7B1207",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9E12D92366B444EB9A846070AB7B1207"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:19:45.023+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2021-01-29",
                        "end": "2021-02-26"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "3F9B0582-3BCC-4E03-A36D-0A33A41C73F6",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D3F9B05823BCC4E03A36D0A33A41C73F6"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1215744012"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Hypertensive disorder"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "38341003",
                            "display": "Hypertension",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-10",
                "issued": "2020-11-18T14:20:15.24+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review\nsecond entry"
            }
        },
        {
            "resource": {
                "resourceType": "ReferralRequest",
                "id": "10BD3DCD-16BD-4FBC-BECF-0E70472E2B56",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ReferralRequest-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D10BD3DCD16BD4FBCBECF0E70472E2B56"
                    }
                ],
                "status": "unknown",
                "intent": "order",
                "priority": "routine",
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/5EEEEA53-485F-4233-9B3A-AFDD05C56BB3"
                },
                "authoredOn": "2020-11-25",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/6AB948A5-2067-4A67-AD00-60EAF13E9CAA"
                    }
                },
                "recipient": [
                    {
                        "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                    },
                    {
                        "reference": "HealthcareService/5E496953-065B-41F2-9577-BE8F2FBD0757-HCS"
                    }
                ],
                "reasonCode": [
                    {
                        "coding": [
                            {
                                "extension": [
                                    {
                                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                        "extension": [
                                            {
                                                "url": "descriptionId",
                                                "valueId": "1484917012"
                                            }
                                        ]
                                    }
                                ],
                                "system": "http://snomed.info/sct",
                                "code": "390884006",
                                "display": "Heart failure follow-up",
                                "userSelected": true
                            }
                        ]
                    }
                ],
                "description": "linked to a problem",
                "supportingInfo": [
                    {
                        "reference": "DocumentReference/E0AA40DB-D6EB-4E1F-B9BB-0E3F7F305731"
                    }
                ],
                "note": [
                    {
                        "text": "Mode:Written"
                    },
                    {
                        "text": "Purpose:Management Advice"
                    },
                    {
                        "text": "NHS / Private:NHS"
                    },
                    {
                        "text": "Transport:None Required"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "218164F4-6101-48E4-9AFE-1CD797644C29",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D218164F4610148E49AFE1CD797644C29"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1215744012"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Hypertensive disorder"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "38341003",
                            "display": "Hypertension",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-04-08T17:05:57.14+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "9C621603-70B0-44A8-B0B1-7DEF38756D2D",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9C62160370B044A8B0B17DEF38756D2D"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "Telephone consultation"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    }
                ],
                "period": {
                    "start": "2021-04-08T16:56:00+01:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/CF61B986-5F73-44E2-B8BB-408A0F435B8B"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "2494D07E-DB8B-471E-9171-6F79BC2E9F43",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D2494D07EDB8B471E91716F79BC2E9F43"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "37331000000100",
                            "display": "Comment note"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-04-08T17:05:57.373+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Stable / no significant change"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "FACC8DEB-9D81-476D-AA42-B90F56FF1846",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DFACC8DEB9D81476DAA42B90F56FF1846"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "49966017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "29857009",
                            "display": "Chest pain",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-04",
                "issued": "2020-11-18T14:17:57.04+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : First\n(Grouped with Ischaemic heart disease)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "D92BE3A5-A8F5-472B-831F-455786BB4A9F",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD92BE3A5A8F5472B831F455786BB4A9F"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "effectiveDateTime": "2020-11-09T13:25:00+00:00",
                "issued": "2020-11-17T13:28:07.517+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : First"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "679893BB-9C1C-4125-B765-3F511FCBF5CC",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D679893BB9C1C4125B7653F511FCBF5CC"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "GP Surgery"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PART",
                                        "display": "Participation"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/A6D3B7DE-E5F4-49FC-9F7F-6A9781829009"
                        }
                    }
                ],
                "period": {
                    "start": "2020-11-09T13:25:00+00:00",
                    "end": "2020-11-09T13:38:00+00:00"
                },
                "length": {
                    "value": 13,
                    "unit": "minute",
                    "system": "http://unitsofmeasure.org",
                    "code": "min"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "ProcedureRequest",
                "id": "CBD7D61A-19A2-4368-BF9A-387CCA0DA905",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-ProcedureRequest-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DCBD7D61A19A24368BF9A387CCA0DA905"
                    }
                ],
                "status": "active",
                "intent": "plan",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "occurrenceDateTime": "2022-11-17",
                "authoredOn": "2020-11-17T13:30:32.073+00:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                },
                "note": [
                    {
                        "text": "Added from a problem within a consultation"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "BA98DB56-0F48-4118-80C2-2D05BEAE2219",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DBA98DB560F48411880C22D05BEAE2219"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2839499013"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57177007",
                            "display": "Family history with explicit context",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "effectiveDateTime": "2020-11-09T13:25:00+00:00",
                "issued": "2020-11-17T15:26:38.537+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Family member : Maternal grandmother\nmanually added text within consultation"
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "B7DCF025-033D-42BB-9014-482451302802",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DB7DCF025033D42BB9014482451302802"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                },
                "authoredOn": "2020-11-09T13:25:00+00:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09",
                        "end": "2020-12-07"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "D57A7BD1-5335-434C-A90A-57342C2310D2",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationRepeatInformation-1",
                        "extension": [
                            {
                                "url": "numberOfRepeatPrescriptionsAllowed",
                                "valueUnsignedInt": 6
                            },
                            {
                                "url": "numberOfRepeatPrescriptionsIssued",
                                "valueUnsignedInt": 4
                            }
                        ]
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD57A7BD15335434CA90A57342C2310D2"
                    }
                ],
                "status": "active",
                "intent": "plan",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:06:09.56+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-11-09"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "D49CDF41-517A-4E66-8118-DD26B178907C",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD49CDF41517A4E668118DD26B178907C"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:12:16.157+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-02",
                        "end": "2020-12-30"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "43BB1A68-C1C7-41C8-8B4A-8DDEF272A467",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D43BB1A68C1C741C88B4A8DDEF272A467"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:15:35.393+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-31",
                        "end": "2021-01-28"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "15DFE675-9D45-45CF-A714-070250805F7E",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "repeat",
                                    "display": "Repeat"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D15DFE6759D4545CFA714070250805F7E"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-06-16T11:19:45.023+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2021-01-29",
                        "end": "2021-02-26"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 28,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "DocumentReference",
                "id": "E0AA40DB-D6EB-4E1F-B9BB-0E3F7F305731",
                "meta": {
                    "versionId": "8195225890269808535",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-DocumentReference-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DE0AA40DBD6EB4E1FB9BB0E3F7F305731"
                    }
                ],
                "status": "current",
                "type": {
                    "text": "Clinical report"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "created": "2019-09-04T00:00:00+01:00",
                "indexed": "2020-11-25T14:04:44.47+00:00",
                "custodian": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "description": "Clinical report (04-Sep-2019)",
                "content": [
                    {
                        "attachment": {
                            "contentType": "image/jpeg",
                            "url": "https://gpcassurance-b86047.test.thirdparty.nhs.uk/A82038/STU3/1/GPConnect/Documents/Binary/144A1A2EB3B34A66B33B148A5B75959DE0AA40DBD6EB4E1FB9BB0E3F7F305731",
                            "size": 70402
                        }
                    }
                ],
                "context": {
                    "encounter": {
                        "reference": "Encounter/6E172462-3BC4-4269-8AB8-9F848CAEDA33"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "68628B67-E043-4631-BA6B-C5727324DC69",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D68628B67E0434631BA6BC5727324DC69"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/D760544D-A24A-48E4-BCC8-76D2363BCB9B"
                },
                "effectiveDateTime": "2021-03-26T15:51:00+00:00",
                "issued": "2021-03-26T15:56:38.587+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review\nSome additional notes about the heart disease review"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "D760544D-A24A-48E4-BCC8-76D2363BCB9B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD760544DA24A48E4BCC876D2363BCB9B"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "GP Surgery"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    }
                ],
                "period": {
                    "start": "2021-03-26T15:51:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/CF61B986-5F73-44E2-B8BB-408A0F435B8B"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "AllergyIntolerance",
                "id": "F53DA9B6-72A7-4E82-AC71-F6BC20017A38",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-AllergyIntolerance-1"
                    ]
                },
                "extension": [
                    {
                        "url": "http://hl7.org/fhir/StructureDefinition/encounter-associatedEncounter",
                        "valueReference": {
                            "reference": "Encounter/D760544D-A24A-48E4-BCC8-76D2363BCB9B"
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DF53DA9B672A74E82AC71F6BC20017A38"
                    }
                ],
                "clinicalStatus": "active",
                "verificationStatus": "unconfirmed",
                "category": [
                    "medication"
                ],
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "432156011"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "292044008",
                            "display": "Aspirin adverse reaction",
                            "userSelected": true
                        }
                    ]
                },
                "patient": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "onsetDateTime": "2021-03-26T15:51:00+00:00",
                "assertedDate": "2021-03-26T15:56:38.867+00:00",
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "note": [
                    {
                        "text": "added to link to the problem"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "C83F4EBA-9E94-49B0-8C7C-15C6E8361319",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DC83F4EBA9E9449B08C7C15C6E8361319"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "411931013"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "275955005",
                            "display": "O/E - allergic rash",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/D760544D-A24A-48E4-BCC8-76D2363BCB9B"
                },
                "effectiveDateTime": "2021-03-26T15:51:00+00:00",
                "issued": "2021-03-26T15:56:38.947+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "5CDC45A0-26C6-495A-80C7-6D9C994F55C1",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D5CDC45A026C6495A80C76D9C994F55C1"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9ADA5156-88A4-4B43-AE6D-1F7903C386F0"
                },
                "effectiveDateTime": "2021-01-29T11:17:00+00:00",
                "issued": "2021-06-16T11:20:09.82+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "9ADA5156-88A4-4B43-AE6D-1F7903C386F0",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D9ADA515688A44B43AE6D1F7903C386F0"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "GP Surgery"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    }
                ],
                "period": {
                    "start": "2021-01-29T11:17:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "0D095295-4B3E-46DB-9986-ACDEB12974A7",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D0D0952954B3E46DB9986ACDEB12974A7"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "37331000000100",
                            "display": "Comment note"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9ADA5156-88A4-4B43-AE6D-1F7903C386F0"
                },
                "effectiveDateTime": "2021-01-29T11:17:00+00:00",
                "issued": "2021-06-16T11:20:11.57+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Continue on meds"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "828198DE-51DC-412D-B407-8E3253D14A18",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D828198DE51DC412DB4078E3253D14A18"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "37443015"
                                        },
                                        {
                                            "url": "descriptionDisplay",
                                            "valueString": "Heart attack"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "22298006",
                            "display": "Myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-09",
                "issued": "2020-11-18T14:17:31.06+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : First\n(Grouped with Ischaemic heart disease)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "5EA6E5BC-96BF-403D-B4B2-3771F3791B7B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D5EA6E5BC96BF403DB4B23771F3791B7B"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "83992015"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "50417007",
                            "display": "Lower respiratory tract infection",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-09",
                "issued": "2020-11-17T15:48:25.117+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Minor\nEpisodicity : First\nTo be evolved\n(Evolved into Pneumonia 16-Nov-2020)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "FBDBFCEA-B088-4EE0-AC53-B36647E878A1",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DFBDBFCEAB0884EE0AC53B36647E878A1"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "350049016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "233604007",
                            "display": "Pneumonia",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-16",
                "issued": "2020-11-17T15:48:47.447+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Laterality : Bilateral\nSignificance : Major\nEpisodicity : First\nTo be evolved\nTo be evolved"
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "52B5207E-072C-4FE2-91D6-8DCF758A31A5",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "acute",
                                    "display": "Acute"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D52B5207E072C4FE291D68DCF758A31A5"
                    }
                ],
                "status": "completed",
                "intent": "plan",
                "medicationReference": {
                    "reference": "Medication/6E1B8C59-BE54-4BB5-B498-27E847B7B72C"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "authoredOn": "2021-04-20T17:28:48.8+01:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Four Times A Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-02",
                        "end": "2020-12-09"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 7,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationRequest",
                "id": "5182A223-73B1-417E-80BA-9EA73652B79B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationRequest-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescriptionType-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescriptionType-1",
                                    "code": "acute",
                                    "display": "Acute"
                                }
                            ]
                        }
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D5182A22373B1417E80BA9EA73652B79B"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/52B5207E-072C-4FE2-91D6-8DCF758A31A5"
                    }
                ],
                "status": "completed",
                "intent": "order",
                "medicationReference": {
                    "reference": "Medication/6E1B8C59-BE54-4BB5-B498-27E847B7B72C"
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/67973141-D1BD-4829-8CAE-D00340397A74"
                },
                "authoredOn": "2020-12-02T15:22:00+00:00",
                "requester": {
                    "agent": {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                },
                "recorder": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "dosageInstruction": [
                    {
                        "text": "One To Be Taken Four Times A Day"
                    }
                ],
                "dispenseRequest": {
                    "validityPeriod": {
                        "start": "2020-12-02",
                        "end": "2020-12-09"
                    },
                    "quantity": {
                        "value": 28,
                        "unit": "tablet"
                    },
                    "expectedSupplyDuration": {
                        "value": 7,
                        "unit": "day",
                        "system": "http://unitsofmeasure.org",
                        "code": "d"
                    }
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DBA875AB4958F4E9CA5ACB5BB6C4A077C"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "2534664018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "414545008",
                            "display": "Ischaemic heart disease",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11-17",
                "issued": "2020-11-17T13:25:09.903+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : New"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "D50E2934-E2C2-4C5C-8E79-294C7F79BD4A",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD50E2934E2C24C5C8E79294C7F79BD4A"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "82824016"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "49727002",
                            "display": "Cough",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-11",
                "issued": "2020-11-17T15:47:52.867+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Severity : Mild, Frequencies : Occasional\nSignificance : Minor\nEpisodicity : First\nSome entered text To be evolved\n(Evolved into Pneumonia 16-Nov-2020)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "160827C3-6CC2-4816-8DEE-4A234746FA7B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D160827C36CC248168DEE4A234746FA7B"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2020-12-14",
                "issued": "2021-04-19T14:31:44.493+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : First\n(Grouped with Ischaemic heart disease)"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "48B935AF-730D-4F99-881C-7FF2C3EF9979",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D48B935AF730D4F99881C7FF2C3EF9979"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/09905826-DF3D-4BDD-8377-C54A7A8D4914"
                },
                "effectiveDateTime": "2020-12-31T11:13:00+00:00",
                "issued": "2021-06-16T11:38:35.973+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "09905826-DF3D-4BDD-8377-C54A7A8D4914",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D09905826DF3D4BDD8377C54A7A8D4914"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "Administration note"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    }
                ],
                "period": {
                    "start": "2020-12-31T11:13:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "C820B675-650C-4B09-9499-E438E69A128B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DC820B675650C4B099499E438E69A128B"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "system": "http://snomed.info/sct",
                            "code": "37331000000100",
                            "display": "Comment note"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/09905826-DF3D-4BDD-8377-C54A7A8D4914"
                },
                "effectiveDateTime": "2020-12-31T11:13:00+00:00",
                "issued": "2021-06-16T11:16:21.25+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Issue heart meds"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "7499F1D6-5C58-43A0-8D0D-823CA7BD15B7",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D7499F1D65C5843A08D0D823CA7BD15B7"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "284159018"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "183936003",
                            "display": "Contraindication to live immunisation",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "effectiveDateTime": "2021-03-17",
                "issued": "2021-03-17T14:40:14.35+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Immunisation (Given Unknown)\nContraindication to live immunisation"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D6DEC4C769A0C4E03A1D151A7F87A2DA2"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                },
                "effectiveDateTime": "2021-03-24T11:39:00+00:00",
                "issued": "2021-06-16T11:41:56.31+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : New"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DC94C9A734AF84D3A8D92FCA8758C0BFE"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "GP Surgery"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                        }
                    }
                ],
                "period": {
                    "start": "2021-03-24T11:39:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "EAF64B5B-2ED0-4190-952B-22D148FDFCBE",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DEAF64B5B2ED04190952B22D148FDFCBE"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "49966017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "29857009",
                            "display": "Chest pain",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                },
                "effectiveDateTime": "2021-03-24T11:39:00+00:00",
                "issued": "2021-06-16T11:41:56.703+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "A07B493D-A5A4-4897-888E-59C7C833BE4F",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DA07B493DA5A44897888E59C7C833BE4F"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "283520011"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "183452005",
                            "display": "Emergency hospital admission",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                },
                "effectiveDateTime": "2021-03-24T11:39:00+00:00",
                "issued": "2021-06-16T11:41:56.843+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "84F97FAB-903E-4E8A-BCB1-A46FE4279038",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D84F97FAB903E4E8ABCB1A46FE4279038"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "94884017"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "57054005",
                            "display": "Acute myocardial infarction",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-06-16T11:46:50.83+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Significance : Major\nEpisodicity : Review"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "4AA333FA-A1B1-4A19-BDDA-8496108767FB",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D4AA333FAA1B14A19BDDA8496108767FB"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "254063019"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "163020007",
                            "display": "O/E - blood pressure reading",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-06-16T11:46:50.91+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "component": [
                    {
                        "code": {
                            "coding": [
                                {
                                    "extension": [
                                        {
                                            "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                            "extension": [
                                                {
                                                    "url": "descriptionId",
                                                    "valueId": "120159016"
                                                }
                                            ]
                                        }
                                    ],
                                    "system": "http://snomed.info/sct",
                                    "code": "72313002",
                                    "display": "Systolic arterial pressure",
                                    "userSelected": true
                                }
                            ]
                        },
                        "valueQuantity": {
                            "value": 120.000,
                            "unit": "mm[Hg]"
                        }
                    },
                    {
                        "code": {
                            "coding": [
                                {
                                    "extension": [
                                        {
                                            "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                            "extension": [
                                                {
                                                    "url": "descriptionId",
                                                    "valueId": "2734671000000117"
                                                }
                                            ]
                                        }
                                    ],
                                    "system": "http://snomed.info/sct",
                                    "code": "1091811000000102",
                                    "display": "Diastolic arterial pressure",
                                    "userSelected": true
                                }
                            ]
                        },
                        "valueQuantity": {
                            "value": 70.000,
                            "unit": "mm[Hg]"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "82ACCC6C-D367-40B5-A4D3-ABA26E7363BD",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D82ACCC6CD36740B5A4D3ABA26E7363BD"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1779359015"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "400097005",
                            "display": "Ingrowing nail",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/86EC1A71-6739-4A43-8484-896F863E851B"
                },
                "effectiveDateTime": "2021-03-26",
                "issued": "2021-03-26T11:45:25.077+00:00",
                "performer": [
                    {
                        "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                    }
                ],
                "comment": "Laterality : Left\nSignificance : Minor\nEpisodicity : First\nThis problem was created whilst Adding a Document"
            }
        },
        {
            "resource": {
                "resourceType": "Encounter",
                "id": "86EC1A71-6739-4A43-8484-896F863E851B",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Encounter-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D86EC1A7167394A438484896F863E851B"
                    }
                ],
                "status": "finished",
                "type": [
                    {
                        "text": "Other"
                    }
                ],
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "participant": [
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "http://hl7.org/fhir/v3/ParticipationType",
                                        "code": "PPRF",
                                        "display": "primary performer"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                        }
                    },
                    {
                        "type": [
                            {
                                "coding": [
                                    {
                                        "system": "https://fhir.nhs.uk/STU3/CodeSystem/GPConnect-ParticipantType-1",
                                        "code": "REC",
                                        "display": "recorder"
                                    }
                                ]
                            }
                        ],
                        "individual": {
                            "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                        }
                    }
                ],
                "period": {
                    "start": "2021-03-26T11:43:00+00:00"
                },
                "location": [
                    {
                        "location": {
                            "reference": "Location/EB3994A6-5A87-4B53-A414-913137072F57"
                        }
                    }
                ],
                "serviceProvider": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "3A43A34E-CC8A-49AD-B619-E4D7F259926E",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D3A43A34ECC8A49ADB619E4D7F259926E"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1779359015"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "400097005",
                            "display": "Ingrowing nail",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-04-08T17:05:56.543+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Laterality : Left\nSignificance : Minor\nEpisodicity : Review"
            }
        },
        {
            "resource": {
                "resourceType": "Observation",
                "id": "55253F84-1DA1-439D-BF16-B682117780BA",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Observation-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D55253F841DA1439DBF16B682117780BA"
                    }
                ],
                "status": "final",
                "code": {
                    "coding": [
                        {
                            "extension": [
                                {
                                    "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-coding-sctdescid",
                                    "extension": [
                                        {
                                            "url": "descriptionId",
                                            "valueId": "1209883019"
                                        }
                                    ]
                                }
                            ],
                            "system": "http://snomed.info/sct",
                            "code": "371186005",
                            "display": "Amputation of toe",
                            "userSelected": true
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "context": {
                    "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                },
                "effectiveDateTime": "2021-04-08T16:56:00+01:00",
                "issued": "2021-04-08T17:05:56.937+01:00",
                "performer": [
                    {
                        "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                    }
                ],
                "comment": "Laterality : Left\nunnecessary"
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "2DB481A3306A413394911558161D6A2B5E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "2896411073564168692",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/2DB481A3-306A-4133-9491-1558161D6A2B"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0260",
                                "display": "General Medical Practitioner"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73",
                "meta": {
                    "versionId": "4749697187075864793",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "name": [
                    {
                        "use": "official",
                        "family": "McAvenue",
                        "given": [
                            "David"
                        ],
                        "prefix": [
                            "Dr"
                        ]
                    }
                ],
                "gender": "male"
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B",
                "meta": {
                    "versionId": "7786052607397903776",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "name": [
                    {
                        "use": "official",
                        "family": "Test",
                        "given": [
                            "NHS"
                        ],
                        "prefix": [
                            "Mr"
                        ]
                    }
                ],
                "gender": "male"
            }
        },
        {
            "resource": {
                "resourceType": "Organization",
                "id": "0D4D8C3BBF6C2736CA91BC7DD50659B4D61D71B6-XMO",
                "meta": {
                    "versionId": "5939580616327273888",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Organization-1"
                    ]
                },
                "name": "imakedrugs"
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4",
                "meta": {
                    "versionId": "6855069453919254394",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "name": [
                    {
                        "use": "official",
                        "family": "Kennedy",
                        "given": [
                            "Frederick"
                        ],
                        "prefix": [
                            "Dr"
                        ]
                    }
                ],
                "gender": "unknown"
            }
        },
        {
            "resource": {
                "resourceType": "Organization",
                "id": "D7CFC8DB301548C1A3DB153C7FDDEDBC21624C4C-XMO",
                "meta": {
                    "versionId": "2151807447256333870",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Organization-1"
                    ]
                },
                "name": "imakedrugs4u"
            }
        },
        {
            "resource": {
                "resourceType": "Medication",
                "id": "CBD59674-FDAB-4345-98F4-6609EF2C60E1",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Medication-1"
                    ]
                },
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/Id/test-drug-codes",
                            "code": "EMTA8949BRIDL",
                            "display": "Bisoprolol 10mg tablets",
                            "userSelected": true
                        },
                        {
                            "system": "http://snomed.info/sct",
                            "code": "318591005",
                            "display": "Bisoprolol 10mg tablets"
                        }
                    ]
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationStatement",
                "id": "7F987A44-FF18-4109-935B-C0A0A3976FD5-MS",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationStatement-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescribingAgency-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescribingAgency-1",
                                    "code": "prescribed-at-gp-practice",
                                    "display": "Prescribed at GP practice"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationStatementLastIssueDate-1",
                        "valueDateTime": "2021-01-29T00:00:00+00:00"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D7F987A44FF184109935BC0A0A3976FD5MS"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/7F987A44-FF18-4109-935B-C0A0A3976FD5"
                    }
                ],
                "status": "active",
                "medicationReference": {
                    "reference": "Medication/CBD59674-FDAB-4345-98F4-6609EF2C60E1"
                },
                "effectivePeriod": {
                    "start": "2020-11-09"
                },
                "dateAsserted": "2021-06-16T11:06:09.56+01:00",
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "taken": "unk",
                "dosage": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Medication",
                "id": "0AD23CEB-615D-4724-BEB0-EC74E161DDEF",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Medication-1"
                    ]
                },
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/Id/test-drug-codes",
                            "code": "RATA16402Ntest",
                            "display": "Ramipril 10mg tablets",
                            "userSelected": true
                        },
                        {
                            "system": "http://snomed.info/sct",
                            "code": "408052000",
                            "display": "Ramipril 10mg tablets"
                        }
                    ]
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationStatement",
                "id": "DAACC2C8-D0CA-4445-AB79-BA8476B61F49-MS",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationStatement-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescribingAgency-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescribingAgency-1",
                                    "code": "prescribed-at-gp-practice",
                                    "display": "Prescribed at GP practice"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationStatementLastIssueDate-1",
                        "valueDateTime": "2021-01-29T00:00:00+00:00"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DDAACC2C8D0CA4445AB79BA8476B61F49MS"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/DAACC2C8-D0CA-4445-AB79-BA8476B61F49"
                    }
                ],
                "status": "active",
                "medicationReference": {
                    "reference": "Medication/0AD23CEB-615D-4724-BEB0-EC74E161DDEF"
                },
                "effectivePeriod": {
                    "start": "2020-11-09"
                },
                "dateAsserted": "2021-06-16T11:06:09.56+01:00",
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "taken": "unk",
                "dosage": [
                    {
                        "text": "One To Be Taken Each Day"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "HealthcareService",
                "id": "5E496953-065B-41F2-9577-BE8F2FBD0757-HCS",
                "meta": {
                    "profile": [
                        "https://fhir.hl7.org.uk/STU3/StructureDefinition/CareConnect-HealthcareService-1"
                    ]
                },
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D5E496953065B41F29577BE8F2FBD0757HCS"
                    }
                ],
                "name": "TEMPLE SOWERBY MEDICAL PRACTICE"
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "6AB948A5-2067-4A67-AD00-60EAF13E9CAA",
                "meta": {
                    "versionId": "8001103298958225736",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "name": [
                    {
                        "use": "official",
                        "family": "Whitcombe",
                        "given": [
                            "Peter"
                        ],
                        "prefix": [
                            "Dr"
                        ]
                    }
                ],
                "gender": "male"
            }
        },
        {
            "resource": {
                "resourceType": "Location",
                "id": "CF61B986-5F73-44E2-B8BB-408A0F435B8B",
                "meta": {
                    "versionId": "3642112961067643133",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Location-1"
                    ]
                },
                "status": "active",
                "name": "Branch Surgery Rhing",
                "description": "hhhhhhhh",
                "type": {
                    "text": "Branch Surgery"
                },
                "telecom": [
                    {
                        "system": "phone",
                        "value": "01133972402",
                        "use": "work",
                        "rank": 1
                    },
                    {
                        "system": "phone",
                        "value": "01133972403",
                        "use": "work",
                        "rank": 2
                    }
                ],
                "managingOrganization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757",
                    "display": "TEMPLE SOWERBY MEDICAL PRACTICE"
                }
            }
        },
        {
            "resource": {
                "resourceType": "Practitioner",
                "id": "A6D3B7DE-E5F4-49FC-9F7F-6A9781829009",
                "meta": {
                    "versionId": "954275709207252868",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Practitioner-1"
                    ]
                },
                "name": [
                    {
                        "use": "official",
                        "family": "Porteous",
                        "given": [
                            "Josh"
                        ],
                        "prefix": [
                            "Mr"
                        ]
                    }
                ],
                "gender": "male"
            }
        },
        {
            "resource": {
                "resourceType": "Medication",
                "id": "E6147893-7DEC-4804-A56F-9885AC4F1B78",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Medication-1"
                    ]
                },
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/Id/test-drug-codes",
                            "code": "SITA10076BRIDL",
                            "display": "Simvastatin 10mg tablets",
                            "userSelected": true
                        },
                        {
                            "system": "http://snomed.info/sct",
                            "code": "319996000",
                            "display": "Simvastatin 10mg tablets"
                        }
                    ]
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationStatement",
                "id": "D57A7BD1-5335-434C-A90A-57342C2310D2-MS",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationStatement-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescribingAgency-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescribingAgency-1",
                                    "code": "prescribed-at-gp-practice",
                                    "display": "Prescribed at GP practice"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationStatementLastIssueDate-1",
                        "valueDateTime": "2021-01-29T00:00:00+00:00"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959DD57A7BD15335434CA90A57342C2310D2MS"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/D57A7BD1-5335-434C-A90A-57342C2310D2"
                    }
                ],
                "status": "active",
                "medicationReference": {
                    "reference": "Medication/E6147893-7DEC-4804-A56F-9885AC4F1B78"
                },
                "effectivePeriod": {
                    "start": "2020-11-09"
                },
                "dateAsserted": "2021-06-16T11:06:09.56+01:00",
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "taken": "unk",
                "dosage": [
                    {
                        "text": "One To Be Taken At Night"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "Medication",
                "id": "6E1B8C59-BE54-4BB5-B498-27E847B7B72C",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-Medication-1"
                    ]
                },
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/Id/test-drug-codes",
                            "code": "ERTA10453BRIDL",
                            "display": "Erythromycin ethyl succinate 500mg tablets",
                            "userSelected": true
                        },
                        {
                            "system": "http://snomed.info/sct",
                            "code": "324179001",
                            "display": "Erythromycin ethyl succinate 500mg tablets"
                        }
                    ]
                }
            }
        },
        {
            "resource": {
                "resourceType": "MedicationStatement",
                "id": "52B5207E-072C-4FE2-91D6-8DCF758A31A5-MS",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-MedicationStatement-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-PrescribingAgency-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-PrescribingAgency-1",
                                    "code": "prescribed-at-gp-practice",
                                    "display": "Prescribed at GP practice"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-MedicationStatementLastIssueDate-1",
                        "valueDateTime": "2020-12-02T00:00:00+00:00"
                    }
                ],
                "identifier": [
                    {
                        "system": "https://TestGPSystem/Test",
                        "value": "144A1A2EB3B34A66B33B148A5B75959D52B5207E072C4FE291D68DCF758A31A5MS"
                    }
                ],
                "basedOn": [
                    {
                        "reference": "MedicationRequest/52B5207E-072C-4FE2-91D6-8DCF758A31A5"
                    }
                ],
                "status": "completed",
                "medicationReference": {
                    "reference": "Medication/6E1B8C59-BE54-4BB5-B498-27E847B7B72C"
                },
                "effectivePeriod": {
                    "start": "2020-12-02",
                    "end": "2020-12-09"
                },
                "dateAsserted": "2021-04-20T17:28:48.8+01:00",
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "taken": "unk",
                "dosage": [
                    {
                        "text": "One To Be Taken Four Times A Day"
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "6D340A1BBC154D4E93CFBBCB5B74DF735E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "8380942905747068072",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/6D340A1B-BC15-4D4E-93CF-BBCB5B74DF73"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0260",
                                "display": "General Medical Practitioner"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "C8FD0E2C31244C72AC8DABEA65537D1B5E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "5132273260413983624",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/C8FD0E2C-3124-4C72-AC8D-ABEA65537D1B"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0260",
                                "display": "General Medical Practitioner"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "3F42A9D065A94E2D9CA467474CB83CA45E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "2936722197028477647",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/3F42A9D0-65A9-4E2D-9CA4-67474CB83CA4"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0260",
                                "display": "General Medical Practitioner"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "6AB948A520674A67AD0060EAF13E9CAA5E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "5290841605602435907",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/6AB948A5-2067-4A67-AD00-60EAF13E9CAA"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0260",
                                "display": "General Medical Practitioner"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "PractitionerRole",
                "id": "A6D3B7DEE5F449FC9F7F6A97818290095E496953065B41F29577BE8F2FBD0757",
                "meta": {
                    "versionId": "8408149953271532963",
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-PractitionerRole-1"
                    ]
                },
                "practitioner": {
                    "reference": "Practitioner/A6D3B7DE-E5F4-49FC-9F7F-6A9781829009"
                },
                "organization": {
                    "reference": "Organization/5E496953-065B-41F2-9577-BE8F2FBD0757"
                },
                "code": [
                    {
                        "coding": [
                            {
                                "system": "https://fhir.nhs.uk/STU3/CodeSystem/CareConnect-SDSJobRoleName-1",
                                "code": "R0700",
                                "display": "Community Nurse"
                            }
                        ]
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - allergies related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-allergies-related-to-problems",
                            "display": "Problems - allergies related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "AllergyIntolerance/0DAFB800-AA02-446C-9A9B-5860E9ADA3E0"
                        }
                    },
                    {
                        "item": {
                            "reference": "AllergyIntolerance/F53DA9B6-72A7-4E82-AC71-F6BC20017A38"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - diary entries related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-diary-entries-related-to-problems",
                            "display": "Problems - diary entries related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "ProcedureRequest/CBD7D61A-19A2-4368-BF9A-387CCA0DA905"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - immunisations related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-immunisations-related-to-problems",
                            "display": "Problems - immunisations related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "Immunization/9569AEF5-9527-4F6A-8EFB-417D0AB3E6B6"
                        }
                    },
                    {
                        "item": {
                            "reference": "Immunization/E151BC23-8CC1-479F-A8EC-5CB9998BA1E5"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/7499F1D6-5C58-43A0-8D0D-823CA7BD15B7"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - medications related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-medications-related-to-problems",
                            "display": "Problems - medications related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "MedicationStatement/7F987A44-FF18-4109-935B-C0A0A3976FD5-MS"
                        }
                    },
                    {
                        "item": {
                            "reference": "MedicationStatement/DAACC2C8-D0CA-4445-AB79-BA8476B61F49-MS"
                        }
                    },
                    {
                        "item": {
                            "reference": "MedicationStatement/D57A7BD1-5335-434C-A90A-57342C2310D2-MS"
                        }
                    },
                    {
                        "item": {
                            "reference": "MedicationStatement/52B5207E-072C-4FE2-91D6-8DCF758A31A5-MS"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    },
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ListWarningCode-1",
                        "valueCode": "confidential-items"
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - uncategorised data related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-uncategorised-data-related-to-problems",
                            "display": "Problems - uncategorised data related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "note": [
                    {
                        "text": "Items excluded due to confidentiality and/or patient preferences."
                    }
                ],
                "entry": [
                    {
                        "item": {
                            "reference": "Observation/3BC1331C-7C74-40D8-8576-0C990119514C"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/47BE9D54-A8A0-46DA-A0A8-A51C794777FE"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/2BE35191-475E-4D5A-8CC8-EB769562B566"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/F6FCF37E-F5D9-46FB-B39A-F94C32A69B11"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/534E8774-16A4-48CB-A187-2A7683839A24"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/C94B1851-0AF6-4DE9-A405-63B4C8BA2205"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/20063759-2032-4474-AA6D-07472A213261"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/9A8BF064-43AC-462E-BB0A-AABD1FEF0B68"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/3F9B0582-3BCC-4E03-A36D-0A33A41C73F6"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/218164F4-6101-48E4-9AFE-1CD797644C29"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/2494D07E-DB8B-471E-9171-6F79BC2E9F43"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/FACC8DEB-9D81-476D-AA42-B90F56FF1846"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/D92BE3A5-A8F5-472B-831F-455786BB4A9F"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/BA98DB56-0F48-4118-80C2-2D05BEAE2219"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/68628B67-E043-4631-BA6B-C5727324DC69"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/C83F4EBA-9E94-49B0-8C7C-15C6E8361319"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/5CDC45A0-26C6-495A-80C7-6D9C994F55C1"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/0D095295-4B3E-46DB-9986-ACDEB12974A7"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/828198DE-51DC-412D-B407-8E3253D14A18"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/5EA6E5BC-96BF-403D-B4B2-3771F3791B7B"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/FBDBFCEA-B088-4EE0-AC53-B36647E878A1"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/BA875AB4-958F-4E9C-A5AC-B5BB6C4A077C"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/D50E2934-E2C2-4C5C-8E79-294C7F79BD4A"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/160827C3-6CC2-4816-8DEE-4A234746FA7B"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/48B935AF-730D-4F99-881C-7FF2C3EF9979"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/C820B675-650C-4B09-9499-E438E69A128B"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/6DEC4C76-9A0C-4E03-A1D1-51A7F87A2DA2"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/EAF64B5B-2ED0-4190-952B-22D148FDFCBE"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/A07B493D-A5A4-4897-888E-59C7C833BE4F"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/84F97FAB-903E-4E8A-BCB1-A46FE4279038"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/4AA333FA-A1B1-4A19-BDDA-8496108767FB"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/82ACCC6C-D367-40B5-A4D3-ABA26E7363BD"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/3A43A34E-CC8A-49AD-B619-E4D7F259926E"
                        }
                    },
                    {
                        "item": {
                            "reference": "Observation/55253F84-1DA1-439D-BF16-B682117780BA"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - documents related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-documents-related-to-problems",
                            "display": "Problems - documents related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "DocumentReference/7189F0C8-639C-45BB-806F-7E156DABA151"
                        }
                    },
                    {
                        "item": {
                            "reference": "DocumentReference/E0AA40DB-D6EB-4E1F-B9BB-0E3F7F305731"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - outbound referrals related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-outbound-referrals-related-to-problems",
                            "display": "Problems - outbound referrals related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "ReferralRequest/10BD3DCD-16BD-4FBC-BECF-0E70472E2B56"
                        }
                    }
                ]
            }
        },
        {
            "resource": {
                "resourceType": "List",
                "meta": {
                    "profile": [
                        "https://fhir.nhs.uk/STU3/StructureDefinition/CareConnect-GPC-List-1"
                    ]
                },
                "extension": [
                    {
                        "url": "https://fhir.nhs.uk/STU3/StructureDefinition/Extension-CareConnect-GPC-ClinicalSetting-1",
                        "valueCodeableConcept": {
                            "coding": [
                                {
                                    "system": "http://snomed.info/sct",
                                    "code": "1060971000000108",
                                    "display": "General practice service"
                                }
                            ]
                        }
                    }
                ],
                "status": "current",
                "mode": "snapshot",
                "title": "Problems - consultations related to problems",
                "code": {
                    "coding": [
                        {
                            "system": "https://fhir.hl7.org.uk/STU3/CodeSystem/GPConnect-SecondaryListValues-1",
                            "code": "problems-consultations-related-to-problems",
                            "display": "Problems - consultations related to problems"
                        }
                    ]
                },
                "subject": {
                    "reference": "Patient/144A1A2E-B3B3-4A66-B33B-148A5B75959D"
                },
                "date": "2021-06-16T13:32:43.306+00:00",
                "orderedBy": {
                    "coding": [
                        {
                            "system": "http://hl7.org/fhir/list-order",
                            "code": "event-date",
                            "display": "Sorted by Event Date"
                        }
                    ]
                },
                "entry": [
                    {
                        "item": {
                            "reference": "Encounter/79649222-3B68-4905-A4DC-7410D29A4565"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/9C621603-70B0-44A8-B0B1-7DEF38756D2D"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/679893BB-9C1C-4125-B765-3F511FCBF5CC"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/D760544D-A24A-48E4-BCC8-76D2363BCB9B"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/9ADA5156-88A4-4B43-AE6D-1F7903C386F0"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/09905826-DF3D-4BDD-8377-C54A7A8D4914"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/C94C9A73-4AF8-4D3A-8D92-FCA8758C0BFE"
                        }
                    },
                    {
                        "item": {
                            "reference": "Encounter/86EC1A71-6739-4A43-8484-896F863E851B"
                        }
                    }
                ]
            }
        }
    ]
}
```