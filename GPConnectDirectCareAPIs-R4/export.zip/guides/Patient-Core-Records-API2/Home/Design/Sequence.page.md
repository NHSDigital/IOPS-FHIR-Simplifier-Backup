## {{page-title}}

==Sequence diagram goes here==




Care setting ---> POST ---> Central Service

NCRS ---> GET ---> Central Service

NHS App ---> GET ---> Central Service

GPSS ---> POST ---> Central Service