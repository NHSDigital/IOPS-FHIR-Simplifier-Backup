## {{page-title}}

Background
There needs to be an agreed method of acknowledging the ingress of a received payload.

The infrastructure acknowledgement is covered by synchronous HTTP response codes but the business acknowledgements are often sent some time after the API call, so an approach is required to cover eventualities like "not my patient".

The acknowledgements framework is undergoing some discussions and any decisions would be updated here.
