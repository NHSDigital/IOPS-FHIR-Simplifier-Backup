## {{page-title}}

### Record update

All updates to a record would be in the form of a RESTful POST interaction. The Bundle profile would be the used to contain the data and it would need to be ingested by the receiving system.

