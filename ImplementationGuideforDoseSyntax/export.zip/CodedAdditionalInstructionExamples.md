# Coded Additional Instruction Examples

These `medicationRequest` examples require use of the `additionalInstruction` using SNOMED-CT coded terms.

---

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    <strong>Important:</strong> Examples are not complete with respect to all required data for an R4 implementation but instead highlight the variety of use of the FHIR Dosage structure
</div>

---