## Abbreviations

This guidance also references a number of abbreviations commonly found in medical records.

[Find out more](https://www.nhs.uk/nhs-services/online-services/nhs-app/nhs-app-help-and-support/abbreviations-commonly-found-in-medical-records/){: .nhsd-a-button }
