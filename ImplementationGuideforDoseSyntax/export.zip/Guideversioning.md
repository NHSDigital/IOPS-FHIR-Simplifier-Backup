# Guide versioning

<div class="nhsd-m-phase-banner">
  <div class="nhsd-a-box nhsd-!t-bg-bright-blue-10-tint">
    <div class="nhsd-m-phase-banner__row">
      <div class="nhsd-m-phase-banner__left-col">
        <span class="nhsd-a-tag nhsd-a-tag--phase">PRIVATE BETA</span>
      </div>
      <div class="nhsd-m-phase-banner__right-col">
        This is guidance is under active development. Your feedback will help us improve it.
      </div>
    </div>
  </div>
</div>

---