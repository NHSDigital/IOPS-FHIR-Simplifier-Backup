<div class="nhsd-o-card-list">
    <div class="nhsd-t-grid">
        <div class="nhsd-t-row">
            <div class="nhsd-t-col">
                <h1 class="nhsd-!t-margin-bottom-7">Welcome to the implementation guide for dose syntax</h2>
                <div class="nhsd-a-box nhsd-a-box--bg-red nhsd-!t-margin-bottom-6 nhsd-t-body">
<strong>Important:</strong> This guide has been migrated to the <a href='https://simplifier.net/guide/ukcoreimplementationguideformedicines/Home'>Implementation Guide for Digital Medicines</a>
</div>
                <p class="nhsd-t-body">
                    The contents of this guidance have been authored by NHS Digital
                    with the support of NHSX, NHS Trusts, NHS Suppliers, Clinical Commissioning Groups and Healthcare professionals across the United Kingdom.
                </p>
                <p class="nhsd-t-body">
                    If you're brand new here, it's recommended you read the Introduction first.
                    <br />
                    <br />
                    <a class="nhsd-a-button" href="Introduction">Continue to the Introduction</a>
                </p>
            </div>
        </div>
    </div>
</div>