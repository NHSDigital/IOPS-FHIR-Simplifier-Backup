## Element: `eventHistory` <span class="mro-circle optional" title="Optional"></span>

It is recommended this element is optional for an MVP implementation.

---