## Element: `effective[x]` <span class="mro-circle mandatory" title="Mandatory"></span>

TBC

---