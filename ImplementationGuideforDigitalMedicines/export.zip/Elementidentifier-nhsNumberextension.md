## Element: `identifier - nhsNumber (extension)` <span class="mro-circle mandatory" title="Mandatory"></span>

Business required for a `UK Core` implementation as an `R4` extension to record the patient’s NHS Number.

---