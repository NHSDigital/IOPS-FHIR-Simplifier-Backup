<h2><a name="example3"></a>Example 3: <code>MedicationStatement</code></h2>

This example has been removed as not relevant to this patient journey.

<!--<div class="nhsd-a-box nhsd-a-box--bg-light-blue nhsd-!t-margin-bottom-6 nhsd-t-body"><strong>Note</strong>: This example below is a draft and requires clinical verification.</div>



<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body"><strong>Important</strong>: The <code>MedicationStatement</code> resource does not currently have a <code>category</code> valueset that contains a value for <code>leave</code>.</div>
-->

<!--// start of code snippet -->
<!--
<div>
    <ul class="nav nav-tabs" role="tablist">
      <li role="presentation" class="active">
        <a href="#xml-6" aria-controls="xml" role="tab" data-toggle="tab">XML</a>
      </li>
      <li role="presentation">
        <a href="#json-6" aria-controls="json" role="tab" data-toggle="tab">JSON</a>
      </li>
        <li role="presentation">
        <a href="#table-6" aria-controls="table" role="tab" data-toggle="tab">Table</a>
      </li>
      <li role="presentation">
        <a href="#tree-6" aria-controls="tree" role="tab" data-toggle="tab">Tree</a>
      </li>
  </ul>
-->
  <!-- Tab panes -->
<!--
  <div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="xml-6">
      {{xml:example-bundle-med-statement-on-leave-toby-lerone}}
    </div>
    <div role="tabpanel" class="tab-pane" id="json-6">
      {{json:example-bundle-med-statement-on-leave-toby-lerone}}
    </div>
    <div role="tabpanel" class="tab-pane" id="table-6">
      {{table:example-bundle-med-statement-on-leave-toby-lerone}}
    </div>
    <div role="tabpanel" class="tab-pane" id="tree-6">
      {{tree:example-bundle-med-statement-on-leave-toby-lerone}}
    </div>
  </div>
</div>
-->
<!--// end of code snippet -->