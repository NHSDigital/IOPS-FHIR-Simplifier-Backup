## Element: `{{page-title}}`

UKCore uses codes within the [ePrescribing route of administration simple reference set (foundation metadata concept)](https://termbrowser.nhs.uk/?perspective=full&conceptId1=999000051000001100&edition=uk-edition).

```xml
<!-- Route -->
<route>
    <coding>
        <system value="http://snomed.info/sct"/>
        <code value="78421000"/>
        <display value="Intramuscular route (qualifier value)"/>
    </coding>
</route>
```

---