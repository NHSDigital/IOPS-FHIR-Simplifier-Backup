## Element: `detectedIssue` <span class="mro-circle avoid" title="Avoid"></span>

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    It is recommended this element is avoided for an MVP implementation.
</div>

---