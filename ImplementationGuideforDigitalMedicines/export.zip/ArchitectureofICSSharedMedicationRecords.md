## Architecture of Integrated Care Systems / Shared Medication Records

See the [Shared Medication Record Architectures](https://simplifier.net/guide/ukcoreimplementationguideformedicines/SharedMedicationRecordArchitectures){: .nhsd-a-link } page that explains three likely architectures of **federated**, **persisted copy** and **hybrid** for shared records.