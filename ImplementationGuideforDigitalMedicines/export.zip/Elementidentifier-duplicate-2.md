## Element: `identifier` <span class="mro-circle mandatory" title="Mandatory"></span>

Use if a local implementation requires bespoke identifiers to track medication requests between the ePMA and dispensing systems.

---