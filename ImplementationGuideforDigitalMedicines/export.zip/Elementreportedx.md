## Element: `reported[x]` <span class="mro-circle unknown" title="Unknown"></span>

Implementation guidance is pending further analysis for the potential use of this element.

---