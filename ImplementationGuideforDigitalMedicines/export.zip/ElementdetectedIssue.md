## Element: `detectedIssue` <span class="mro-circle avoid" title="Avoid"></span>

It is recommended this element is avoided for an MVP implementation.

---