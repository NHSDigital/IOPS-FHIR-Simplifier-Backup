## Element: `address` <span class="mro-circle optional" title="Optional"></span>

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    The element is not required for an MVP implementation.
</div>

The hospital Patient Administration System (PAS) will have a record of the patient address but this information is not required to be shared with the hospital pharmacy system to support the dispensing process.

---