## Element: `text` <span class="mro-circle optional" title="Optional"></span>

It is recommended this element is **not implemented** as part of an MVP.

or

Where the user of the ePMA system has selected a pre-defined medication order, often known as an “order sentence”, the textual description of the order sentence should be populated as the text for this resource. 

This is so that the text chosen on-screen by the user is captured within the `MedicationRequest` resource. Where an ePMA system does not use a concept akin to selecting an order sentence then this element does not form part of the recommended MVP.
