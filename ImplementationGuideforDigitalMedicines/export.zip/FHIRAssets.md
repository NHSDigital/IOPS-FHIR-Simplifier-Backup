# {{page-title}}

For FHIR Assets not shown here, refer to the [UK Core](https://simplifier.net/guide/UKCoreVersionHistory/Home) standard.

{{index:current}}
