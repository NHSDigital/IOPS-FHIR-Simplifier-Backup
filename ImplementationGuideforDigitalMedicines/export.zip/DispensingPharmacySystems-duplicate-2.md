## {{page-title}}

A dispensing system is used within a pharmacy organisation or pharmacy function of a hospital. It is used to record the supply of medicines and appliances following order requests and/or NHS prescriptions. Key functions include dispensed medicines labelling and stock control.

---