## Element: `deceased[x]` <span class="mro-circle optional" title="Optional"></span>

Business required for two reasons;

1. Key patient demographic for patient identification
2. Can influence the medication dispensing decision process, e.g. paediatric medication

---