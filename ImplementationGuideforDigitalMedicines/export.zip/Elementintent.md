## Element: `intent` <span class="mro-circle mandatory" title="Mandatory"></span>

The value `order` should be used to denote this is a medication request order.

---