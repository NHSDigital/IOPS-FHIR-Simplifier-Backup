# {{page-title}}

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    This page is in Experimental status.
</div>

This section details the logic required for a system to generate a suitable, clinically safe, complete medication plus dosage string from the coded structures.

---
