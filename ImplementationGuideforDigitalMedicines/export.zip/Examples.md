# {{page-title}}

XML and JSON examples for the use cases in scope within this implementation guide.

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
  All examples are based on an implementation using <code>FHIR Messages</code> where the provider system is using an HTTP <code>POST</code> to the consumer system acting as a FHIR Server.
</div>

{{index:current}}
