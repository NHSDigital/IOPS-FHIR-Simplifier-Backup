# {{page-title}}

## Patient Journey: Justin Thyme

1. Justin self-declares over-the-counter **Paracetamol** medication and this is recorded in the clinical system and can be shared with a shared medication record as a `MedicationStatement`.

---
