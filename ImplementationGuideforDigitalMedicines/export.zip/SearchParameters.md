# {{page-title}}

For context, see [Search](https://simplifier.net/guide/ukcoreimplementationguideformedicines/Interactions#Search){: .nhsd-a-link } within the Interactions section.
