## Element: `text` <span class="mro-circle optional" title="optional"></span>

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    It is recommended this element is <strong>not implemented</strong> as part of an MVP.
</div>