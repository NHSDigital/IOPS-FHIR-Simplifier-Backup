<div class="article-header">
    <h1>This guide has been moved.</h1>
    <p class="subtitle">Please update any references to this location using the link below.</p>
</div>

The new link for this guide is:

[https://simplifier.net/guide/ukcoreimplementationguideformedicines](https://simplifier.net/guide/ukcoreimplementationguideformedicines)

Please update your links to reflect the new location.



[Go to the new implementation guidance](https://simplifier.net/guide/ukcoreimplementationguideformedicines){: .btn .btn-default }
