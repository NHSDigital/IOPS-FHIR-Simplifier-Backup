## {{page-title}}

<div class="nhsd-a-box nhsd-a-box--bg-light-blue nhsd-!t-margin-bottom-6 nhsd-t-body">
    <strong>Note:</strong> Both these resources are work-in-progress and subject to change.
</div>

An open source TypeScript function based on this guidance is available from the [NHS Digital Github](https://github.com/NHSDigital/electronic-prescription-service-api/blob/master/coordinator/src/services/translation/request/dosage.ts).

A user-facing end-point based on this guidance has been incorporated into the [NHS Digital EPSAT](https://internal-dev-sandbox.api.service.nhs.uk/eps-api-tool/) testing tool.

---
