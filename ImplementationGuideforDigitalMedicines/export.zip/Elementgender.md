## Element: `gender` <span class="mro-circle mandatory" title="Mandatory"></span>

Business required as a key patient demographic for patient identification.


---