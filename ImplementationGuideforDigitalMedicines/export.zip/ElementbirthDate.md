## Element: `birthDate` <span class="mro-circle mandatory" title="Mandatory"></span>

Business required for two reasons;

1. Key patient demographic for patient identification
2. Can influence the medication dispensing decision process, e.g. paediatric medication

---