# {{page-title}}

The following edge cases have been identified which are not sufficiently supported as coded structures within the R4 `Dosage` structure. Until such a time when the R4 FHIR [UK Core](https://simplifier.net/guide/UKCoreVersionHistory/Home) profiles are updated with either an extension or an internationally agreed change to the HL7 FHIR standard, a work-around is required.