<a name="example3"></a>
## {{page-title}}

<div class="nhsd-a-box nhsd-a-box--bg-light-blue nhsd-!t-margin-bottom-6 nhsd-t-body"><strong>Note:</strong> This example below has been temporarily removed as under review and will be re-published very soon.</div>

The dispensing of **Pregabalin**.

### Actors

**Provider System** = Hospital pharamcy system

**Consumer System** = Ward EMPA system

### Example

*Example will be re-published soon...*

<!--// start of code snippet -->
<!--
NB: Need to add "Pregabalin 75mg tablets" (38020211000001109) and 56 tablets into this example.
<div>
    <ul class="nav nav-tabs" role="tablist">
      <li role="presentation" class="active">
        <a href="#xml-3" aria-controls="xml" role="tab" data-toggle="tab">XML</a>
      </li>
      <li role="presentation">
        <a href="#json-3" aria-controls="json" role="tab" data-toggle="tab">JSON</a>
      </li>
        <li role="presentation">
        <a href="#table-3" aria-controls="table" role="tab" data-toggle="tab">Table</a>
      </li>
      <li role="presentation">
        <a href="#tree-3" aria-controls="tree" role="tab" data-toggle="tab">Tree</a>
      </li>
  </ul>
-->
  <!-- Tab panes -->
  <!--
  <div class="tab-content snippet">
    <div role="tabpanel" class="tab-pane active" id="xml-3">
      {{xml:chris-packet-example-3}}
    </div>
    <div role="tabpanel" class="tab-pane" id="json-3">
      {{json:chris-packet-example-3}}
    </div>
    <div role="tabpanel" class="tab-pane" id="table-3">
      {{table:chris-packet-example-3}}
    </div>
    <div role="tabpanel" class="tab-pane" id="tree-3">
      {{tree:chris-packet-example-3}}
    </div>
  </div>
</div>
-->
<!--// end of code snippet -->

---