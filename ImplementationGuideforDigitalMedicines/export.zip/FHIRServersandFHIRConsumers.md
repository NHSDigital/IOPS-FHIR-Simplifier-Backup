## {{page-title}}

See the [Interactions](Interactions){: .nhsd-a-link } page that explains how the RESTful operations of `POST` and `GET` will be used depending on which clinical system is acting as a FHIR server or a FHIR consumer.

---