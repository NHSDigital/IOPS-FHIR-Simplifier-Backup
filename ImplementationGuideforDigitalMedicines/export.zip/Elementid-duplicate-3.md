## Element: `id` <span class="mro-circle required" title="Required"></span>

Is is recommended that the logical id is the local patient identifier issued and managed within the Trust for the patient. 

This will typically be different to the patient’s NHS Number.