## {{page-title}}

This guidance uses a number of developer terms - details of which can be found on the NHS Digital website in the Glossary of Developer terms section.

[Find out more](https://digital.nhs.uk/developer/guides-and-documentation/glossary-of-developer-terms){: .nhsd-a-button }

---