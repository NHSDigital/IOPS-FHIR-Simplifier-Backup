## Element: `type` <span class="mro-circle required" title="Required"></span>

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    It is recommended this element is required for an MVP implementation.
</div>

---