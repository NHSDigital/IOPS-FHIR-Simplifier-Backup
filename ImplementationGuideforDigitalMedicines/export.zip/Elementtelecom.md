## Element: `telecom` <span class="mro-circle optional" title="Optional"></span>

<div class="nhsd-a-box nhsd-a-box--bg-light-yellow nhsd-!t-margin-bottom-6 nhsd-t-body">
    The element is not required for an MVP implementation.
</div>

---