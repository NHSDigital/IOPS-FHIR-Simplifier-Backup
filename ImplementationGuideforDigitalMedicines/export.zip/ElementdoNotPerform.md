## Element: `doNotPerform` <span class="mro-circle avoid" title="Avoid"></span>

Implementation guidance is pending further analysis for the potential use and risks for this element.

At this time it is advised to **not support** this element within an implementation.

---