## {{page-title}}

<div class="nhsd-!t-margin-bottom-6">
<ul class="nav nav-tabs" role="tablist">
   <li role="presentation" >
      <a href="#AllergyIntoleranceTableOutput" role="tab" data-toggle="tab">Table View</a>
   </li>
   <li role="presentation">
      <a href="#AllergyIntoleranceJSONOutput" role="tab" data-toggle="tab">JSON View</a>
   </li>
</ul>
<div class="tab-content snippet">
   <div id="AllergyIntoleranceTableOutput" role="tabpanel" class="tab-pane active">
      <br>
      {{table:Example-Output-UKCore-AllergyIntolerance}}
   </div>
   <div id="AllergyIntoleranceJSONOutput" role="tabpanel" class="tab-pane">
      <br/>
      {{json:Example-Output-UKCore-AllergyIntolerance}}
   </div>
</div>
</div>

-----