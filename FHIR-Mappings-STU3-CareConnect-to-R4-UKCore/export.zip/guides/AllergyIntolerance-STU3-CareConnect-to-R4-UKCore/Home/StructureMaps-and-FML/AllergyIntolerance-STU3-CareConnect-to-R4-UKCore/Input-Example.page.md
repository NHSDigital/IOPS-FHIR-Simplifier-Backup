## {{page-title}}

<div class="nhsd-!t-margin-bottom-6">
<ul class="nav nav-tabs" role="tablist">
   <li role="presentation" >
      <a href="#AllergyIntoleranceTableInput" role="tab" data-toggle="tab">Table View</a>
   </li>
   <li role="presentation">
      <a href="#AllergyIntoleranceJSONInput" role="tab" data-toggle="tab">JSON View</a>
   </li>
</ul>
<div class="tab-content snippet">
   <div id="AllergyIntoleranceTableInput" role="tabpanel" class="tab-pane active">
      <br>
      {{table:Example-Input-CareConnect-AllergyIntolerance}}
   </div>
   <div id="AllergyIntoleranceJSONInput" role="tabpanel" class="tab-pane">
      <br/>
      {{json:Example-Input-CareConnect-AllergyIntolerance}}
   </div>
</div>
</div>

TODO (STU3 resource won't render as project is R4)

-----


