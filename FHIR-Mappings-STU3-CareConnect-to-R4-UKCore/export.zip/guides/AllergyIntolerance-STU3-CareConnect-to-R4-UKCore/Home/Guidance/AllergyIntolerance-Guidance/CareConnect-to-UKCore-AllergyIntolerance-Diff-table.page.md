## {{page-title}}

{{render:DiffTable-CareConnect-to-UKCore-AllergyIntolerance3to4.md}}

---