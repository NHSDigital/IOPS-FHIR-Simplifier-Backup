## {{page-title}}

The recording of allergy and intolerance information in patient records is a major component of communicating the effects of external substances and compounds on patient health.

---